-- ==============================================================================
-- COMPLETE MENUS TABLE WITH PARENT-CHILD HIERARCHY
-- Created: 2026-03-05
-- Description: Full SQL script to create menus table and insert all menu items 
--              separately with parent-child relationships
-- ==============================================================================

-- ==============================================================================
-- STEP 1: DROP EXISTING TABLES (if you want fresh start)
-- ==============================================================================
-- Uncomment the following line if you want to drop and recreate:
-- DROP TABLE IF EXISTS menus;

-- ==============================================================================
-- STEP 2: CREATE MENUS TABLE WITH PARENT SUPPORT
-- ==============================================================================

CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    parent_id VARCHAR(36) DEFAULT NULL,
    menu_order INT DEFAULT 0,
    bg_color VARCHAR(20) DEFAULT '#8B5CF6',
    text_color VARCHAR(20) DEFAULT '#FFFFFF',
    hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
    hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
    label VARCHAR(100),
    route VARCHAR(100),
    icon VARCHAR(50),
    subtitle VARCHAR(255),
    purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
    menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
    is_visible BOOLEAN DEFAULT TRUE,
    required_flags JSON,
    required_permissions JSON,
    required_roles JSON,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL
);

-- ==============================================================================
-- STEP 3: CREATE INDEXES FOR PERFORMANCE
-- ==============================================================================

CREATE INDEX IF NOT EXISTS idx_menus_type ON menus(type);
CREATE INDEX IF NOT EXISTS idx_menus_parent ON menus(parent_id);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_purpose ON menus(purpose);
CREATE INDEX IF NOT EXISTS idx_menus_menu_for ON menus(menu_for);
CREATE INDEX IF NOT EXISTS idx_menus_active ON menus(is_active);

-- ==============================================================================
-- STEP 4: DELETE EXISTING MENUS AND INSERT FRESH DATA
-- ==============================================================================

-- First delete existing menus to avoid duplicates
DELETE FROM menus WHERE type IN ('primary', 'secondary');

-- Primary Menu Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible) 
VALUES (
    'menu-primary-main',
    'Primary Navigation',
    'primary',
    TRUE,
    '[]',
    0,
    '#8B5CF6',
    '#FFFFFF',
    'home',
    'mobile',
    TRUE
);

-- Primary Menu Items - Each as separate row with parent_id (use INSERT IGNORE)

-- Home Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-home',
    'Home',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    1,
    'Home',
    'home',
    'Home',
    'home',
    'mobile',
    TRUE
);

-- Notifications Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-notifications',
    'Notifications',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    2,
    'Notifications',
    'notifications',
    'Alerts',
    'home',
    'mobile',
    TRUE
);

-- AI Chat Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-ai-chat',
    'AI Chat',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    3,
    'AIChat',
    'chatbubbles',
    'AI Chat',
    'home',
    'mobile',
    TRUE,
    '["ai.chat"]',
    '["ai:read"]'
);

-- More Tab (with children - dropdown)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-more',
    'More',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    4,
    'More',
    'menu',
    'More',
    'home',
    'mobile',
    TRUE
);

-- Profile Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-profile',
    'Profile',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    5,
    'Profile',
    'person',
    'Profile',
    'home',
    'mobile',
    TRUE
);

-- ==============================================================================
-- STEP 5: INSERT CHILDREN FOR "MORE" MENU
-- ==============================================================================

-- More > Women Safety
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles)
VALUES (
    'menu-more-women-safety',
    'Women Safety',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    1,
    'WomenSafety',
    'shield-checkmark',
    'Women Safety',
    '#EC4899',
    'more',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]'
);

-- More > Child Care
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles)
VALUES (
    'menu-more-child-care',
    'Child Care',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    2,
    'ChildCare',
    'happy',
    'Child Care',
    '#10B981',
    'more',
    'mobile',
    TRUE,
    '["parent", "guardian"]'
);

-- More > Family
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, required_permissions)
VALUES (
    'menu-more-family',
    'Family',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    3,
    'Family',
    'people',
    'Family',
    '#EC4899',
    'more',
    'mobile',
    TRUE,
    '["parent", "guardian", "admin"]',
    '["family.tracking"]',
    '["family:read"]'
);

-- More > Home Automation
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-home-automation',
    'Home Automation',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    4,
    'HomeAutomation',
    'home',
    'Home Automation',
    '#3B82F6',
    'more',
    'mobile',
    TRUE,
    '["home.automation"]',
    '["automation:read"]'
);

-- More > Vision AI
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-vision',
    'Vision AI',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    5,
    'Vision',
    'camera',
    'Vision AI',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["ai.vision"]',
    '["ai:read"]'
);

-- More > Speech to Text
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-speech',
    'Speech to Text',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    6,
    'Speech',
    'mic',
    'Speech to Text',
    '#10B981',
    'more',
    'mobile',
    TRUE,
    '["ai.speech"]',
    '["ai:read"]'
);

-- More > Text to Speech
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-tts',
    'Text to Speech',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    7,
    'TTS',
    'volume-high',
    'Text to Speech',
    '#F59E0B',
    'more',
    'mobile',
    TRUE,
    '["ai.tts"]',
    '["ai:read"]'
);

-- More > Model Browser
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-models',
    'Model Browser',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    8,
    'ModelsList',
    'server',
    'Model Browser',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["ai:read"]'
);

-- More > Settings
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-settings',
    'Settings',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    9,
    'Settings',
    'settings',
    'Settings',
    '#F59E0B',
    'more',
    'mobile',
    TRUE,
    '["settings:read"]'
);

-- More > My Profile
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-profile',
    'My Profile',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    10,
    'Profile',
    'person',
    'My Profile',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["users:read"]'
);

-- ==============================================================================
-- STEP 6: INSERT CORE SERVICES MENU (Home Screen Cards)
-- ==============================================================================

-- Core Services Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible)
VALUES (
    'menu-core-services',
    'Core Services',
    'secondary',
    TRUE,
    '[]',
    1,
    '#EC4899',
    '#FFFFFF',
    'home',
    'mobile',
    TRUE
);

-- Core Service: Women Safety
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'svc-women-safety',
    'Women Safety',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    1,
    'WomenSafety',
    'shield-checkmark',
    'Women Safety',
    'SOS, emergency contacts & safety tips',
    '#EC4899',
    'home',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["sos.emergency"]',
    'safety'
);

-- Core Service: Child Care
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, category)
VALUES (
    'svc-child-care',
    'Child Care',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    2,
    'ChildCare',
    'happy',
    'Child Care',
    'Tips, guidance & assistant',
    '#10B981',
    'home',
    'mobile',
    TRUE,
    '["parent", "guardian"]',
    'family'
);

-- Core Service: Family
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, required_permissions, category)
VALUES (
    'svc-family',
    'Family',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    3,
    'Family',
    'people',
    'Family',
    'Manage family members & relationships',
    '#EC4899',
    'home',
    'mobile',
    TRUE,
    '["parent", "guardian", "admin"]',
    '["family.tracking"]',
    '["family:read"]',
    'family'
);

-- Core Service: Home Automation
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-home-automation',
    'Home Automation',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    4,
    'HomeAutomation',
    'home',
    'Home Automation',
    'Control smart devices & appliances',
    '#3B82F6',
    'home',
    'mobile',
    TRUE,
    '["home.automation"]',
    '["automation:read"]',
    'lifestyle'
);

-- Core Service: Vision AI
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-vision',
    'Vision',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    5,
    'Vision',
    'camera',
    'Vision',
    'Image analysis with AI',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["ai.vision"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Speech to Text
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-speech',
    'Speech to Text',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    6,
    'Speech',
    'mic',
    'Speech to Text',
    'Transcribe audio with AI',
    '#10B981',
    'home',
    'mobile',
    TRUE,
    '["ai.speech"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Text to Speech
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-tts',
    'Text to Speech',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    7,
    'TTS',
    'volume-high',
    'Text to Speech',
    'Convert text to speech',
    '#F59E0B',
    'home',
    'mobile',
    TRUE,
    '["ai.tts"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Model Browser
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-models',
    'Model Browser',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    8,
    'ModelsList',
    'server',
    'Model Browser',
    'Browse and select AI models',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["ai:read"]',
    'ai'
);

-- Core Service: Settings
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-settings',
    'Settings',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    9,
    'Settings',
    'settings',
    'Settings',
    'API key, preferences & about',
    '#F59E0B',
    'home',
    'mobile',
    TRUE,
    '["settings:read"]',
    'system'
);

-- Core Service: My Profile
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-profile',
    'My Profile',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    10,
    'Profile',
    'person',
    'My Profile',
    'View & edit your profile',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["users:read"]',
    'system'
);

-- ==============================================================================
-- STEP 7: VERIFICATION QUERIES
-- ==============================================================================

-- Check all menus with their parent relationships
SELECT 
    m.id,
    m.name,
    m.type,
    m.menu_order,
    m.route,
    m.icon,
    m.label,
    m.purpose,
    m.menu_for,
    m.is_visible,
    p.name AS parent_name,
    p.type AS parent_type
FROM menus m
LEFT JOIN menus p ON m.parent_id = p.id
ORDER BY m.type, m.menu_order;

-- Get hierarchy tree for primary menu
SELECT 
    m.id,
    m.name,
    m.menu_order,
    m.route,
    m.icon,
    m.label,
    m.parent_id,
    p.name AS parent_name
FROM menus m
LEFT JOIN menus p ON m.parent_id = p.id
WHERE m.type = 'primary'
ORDER BY m.menu_order;

-- Get services by category
SELECT 
    category,
    COUNT(*) as count
FROM menus
WHERE type = 'secondary' 
AND parent_id = 'menu-core-services'
GROUP BY category;

SELECT 'Full menu hierarchy setup completed successfully!' AS status;
