-- ==============================================================================
-- WOMEN SAFETY, SAFETY MAP, AND SAFE ROUTE MODULES MIGRATION
-- Created: 2026-03-08
-- Purpose: Add database tables for Women Safety, Safety Map, and Safe Route modules
-- ==============================================================================

USE safety_app;

-- ==============================================================================
-- PART 1: WOMEN SAFETY MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1.1 SOS ALERTS LOG (Enhanced version)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sos_alerts_log (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type ENUM('sos', 'panic', 'distress', 'emergency') DEFAULT 'sos',
    status ENUM('initiated', 'in_progress', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'initiated',
    latitude DOUBLE,
    longitude DOUBLE,
    address VARCHAR(500),
    accuracy DECIMAL(10,2),
    trigger_method ENUM('button', 'shake', 'voice', 'timer', 'auto') DEFAULT 'button',
    message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_alert_type (alert_type),
    INDEX idx_started_at (started_at),
    INDEX idx_is_active (is_active),
    INDEX idx_location (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.2 SOS LOCATION HISTORY (Track SOS location updates)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sos_location_history (
    id VARCHAR(36) PRIMARY KEY,
    sos_alert_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    accuracy DECIMAL(10,2),
    speed DECIMAL(10,2),
    heading DECIMAL(10,2),
    altitude DOUBLE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sos_alert_id (sos_alert_id),
    INDEX idx_user_id (user_id),
    INDEX idx_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.3 FAKE CALL LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fake_call_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    caller_name VARCHAR(100) NOT NULL,
    caller_number VARCHAR(20),
    scheduled_duration INT DEFAULT 30 COMMENT 'Duration in seconds',
    actual_duration INT DEFAULT 0 COMMENT 'Actual duration in seconds',
    ringtone_type VARCHAR(50) DEFAULT 'default',
    call_status ENUM('scheduled', 'ringing', 'answered', 'missed', 'cancelled', 'completed') DEFAULT 'scheduled',
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    is_automated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_call_status (call_status),
    INDEX idx_scheduled_at (scheduled_at),
    INDEX idx_started_at (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.4 FAKE CALL SETTINGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fake_call_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    default_caller_name VARCHAR(100) DEFAULT 'Mom',
    default_caller_number VARCHAR(20),
    default_duration INT DEFAULT 30,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    vibration_enabled BOOLEAN DEFAULT TRUE,
    answer_automatically BOOLEAN DEFAULT FALSE,
    custom_greeting TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.5 SIREN LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS siren_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    siren_type ENUM('panic', 'emergency', 'car', 'custom') DEFAULT 'panic',
    volume_level INT DEFAULT 100 COMMENT 'Volume percentage 0-100',
    duration_seconds INT DEFAULT 0,
    trigger_method ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
    latitude DOUBLE,
    longitude DOUBLE,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_siren_type (siren_type),
    INDEX idx_started_at (started_at),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.6 RECORDING LOGS (Audio/Video)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recording_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sos_alert_id VARCHAR(36),
    recording_type ENUM('audio', 'video', 'both') DEFAULT 'audio',
    file_path VARCHAR(500),
    file_size BIGINT COMMENT 'Size in bytes',
    duration_seconds INT DEFAULT 0,
    format VARCHAR(20) DEFAULT 'm4a',
    quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DOUBLE,
    longitude DOUBLE,
    is_automatically_triggered BOOLEAN DEFAULT FALSE,
    transcription TEXT,
    is_uploaded BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    recording_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recording_ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_sos_alert_id (sos_alert_id),
    INDEX idx_recording_type (recording_type),
    INDEX idx_recording_started_at (recording_started_at),
    INDEX idx_is_uploaded (is_uploaded),
    INDEX idx_is_deleted (is_deleted)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.7 WOMEN SAFETY PREFERENCES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS women_safety_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    sos_enabled BOOLEAN DEFAULT TRUE,
    sos_button_size ENUM('small', 'medium', 'large') DEFAULT 'large',
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_auto_call_enabled BOOLEAN DEFAULT FALSE,
    sos_location_sharing_enabled BOOLEAN DEFAULT TRUE,
    sos_notify_contacts BOOLEAN DEFAULT TRUE,
    sos_message_template TEXT,
    fake_call_enabled BOOLEAN DEFAULT TRUE,
    siren_enabled BOOLEAN DEFAULT TRUE,
    auto_recording_on_sos BOOLEAN DEFAULT TRUE,
    audio_quality ENUM('low', 'medium', 'high') DEFAULT 'high',
    video_quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    shake_to_activate BOOLEAN DEFAULT FALSE,
    voice_activation_enabled BOOLEAN DEFAULT FALSE,
    voice_activation_phrase VARCHAR(100),
    timer_based_sos BOOLEAN DEFAULT FALSE,
    timer_duration_minutes INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 2: SAFETY MAP MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 2.1 MAP INCIDENTS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS map_incidents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    incident_type ENUM('harassment', 'assault', 'theft', 'suspicious_activity', 'unsafe_area', 'police_presence', 'accident', 'road_block', 'natural_disaster', 'other') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by VARCHAR(36),
    verification_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    report_count INT DEFAULT 1,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    photo_url VARCHAR(500),
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    tags JSON,
    expires_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_incident_type (incident_type),
    INDEX idx_severity (severity),
    INDEX idx_location (latitude, longitude),
    INDEX idx_city (city),
    INDEX idx_is_verified (is_verified),
    INDEX idx_verification_status (verification_status),
    INDEX idx_is_active (is_active),
    INDEX idx_created_at (created_at),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.2 SAFE ZONES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS safe_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    zone_type ENUM('police_station', 'hospital', 'fire_station', 'public_space', 'cafe', 'shop', 'residential', 'public_transport', 'other') NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500 COMMENT 'Zone radius in meters',
    zone_shape ENUM('circle', 'polygon') DEFAULT 'circle',
    polygon_coords JSON,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    amenity_details JSON COMMENT 'Details like operating hours, phone, etc.',
    safety_rating DECIMAL(3,2) DEFAULT 5.00 COMMENT 'Safety rating 1-5',
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_zone_type (zone_type),
    INDEX idx_location (latitude, longitude),
    INDEX idx_city (city),
    INDEX idx_is_verified (is_verified),
    INDEX idx_is_public (is_public),
    INDEX idx_is_active (is_active),
    INDEX idx_safety_rating (safety_rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.3 AREA SAFETY RATINGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS area_safety_ratings (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    center_latitude DOUBLE NOT NULL,
    center_longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 1000,
    overall_rating DECIMAL(3,2) DEFAULT 3.00,
    incident_count INT DEFAULT 0,
    safe_zone_count INT DEFAULT 0,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    rating_breakdown JSON COMMENT '{"harassment": 3.0, "theft": 3.5, "assault": 4.0, "overall": 3.5}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_area_name (area_name),
    INDEX idx_city (city),
    INDEX idx_location (center_latitude, center_longitude),
    INDEX idx_overall_rating (overall_rating),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.4 INCIDENT VOTES (Community verification)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident_votes (
    id VARCHAR(36) PRIMARY KEY,
    incident_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    vote_type ENUM('upvote', 'downvote') DEFAULT 'upvote',
    is_helpful BOOLEAN DEFAULT TRUE,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES map_incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_incident_user_vote (incident_id, user_id),
    INDEX idx_incident_id (incident_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 3: SAFE ROUTE MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 3.1 ROUTE HISTORY
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    origin_name VARCHAR(255),
    origin_latitude DOUBLE NOT NULL,
    origin_longitude DOUBLE NOT NULL,
    destination_name VARCHAR(255),
    destination_latitude DOUBLE NOT NULL,
    destination_longitude DOUBLE NOT NULL,
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    route_distance DECIMAL(10,2) COMMENT 'Distance in kilometers',
    route_duration INT COMMENT 'Duration in minutes',
    safety_score DECIMAL(5,2) COMMENT 'Safety score 0-100',
    route_path JSON COMMENT 'Encoded polyline or coordinates array',
    alternative_routes JSON COMMENT 'Alternative routes if any',
    is_favorite BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_travel_mode (travel_mode),
    INDEX idx_safety_score (safety_score),
    INDEX idx_is_favorite (is_favorite),
    INDEX idx_is_completed (is_completed),
    INDEX idx_started_at (started_at),
    INDEX idx_completed_at (completed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.2 ROUTE PREFERENCES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    preferred_travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    avoid_highways BOOLEAN DEFAULT FALSE,
    avoid_tolls BOOLEAN DEFAULT FALSE,
    avoid_ferries BOOLEAN DEFAULT FALSE,
    prefer_lit_streets BOOLEAN DEFAULT TRUE,
    prefer_popular_areas BOOLEAN DEFAULT TRUE,
    minimum_safety_score INT DEFAULT 50 COMMENT 'Minimum safety score threshold',
    maximum_walk_distance INT DEFAULT 2000 COMMENT 'Max walking distance in meters',
    prefer_alternative_routes BOOLEAN DEFAULT TRUE,
    time_of_day_preference JSON COMMENT '{"morning": "8:00", "evening": "18:00"}',
    saved_locations JSON COMMENT 'Saved locations for quick access',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.3 ROUTE WAYPOINTS (Waypoints along a route)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_waypoints (
    id VARCHAR(36) PRIMARY KEY,
    route_id VARCHAR(36) NOT NULL,
    waypoint_order INT NOT NULL,
    waypoint_name VARCHAR(255),
    waypoint_type ENUM('safety_check', 'safe_zone', 'police_station', 'hospital', 'cafe', 'rest_stop', 'other') DEFAULT 'safety_check',
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    distance_from_start DECIMAL(10,2) COMMENT 'Distance from start in km',
    estimated_time_from_start INT COMMENT 'Time from start in minutes',
    safety_rating DECIMAL(3,2),
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES route_history(id) ON DELETE CASCADE,
    INDEX idx_route_id (route_id),
    INDEX idx_waypoint_order (waypoint_order),
    INDEX idx_waypoint_type (waypoint_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.4 SAFETY TIPS (AI-generated or curated safety tips)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS safety_tips (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('general', 'walking', 'driving', 'public_transport', 'night', 'emergency', 'digital') DEFAULT 'general',
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit', 'all') DEFAULT 'all',
    time_of_day ENUM('morning', 'afternoon', 'evening', 'night', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_travel_mode (travel_mode),
    INDEX idx_time_of_day (time_of_day),
    INDEX idx_is_active (is_active),
    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 4: ADD MENU ENTRIES FOR NEW MODULES
-- ==============================================================================

-- Add Women Safety menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-women-safety', 'Women Safety', 'primary', TRUE, '[]', 'menu-more', 10, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'Personal safety features', '#EC4899', 'more', 'mobile', TRUE, '["women.safety.view"]', '["women_safety:view"]', 'safety', NOW(), NOW());

-- Add Safety Map menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-more', 11, 'SafetyMap', 'map', 'Safety Map', 'Community safety map', '#10B981', 'more', 'mobile', TRUE, '["safety.map.view"]', '["safety_map:view"]', 'safety', NOW(), NOW());

-- Add Safe Route menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-more', 12, 'SafeRoute', 'navigate', 'Safe Route', 'AI-powered safe routes', '#3B82F6', 'more', 'mobile', TRUE, '["safe.route.view"]', '["safe_route:view"]', 'safety', NOW(), NOW());

-- Add Fake Call to Women Safety submenu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-women-safety-fake-call', 'Fake Call', 'secondary', TRUE, '[]', 'menu-women-safety', 1, 'FakeCall', 'call', 'Fake Call', 'Simulate incoming calls', '#8B5CF6', 'more', 'mobile', TRUE, '["fake.call.use"]', '["fake_call:use"]', 'safety', NOW(), NOW());

-- Add Women Safety to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-women-safety', 'Women Safety', 'primary', TRUE, '[]', 'menu-core-services-container', 10, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'Personal safety features', '#EC4899', 'home', 'mobile', TRUE, '["women.safety.view"]', '["women_safety:view"]', 'safety', NOW(), NOW());

-- Add Safety Map to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-core-services-container', 11, 'SafetyMap', 'map', 'Safety Map', 'Community safety map', '#10B981', 'home', 'mobile', TRUE, '["safety.map.view"]', '["safety_map:view"]', 'safety', NOW(), NOW());

-- Add Safe Route to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-core-services-container', 12, 'SafeRoute', 'navigate', 'Safe Route', 'AI-powered safe routes', '#3B82F6', 'home', 'mobile', TRUE, '["safe.route.view"]', '["safe_route:view"]', 'safety', NOW(), NOW());

-- ==============================================================================
-- PART 5: ADD PERMISSIONS TO EXISTING USERS AND ROLES
-- ==============================================================================

-- Add women_safety permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.women.safety.view', true, '$.women.safety.sos', true, '$.women.safety.fakeCall', true, '$.women.safety.siren', true, '$.women.safety.recording', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.women_safety.view', true, '$.women_safety.sos', true, '$.women_safety.fake_call', true, '$.women_safety.siren', true, '$.women_safety.recording', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_map permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.map.view', true, '$.safety.map.report', true, '$.safety.map.vote', true, '$.safe.zone.add', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_map.view', true, '$.safety_map.report', true, '$.safety_map.vote', true, '$.safe_zone.add', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safe_route permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safe.route.view', true, '$.safe.route.create', true, '$.safe.route.history', true, '$.safe.route.favorite', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safe_route.view', true, '$.safe_route.create', true, '$.safe_route.history', true, '$.safe_route.favorite', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add women_safety permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.women.safety.view', true, '$.women.safety.sos', true, '$.women.safety.fakeCall', true, '$.women.safety.siren', true, '$.women.safety.recording', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.women_safety.view', true, '$.women_safety.sos', true, '$.women_safety.fake_call', true, '$.women_safety.siren', true, '$.women_safety.recording', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_map permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.map.view', true, '$.safety.map.report', true, '$.safety.map.vote', true, '$.safe.zone.add', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_map.view', true, '$.safety_map.report', true, '$.safety_map.vote', true, '$.safe_zone.add', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safe_route permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safe.route.view', true, '$.safe.route.create', true, '$.safe.route.history', true, '$.safe.route.favorite', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safe_route.view', true, '$.safe_route.create', true, '$.safe_route.history', true, '$.safe_route.favorite', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ==============================================================================
-- PART 6: ADD SAMPLE DATA
-- ==============================================================================

-- Add sample safety tips
INSERT INTO safety_tips (id, title, content, category, travel_mode, time_of_day, is_active, display_order) VALUES
(UUID(), 'Stay Aware of Your Surroundings', 'Always be aware of your surroundings. Avoid using headphones or looking at your phone while walking, especially in unfamiliar areas.', 'general', 'walking', 'all', TRUE, 1),
(UUID(), 'Trust Your Instincts', 'If something feels wrong, trust your gut feelings. It\'s better to be safe than sorry. Leave the area immediately if you feel unsafe.', 'general', 'all', 'all', TRUE, 2),
(UUID(), 'Share Your Itinerary', 'Always share your travel plans with a trusted friend or family member. Keep them updated on your whereabouts.', 'general', 'all', 'all', TRUE, 3),
(UUID(), 'Use Well-Lit Paths', 'Stick to well-lit, populated areas when walking at night. Avoid shortcuts through dark alleys or isolated areas.', 'walking', 'walking', 'night', TRUE, 4),
(UUID(), 'Keep Emergency Contacts Handy', 'Save emergency contacts on speed dial. Include local police and emergency services numbers.', 'emergency', 'all', 'all', TRUE, 5),
(UUID(), 'Plan Your Route in Advance', 'Before heading out, plan your route and familiarise yourself with the area. Know where police stations and safe zones are located.', 'general', 'all', 'all', TRUE, 6),
(UUID(), 'Avoid Isolated Bus Stops', 'Wait at busy, well-lit bus stops. If possible, travel with a companion during late hours.', 'public_transport', 'transit', 'night', TRUE, 7),
(UUID(), 'Lock Your Vehicle', 'Always lock your car doors and keep windows closed. Never leave valuables visible inside your vehicle.', 'driving', 'driving', 'all', TRUE, 8);

-- ==============================================================================
-- PART 7: VERIFICATION QUERIES
-- ==============================================================================

SELECT 'Women Safety, Safety Map, and Safe Route Modules Migration Completed Successfully!' AS message;

-- Verify tables were created
SELECT TABLE_NAME FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'safety_app' 
AND TABLE_NAME IN (
    'sos_alerts_log', 'sos_location_history', 'fake_call_logs', 'fake_call_settings', 
    'siren_logs', 'recording_logs', 'women_safety_preferences',
    'map_incidents', 'safe_zones', 'area_safety_ratings', 'incident_votes',
    'route_history', 'route_preferences', 'route_waypoints', 'safety_tips'
);

-- Verify menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions 
FROM menus 
WHERE id IN (
    'menu-women-safety', 'menu-safety-map', 'menu-safe-route', 
    'menu-women-safety-fake-call',
    'svc-women-safety', 'svc-safety-map', 'svc-safe-route'
);

-- Verify sample data
SELECT 'safety_tips', COUNT(*) AS record_count FROM safety_tips;
