-- ==============================================================================
-- WOMEN SAFETY APP - MISSING TABLES MIGRATION
-- Created: 2026-03-13
-- Purpose: Add missing tables from safety_app_2026_03_8.sql to safety_dump_2026_03_13.sql
-- Password: Password@123 for all users
-- Bcrypt: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ==============================================================================

USE safety_app;

-- ==============================================================================
-- FAMILIES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS families (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY RELATIONSHIPS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_relationships (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    from_user_id VARCHAR(36) NOT NULL,
    to_user_id VARCHAR(36) NOT NULL,
    relationship_type ENUM('parent', 'child', 'spouse', 'sibling', 'grandparent', 'grandchild', 'other') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_relationship (family_id, from_user_id, to_user_id, relationship_type),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY PLACES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_places (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    place_type ENUM('home', 'school', 'daycare', 'park', 'clinic', 'hospital', 'relative_home', 'work', 'sports', 'other') NOT NULL,
    address TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius_meters INT DEFAULT 100,
    privacy_tag ENUM('do_not_log') DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CONTEXT SNAPSHOTS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS context_snapshots (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    place_id VARCHAR(36),
    place_type VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_type ENUM('arriving', 'leaving', 'dwell', 'transit') DEFAULT 'dwell',
    candidate_context_types JSON,
    confidence DECIMAL(3, 2) DEFAULT 0.50,
    raw_event_ids JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SUGGESTIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS suggestions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    type ENUM('log_activity', 'reminder', 'safety_prompt', 'photo_suggestion') NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    status ENUM('pending', 'shown', 'accepted', 'dismissed', 'snoozed') DEFAULT 'pending',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shown_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL
);

-- ==============================================================================
-- FAMILY ACTIVITY LOGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_activity_logs (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    activity_type VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    started_at TIMESTAMP NOT NULL,
    ended_at TIMESTAMP NULL,
    place_id VARCHAR(36),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- CONSENT SETTINGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS consent_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    location_enabled BOOLEAN DEFAULT FALSE,
    activity_enabled BOOLEAN DEFAULT FALSE,
    calendar_enabled BOOLEAN DEFAULT FALSE,
    analytics_enabled BOOLEAN DEFAULT FALSE,
    family_agent_enabled BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME NULL,
    quiet_hours_end TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- AUDIT LOGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    family_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id VARCHAR(36),
    metadata JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE SET NULL
);

-- ==============================================================================
-- USER THEMES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

-- ==============================================================================
-- PERMISSIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

-- ==============================================================================
-- ROLE PERMISSIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

-- ==============================================================================
-- HOME DEVICES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS home_devices (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    device_type ENUM('light', 'fan', 'ac', 'door', 'camera', 'thermostat', 'plug', 'sensor') NOT NULL,
    room VARCHAR(100) DEFAULT 'Living Room',
    status ENUM('on', 'off') DEFAULT 'off',
    brightness INT DEFAULT 100,
    speed INT DEFAULT 0,
    temperature INT DEFAULT 24,
    is_locked BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- REFRESH TOKENS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CHILD ACTIVITIES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS child_activities (
    id VARCHAR(36) PRIMARY KEY,
    child_id VARCHAR(36) NOT NULL,
    activity_type ENUM('feeding', 'sleep', 'medicine', 'diaper', 'other') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
);

-- ==============================================================================
-- LOCATION HISTORY TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS location_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(6,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GEOFENCES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geofences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius INT DEFAULT 100,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- USER SETTINGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    notification_enabled BOOLEAN DEFAULT TRUE,
    location_sharing BOOLEAN DEFAULT TRUE,
    auto_sos BOOLEAN DEFAULT FALSE,
    shake_to_sos BOOLEAN DEFAULT FALSE,
    sos_timer INT DEFAULT 30,
    shake_sensitivity INT DEFAULT 3,
    volume_press_enabled BOOLEAN DEFAULT FALSE,
    power_press_enabled BOOLEAN DEFAULT FALSE,
    voice_enabled BOOLEAN DEFAULT FALSE,
    auto_sos_enabled BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GEOGRAPHIC AREAS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geographic_areas (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
    parent_area_id VARCHAR(36) DEFAULT NULL,
    code VARCHAR(50) UNIQUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    population INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL
);

-- ==============================================================================
-- USER AREA ASSIGNMENTS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_area_assignments (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    area_id VARCHAR(36) NOT NULL,
    role_in_area ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
    is_primary BOOLEAN DEFAULT FALSE,
    assigned_by VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_area (user_id, area_id, is_primary)
);

-- ==============================================================================
-- SOS CASES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_cases (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    victim_user_id VARCHAR(36),
    victim_name VARCHAR(100),
    victim_phone VARCHAR(20),
    victim_area_id VARCHAR(36),
    status ENUM('pending', 'acknowledged', 'investigating', 'resolved', 'closed', 'escalated') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    category VARCHAR(100),
    description TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address TEXT,
    area_id VARCHAR(36),
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by VARCHAR(36),
    resolution_notes TEXT,
    resolved_at TIMESTAMP NULL,
    resolved_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (victim_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS CASE ACTIVITY LOG (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_case_activity (
    id VARCHAR(36) PRIMARY KEY,
    case_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES sos_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- ROLE ASSIGNMENT HISTORY (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_assignment_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    previous_role VARCHAR(50),
    new_role VARCHAR(50) NOT NULL,
    assigned_by VARCHAR(36),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS ALERTS LOG (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_alerts_log (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type ENUM('sos', 'panic', 'distress', 'emergency') DEFAULT 'sos',
    status ENUM('initiated', 'in_progress', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'initiated',
    latitude DOUBLE,
    longitude DOUBLE,
    address VARCHAR(500),
    accuracy DECIMAL(10,2),
    trigger_method ENUM('button', 'shake', 'voice', 'timer', 'auto') DEFAULT 'button',
    message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- WOMEN SAFETY PREFERENCES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS women_safety_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    sos_enabled BOOLEAN DEFAULT TRUE,
    sos_button_size ENUM('small', 'medium', 'large') DEFAULT 'large',
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_auto_call_enabled BOOLEAN DEFAULT FALSE,
    sos_location_sharing_enabled BOOLEAN DEFAULT TRUE,
    sos_notify_contacts BOOLEAN DEFAULT TRUE,
    sos_message_template TEXT,
    fake_call_enabled BOOLEAN DEFAULT TRUE,
    siren_enabled BOOLEAN DEFAULT TRUE,
    auto_recording_on_sos BOOLEAN DEFAULT TRUE,
    audio_quality ENUM('low', 'medium', 'high') DEFAULT 'high',
    video_quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    shake_to_activate BOOLEAN DEFAULT FALSE,
    voice_activation_enabled BOOLEAN DEFAULT FALSE,
    voice_activation_phrase VARCHAR(100),
    timer_based_sos BOOLEAN DEFAULT FALSE,
    timer_duration_minutes INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    caller_name VARCHAR(100) NOT NULL,
    caller_number VARCHAR(20),
    scheduled_duration INT DEFAULT 30,
    actual_duration INT DEFAULT 0,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    call_status ENUM('scheduled', 'ringing', 'answered', 'missed', 'cancelled', 'completed') DEFAULT 'scheduled',
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    is_automated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL SETTINGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    default_caller_name VARCHAR(100) DEFAULT 'Mom',
    default_caller_number VARCHAR(20),
    default_duration INT DEFAULT 30,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    vibration_enabled BOOLEAN DEFAULT TRUE,
    answer_automatically BOOLEAN DEFAULT FALSE,
    custom_greeting TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SIREN LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS siren_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    siren_type ENUM('panic', 'emergency', 'car', 'custom') DEFAULT 'panic',
    volume_level INT DEFAULT 100,
    duration_seconds INT DEFAULT 0,
    trigger_method ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
    latitude DOUBLE,
    longitude DOUBLE,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- RECORDING LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS recording_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sos_alert_id VARCHAR(36),
    recording_type ENUM('audio', 'video', 'both') DEFAULT 'audio',
    file_path VARCHAR(500),
    file_size BIGINT,
    duration_seconds INT DEFAULT 0,
    format VARCHAR(20) DEFAULT 'm4a',
    quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DOUBLE,
    longitude DOUBLE,
    is_automatically_triggered BOOLEAN DEFAULT FALSE,
    transcription TEXT,
    is_uploaded BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    recording_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recording_ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE SET NULL
);

-- ==============================================================================
-- MAP INCIDENTS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS map_incidents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    incident_type ENUM('harassment', 'assault', 'theft', 'suspicious_activity', 'unsafe_area', 'police_presence', 'accident', 'road_block', 'natural_disaster', 'other') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by VARCHAR(36),
    verification_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    report_count INT DEFAULT 1,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    photo_url VARCHAR(500),
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    tags JSON,
    expires_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SAFE ZONES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safe_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    zone_type ENUM('police_station', 'hospital', 'fire_station', 'public_space', 'cafe', 'shop', 'residential', 'public_transport', 'other') NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500,
    zone_shape ENUM('circle', 'polygon') DEFAULT 'circle',
    polygon_coords JSON,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    amenity_details JSON,
    safety_rating DECIMAL(3,2) DEFAULT 5.00,
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- AREA SAFETY RATINGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS area_safety_ratings (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    center_latitude DOUBLE NOT NULL,
    center_longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 1000,
    overall_rating DECIMAL(3,2) DEFAULT 3.00,
    incident_count INT DEFAULT 0,
    safe_zone_count INT DEFAULT 0,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    rating_breakdown JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INCIDENT VOTES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS incident_votes (
    id VARCHAR(36) PRIMARY KEY,
    incident_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    vote_type ENUM('upvote', 'downvote') DEFAULT 'upvote',
    is_helpful BOOLEAN DEFAULT TRUE,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES map_incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_incident_user_vote (incident_id, user_id)
);

-- ==============================================================================
-- ROUTE HISTORY (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    origin_name VARCHAR(255),
    origin_latitude DOUBLE NOT NULL,
    origin_longitude DOUBLE NOT NULL,
    destination_name VARCHAR(255),
    destination_latitude DOUBLE NOT NULL,
    destination_longitude DOUBLE NOT NULL,
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    route_distance DECIMAL(10,2),
    route_duration INT,
    safety_score DECIMAL(5,2),
    route_path JSON,
    alternative_routes JSON,
    is_favorite BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- ROUTE PREFERENCES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    preferred_travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    avoid_highways BOOLEAN DEFAULT FALSE,
    avoid_tolls BOOLEAN DEFAULT FALSE,
    avoid_ferries BOOLEAN DEFAULT FALSE,
    prefer_lit_streets BOOLEAN DEFAULT TRUE,
    prefer_popular_areas BOOLEAN DEFAULT TRUE,
    minimum_safety_score INT DEFAULT 50,
    maximum_walk_distance INT DEFAULT 2000,
    prefer_alternative_routes BOOLEAN DEFAULT TRUE,
    time_of_day_preference JSON,
    saved_locations JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SAFETY TIPS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_tips (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('general', 'walking', 'driving', 'public_transport', 'night', 'emergency', 'digital') DEFAULT 'general',
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit', 'all') DEFAULT 'all',
    time_of_day ENUM('morning', 'afternoon', 'evening', 'night', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INSERT ROLE PERMISSIONS (ALL 10 ROLES)
-- ==============================================================================

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', 
'{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'admin', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'woman', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- ==============================================================================
-- INSERT USER PERMISSIONS
-- ==============================================================================
INSERT INTO permissions (id, user_id, flags, permissions, ui_restrictions)
SELECT UUID(), id, 
    (SELECT flags FROM role_permissions WHERE role = users.role),
    (SELECT base_permissions FROM role_permissions WHERE role = users.role),
    (SELECT ui_restrictions FROM role_permissions WHERE role = users.role)
FROM users;

-- ==============================================================================
-- INSERT FAMILIES
-- ==============================================================================
INSERT INTO families (id, name, description, created_by) VALUES
('family-001', 'Patel Family', 'Rajesh Patel family', 'user-guardian-001'),
('family-002', 'Sharma Family', 'Priya Sharma family', 'user-guardian-002'),
('family-003', 'Kumar Family', 'Amit and Sneha Kumar family', 'user-parent-001'),
('family-004', 'Singh Family', 'Anjali Singh family', 'user-woman-001');

-- ==============================================================================
-- INSERT FAMILY MEMBERS
-- ==============================================================================
INSERT INTO family_members (id, family_id, user_id, role, nickname) VALUES
('fm-001', 'family-001', 'user-guardian-001', 'head', 'Dad'),
('fm-002', 'family-001', 'user-woman-001', 'member', 'Daughter'),
('fm-003', 'family-002', 'user-guardian-002', 'head', 'Mom'),
('fm-004', 'family-002', 'user-woman-003', 'member', 'Daughter'),
('fm-005', 'family-003', 'user-parent-001', 'head', 'Father'),
('fm-006', 'family-003', 'user-parent-002', 'head', 'Mother'),
('fm-007', 'family-004', 'user-woman-001', 'head', 'Self');

-- ==============================================================================
-- INSERT FAMILY PLACES
-- ==============================================================================
INSERT INTO family_places (id, family_id, name, place_type, address, latitude, longitude, radius_meters, is_active, created_by) VALUES
('fp-001', 'family-001', 'Patel Home', 'home', '123 Main Road, Mumbai', 19.0760, 72.8777, 100, TRUE, 'user-guardian-001'),
('fp-002', 'family-001', 'St. Mary School', 'school', '456 Education Lane, Mumbai', 19.0780, 72.8800, 200, TRUE, 'user-guardian-001'),
('fp-003', 'family-002', 'Sharma Residence', 'home', '789 Oak Street, Delhi', 28.6139, 77.2090, 100, TRUE, 'user-guardian-002'),
('fp-004', 'family-003', 'Kumar House', 'home', '321 Pine Avenue, Bangalore', 12.9716, 77.5946, 100, TRUE, 'user-parent-001');

-- ==============================================================================
-- INSERT GEOGRAPHIC AREAS
-- ==============================================================================
INSERT INTO geographic_areas (id, name, type, code, latitude, longitude, is_active) VALUES
('geo-state-mh', 'Maharashtra', 'state', 'MH', 19.7515, 75.7139, TRUE),
('geo-state-up', 'Uttar Pradesh', 'state', 'UP', 26.8467, 80.9462, TRUE),
('geo-district-mumbai', 'Mumbai', 'district', 'MH-MUM', 19.0760, 72.8777, TRUE),
('geo-district-delhi', 'Delhi', 'district', 'DL-DEL', 28.6139, 77.2090, TRUE);

-- ==============================================================================
-- INSERT USER AREA ASSIGNMENTS
-- ==============================================================================
INSERT INTO user_area_assignments (id, user_id, area_id, role_in_area, is_primary, assigned_by) VALUES
(UUID(), 'user-police-001', 'geo-district-mumbai', 'police', TRUE, 'user-system-admin-001'),
(UUID(), 'user-supervisor-001', 'geo-state-mh', 'supervisor', TRUE, 'user-system-admin-001');

-- ==============================================================================
-- INSERT HOME DEVICES
-- ==============================================================================
INSERT INTO home_devices (id, user_id, name, device_type, room, status, brightness, is_locked) VALUES
('hd-001', 'user-guardian-001', 'Living Room Light', 'light', 'Living Room', 'on', 80, TRUE),
('hd-002', 'user-guardian-001', 'Bedroom Fan', 'fan', 'Bedroom', 'on', 3, TRUE),
('hd-003', 'user-parent-001', 'Baby Room Monitor', 'camera', 'Baby Room', 'on', 0, TRUE);

-- ==============================================================================
-- INSERT GEOFENCES
-- ==============================================================================
INSERT INTO geofences (id, user_id, name, latitude, longitude, radius, is_active) VALUES
('geo-001', 'user-guardian-001', 'Home', 19.0760, 72.8777, 100, TRUE),
('geo-002', 'user-parent-001', 'Home', 12.9716, 77.5946, 100, TRUE);

-- ==============================================================================
-- INSERT LOCATION HISTORY
-- ==============================================================================
INSERT INTO location_history (id, user_id, latitude, longitude, accuracy) VALUES
('lh-001', 'user-woman-001', 13.0827, 80.2707, 10),
('lh-002', 'user-guardian-001', 19.0760, 72.8777, 5);

-- ==============================================================================
-- INSERT USER SETTINGS
-- ==============================================================================
INSERT INTO user_settings (id, user_id, notification_enabled, location_sharing, auto_sos, shake_to_sos, sos_timer, shake_sensitivity)
SELECT UUID(), id, TRUE, TRUE, FALSE, FALSE, 30, 3 FROM users;

-- ==============================================================================
-- INSERT WOMEN SAFETY PREFERENCES
-- ==============================================================================
INSERT INTO women_safety_preferences (id, user_id, sos_enabled, sos_button_size, sos_vibration_enabled, sos_sound_enabled, sos_location_sharing_enabled, fake_call_enabled, siren_enabled)
SELECT UUID(), id, TRUE, 'large', TRUE, TRUE, TRUE, TRUE, TRUE
FROM users WHERE role IN ('woman', 'parent', 'guardian');

-- ==============================================================================
-- INSERT FAKE CALL SETTINGS
-- ==============================================================================
INSERT INTO fake_call_settings (id, user_id, default_caller_name, default_duration, vibration_enabled, is_active)
SELECT UUID(), id, 'Mom', 30, TRUE, TRUE
FROM users WHERE role IN ('woman', 'parent', 'guardian');

-- ==============================================================================
-- INSERT SAFETY TIPS
-- ==============================================================================
INSERT IGNORE INTO safety_tips (id, title, content, category, travel_mode, time_of_day, is_active, display_order) VALUES
('tip-001', 'Stay Aware', 'Always be aware of your surroundings and trust your instincts', 'general', 'all', 'all', TRUE, 1),
('tip-002', 'Share Your Location', 'Keep your location shared with trusted contacts while traveling', 'general', 'walking', 'all', TRUE, 2),
('tip-003', 'Emergency Contacts', 'Keep emergency numbers saved and easily accessible', 'emergency', 'all', 'all', TRUE, 3),
('tip-004', 'Night Safety', 'Stay in well-lit areas and avoid shortcuts through dark alleys', 'walking', 'walking', 'night', TRUE, 4);

-- ==============================================================================
-- INSERT USER THEMES
-- ==============================================================================
INSERT INTO user_themes (id, user_id, theme_id, is_active)
SELECT UUID(), id, (SELECT id FROM themes LIMIT 1), TRUE FROM users;

-- ==============================================================================
-- INSERT CONSENT SETTINGS
-- ==============================================================================
INSERT INTO consent_settings (id, user_id, location_enabled, activity_enabled, family_agent_enabled)
SELECT UUID(), id, FALSE, FALSE, TRUE FROM users;

-- ==============================================================================
-- MIGRATION COMPLETE
-- ==============================================================================
SELECT 'Missing Tables Migration Complete - 2026-03-13' AS message;

-- ==============================================================================
-- END OF MIGRATION FILE
-- ==============================================================================