-- Migration: Add app_settings table for storing app-wide configuration
-- Created: 2026-03-05

-- ============================================
-- APP SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS app_settings (
    id VARCHAR(36) PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add index for fast key lookups
CREATE INDEX IF NOT EXISTS idx_app_settings_key ON app_settings(setting_key);

-- Insert default Groq API key (empty by default, should be updated via admin)
INSERT INTO app_settings (id, setting_key, setting_value, description, is_encrypted) 
VALUES (
    UUID(), 
    'groq_key', 
    '', 
    'Groq API key for AI chat functionality',
    TRUE
) ON DUPLICATE KEY UPDATE setting_key = setting_key;
