-- ==============================================================================
-- BEHAVIOR PATTERN ANALYSIS MODULE - MENU RELOCATION
-- Created: 2026-03-07
-- Description: SQL script to add Behavior Pattern module to Women Safety category
--              and make it prominent in Core Services
-- ==============================================================================

-- ==============================================================================
-- STEP 1: Add Behavior Pattern to Women Safety Menu (under More > Women Safety)
-- ==============================================================================

-- First, check if menu-women-safety exists
SELECT id, name FROM menus WHERE id = 'menu-women-safety';

-- Add Behavior Pattern to Women Safety submenu
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'menu-women-safety-behavior-pattern',
    'Behavior Pattern',
    'secondary',
    TRUE,
    '[]',
    'menu-women-safety',
    4,
    'BehaviorPattern',
    'analytics',
    'Behavior Pattern',
    'Track and analyze behavioral patterns',
    '#6366F1',
    'more',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["behavior.analysis"]',
    'safety'
)
ON DUPLICATE KEY UPDATE 
    label = VALUES(label),
    route = VALUES(route),
    icon = VALUES(icon),
    subtitle = VALUES(subtitle),
    bg_color = VALUES(bg_color),
    required_roles = VALUES(required_roles),
    required_flags = VALUES(required_flags),
    category = VALUES(category);

-- ==============================================================================
-- STEP 2: Add Behavior Pattern to Core Services (Home Screen)
-- ==============================================================================

-- First, check if the Core Services container exists
SELECT id, name FROM menus WHERE id = 'menu-core-services-container';

-- Add Behavior Pattern as a child of Safety Features in Core Services
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'svc-behavior-pattern',
    'Behavior Pattern',
    'secondary',
    TRUE,
    '[]',
    'svc-women-safety',
    2,
    'BehaviorPattern',
    'analytics',
    'Behavior Pattern',
    'Track and analyze behavioral patterns',
    '#6366F1',
    'home',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["behavior.analysis"]',
    'safety'
)
ON DUPLICATE KEY UPDATE 
    label = VALUES(label),
    route = VALUES(route),
    icon = VALUES(icon),
    subtitle = VALUES(subtitle),
    bg_color = VALUES(bg_color),
    required_roles = VALUES(required_roles),
    required_flags = VALUES(required_flags),
    category = VALUES(category);

-- ==============================================================================
-- STEP 3: Update existing Behavior Pattern entry (if under Child Care)
-- ==============================================================================

-- Check and update existing behavior pattern menu under Child Care to also show for women
UPDATE menus 
SET required_roles = '["woman", "parent", "guardian"]',
    category = 'safety'
WHERE id = 'menu-behavior-pattern' 
AND category = 'family';

-- ==============================================================================
-- STEP 4: Verify the entries
-- ==============================================================================

-- Check all Behavior Pattern related entries
SELECT id, name, route, icon, label, subtitle, category, parent_id, required_roles 
FROM menus 
WHERE name LIKE '%Behavior%' OR label LIKE '%Behavior%' OR route = 'BehaviorPattern';

-- Check Women Safety submenu items
SELECT id, name, route, icon, label, menu_order, category 
FROM menus 
WHERE parent_id = 'menu-women-safety' OR parent_id = 'svc-women-safety'
ORDER BY menu_order;

-- Check Core Services safety features
SELECT id, name, route, icon, label, category, parent_id 
FROM menus 
WHERE category = 'safety' AND (purpose = 'home' OR purpose = 'more')
ORDER BY menu_order;
