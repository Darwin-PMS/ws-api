-- Behavior Analysis System Database Migration
-- Creates tables for behavior patterns, anomalies, feedback, alerts, and sensor data

-- ========================
-- Behavior Patterns Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_patterns (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    pattern_type ENUM('route', 'location', 'time', 'activity', 'commute') NOT NULL,
    pattern_name VARCHAR(100),
    pattern_data JSON NOT NULL,
    confidence DECIMAL(3,2) DEFAULT 0.50,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_patterns_user (user_id),
    INDEX idx_patterns_type (pattern_type)
);

-- ========================
-- Anomaly Events Table
-- ========================
CREATE TABLE IF NOT EXISTS anomaly_events (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_type ENUM('unexpected_stop', 'route_deviation', 'unusual_inactivity', 'abnormal_speed', 'sensor_anomaly', 'fall_detected') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    location_name VARCHAR(255),
    accuracy DECIMAL(6,2),
    speed DECIMAL(6,2),
    duration_minutes INT,
    context_data JSON,
    ai_analysis TEXT,
    is_confirmed BOOLEAN DEFAULT NULL,
    confirmed_at TIMESTAMP NULL,
    feedback_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_anomaly_user_time (user_id, created_at),
    INDEX idx_anomaly_type (anomaly_type),
    INDEX idx_anomaly_severity (severity)
);

-- ========================
-- Behavior Feedback Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_feedback (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_id VARCHAR(36) NOT NULL,
    feedback_type ENUM('false_positive', 'accurate', 'needs_review', 'helpful') NOT NULL,
    user_notes TEXT,
    expected_behavior VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (anomaly_id) REFERENCES anomaly_events(id) ON DELETE CASCADE,
    INDEX idx_feedback_anomaly (anomaly_id),
    INDEX idx_feedback_user (user_id)
);

-- ========================
-- Behavior Alerts Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_id VARCHAR(36),
    alert_type ENUM('sos', 'warning', 'notification', 'trusted_contact', 'emergency_service') NOT NULL,
    status ENUM('pending', 'sent', 'delivered', 'acknowledged', 'resolved', 'failed') DEFAULT 'pending',
    recipient_type ENUM('user', 'trusted_contact', 'emergency_service', 'system') NOT NULL,
    recipient_id VARCHAR(36),
    recipient_name VARCHAR(100),
    recipient_phone VARCHAR(20),
    recipient_email VARCHAR(255),
    message TEXT,
    location_latitude DECIMAL(10,8),
    location_longitude DECIMAL(11,8),
    map_link VARCHAR(500),
    response_data JSON,
    sent_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (anomaly_id) REFERENCES anomaly_events(id) ON DELETE SET NULL,
    INDEX idx_alerts_user (user_id),
    INDEX idx_alerts_status (status),
    INDEX idx_alerts_type (alert_type)
);

-- ========================
-- Sensor Data Table
-- ========================
CREATE TABLE IF NOT EXISTS sensor_data (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sensor_type ENUM('accelerometer', 'gyroscope', 'heart_rate', 'steps', 'fall_detect', 'barometer', 'pedometer') NOT NULL,
    data JSON NOT NULL,
    source ENUM('phone', 'smartwatch', 'external') DEFAULT 'phone',
    device_id VARCHAR(100),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sensor_user_time (user_id, recorded_at),
    INDEX idx_sensor_type (sensor_type)
);

-- ========================
-- User Behavior Settings Table
-- ========================
CREATE TABLE IF NOT EXISTS user_behavior_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    monitoring_enabled BOOLEAN DEFAULT TRUE,
    detection_settings JSON DEFAULT JSON_OBJECT(
        'stopDetection', TRUE,
        'routeDeviation', TRUE,
        'inactivityDetection', TRUE,
        'speedAnalysis', TRUE,
        'sensorAnalysis', TRUE
    ),
    sensitivity_settings JSON DEFAULT JSON_OBJECT(
        'level', 'medium',
        'stopDurationMultiplier', 2.0,
        'routeDeviationMultiplier', 1.5,
        'inactivityMultiplier', 1.5
    ),
    alert_settings JSON DEFAULT JSON_OBJECT(
        'alertThreshold', 3,
        'autoAlertContacts', TRUE,
        'alertDelay', 30,
        'severityThreshold', 'medium'
    ),
    notification_settings JSON DEFAULT JSON_OBJECT(
        'pushNotifications', TRUE,
        'smsAlerts', TRUE,
        'soundEnabled', TRUE,
        'vibrationEnabled', TRUE
    ),
    privacy_settings JSON DEFAULT JSON_OBJECT(
        'shareWithContacts', TRUE,
        'shareLocationHistory', FALSE,
        'contributeAnonymizedData', TRUE,
        'allowSensorDataCollection', TRUE
    ),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ========================
-- Trusted Contacts for Behavior Alerts
-- ========================
CREATE TABLE IF NOT EXISTS behavior_trusted_contacts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    contact_id VARCHAR(36) NOT NULL,
    notify_on_anomaly BOOLEAN DEFAULT TRUE,
    notify_on_warning BOOLEAN DEFAULT FALSE,
    notify_on_critical_only BOOLEAN DEFAULT FALSE,
    alert_delay_seconds INT DEFAULT 0,
    contact_priority INT DEFAULT 1,
    custom_message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (contact_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_behavior_contact (user_id, contact_id)
);

-- ========================
-- Location History Enhanced (Extended from existing)
-- ========================
ALTER TABLE location_history 
ADD COLUMN IF NOT EXISTS activity_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS speed_kmh DECIMAL(6,2),
ADD COLUMN IF NOT EXISTS is_stationary BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS place_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS place_id VARCHAR(36);

-- Create index for enhanced location history
CREATE INDEX IF NOT EXISTS idx_location_user_time_activity 
ON location_history(user_id, created_at, activity_type);

-- ========================
-- Context Snapshots Enhanced (Extended from existing)
-- ========================
ALTER TABLE context_snapshots 
ADD COLUMN IF NOT EXISTS context_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS risk_level INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS pattern_matched BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS pattern_id VARCHAR(36),
ADD COLUMN IF NOT EXISTS sensor_data JSON;

-- Insert default behavior settings for existing users
INSERT INTO user_behavior_settings (id, user_id)
SELECT UUID(), id FROM users
WHERE id NOT IN (SELECT user_id FROM user_behavior_settings);

-- Insert default emergency contacts as behavior alert recipients
INSERT INTO behavior_trusted_contacts (id, user_id, contact_id, contact_priority)
SELECT UUID(), u.id, e.id, 99
FROM users u
CROSS JOIN emergency_contacts e
WHERE e.is_primary = TRUE
AND u.id NOT IN (SELECT DISTINCT user_id FROM behavior_trusted_contacts WHERE contact_priority = 99);

-- Create procedure to clean old sensor data
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS cleanup_old_sensor_data()
BEGIN
    DELETE FROM sensor_data 
    WHERE recorded_at < DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    DELETE FROM location_history 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    DELETE FROM anomaly_events 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR)
    AND (is_confirmed = TRUE OR is_confirmed = FALSE);
END //
DELIMITER ;

-- Create event to run cleanup weekly
CREATE EVENT IF NOT EXISTS weekly_sensor_cleanup
ON SCHEDULE EVERY 1 WEEK
DO CALL cleanup_old_sensor_data();

SELECT 'Behavior Analysis tables created successfully' AS result;
