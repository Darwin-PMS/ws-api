-- ============================================
-- SAFETY TUTORIALS, NEWS, AND LAWS MODULE MIGRATION
-- Created: 2026-03-08
-- Purpose: Add Safety Tutorial, News, and Laws modules with menus and permissions
-- ============================================

USE safety_app;

-- ============================================
-- 1. CREATE SAFETY_TUTORIALS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_tutorials (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    video_url VARCHAR(500),
    duration INT DEFAULT 0 COMMENT 'Duration in minutes',
    difficulty ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    is_premium BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_is_active (is_active),
    INDEX idx_difficulty (difficulty)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. CREATE SAFETY_NEWS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_news (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    summary TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    author VARCHAR(100),
    source VARCHAR(200),
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_featured BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_is_featured (is_featured),
    INDEX idx_is_active (is_active),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. CREATE SAFETY_LAWS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_laws (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    jurisdiction VARCHAR(100),
    effective_date DATE,
    penalty TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_jurisdiction (jurisdiction),
    INDEX idx_is_active (is_active),
    INDEX idx_effective_date (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. ADD SAMPLE DATA FOR SAFETY_TUTORIALS
-- ============================================

INSERT INTO safety_tutorials (id, title, description, content, category, image_url, video_url, duration, difficulty, is_premium, is_active) VALUES
(UUID(), 'Self-Defense Basics', 'Learn essential self-defense techniques every woman should know', '<h2>Basic Self-Defense Techniques</h2><p>This tutorial covers fundamental self-defense moves including:</p><ul><li>Palm strike</li><li>Knee defense</li><li>Escaping wrist grabs</li><li>Creating distance</li></ul>', 'self-defense', 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=800', 'https://example.com/videos/self-defense-basics.mp4', 30, 'beginner', FALSE, TRUE),
(UUID(), 'Digital Safety Guide', 'Protect yourself from online threats and harassment', '<h2>Digital Safety Essentials</h2><p>Learn how to:</p><ul><li>Secure your social media accounts</li><li>Recognize phishing attempts</li><li>Protect your personal information</li><li>Handle online harassment</li></ul>', 'digital-safety', 'https://images.unsplash.com/photo-1563206767-5b1d97289374?w=800', 'https://example.com/videos/digital-safety.mp4', 45, 'beginner', FALSE, TRUE),
(UUID(), 'Travel Safety Tips', 'Stay safe while traveling alone', '<h2>Safe Travel Guidelines</h2><p>Essential tips for solo travelers:</p><ul><li>Research your destination</li><li>Share your itinerary</li><li>Choose safe accommodations</li><li>Stay aware of your surroundings</li></ul>', 'travel-safety', 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800', 'https://example.com/videos/travel-safety.mp4', 25, 'beginner', FALSE, TRUE),
(UUID(), 'Emergency Alert Systems', 'How to effectively use emergency alert systems', '<h2>Using Emergency Alerts</h2><p>Master the use of emergency apps and systems:</p><ul><li>SOS button usage</li><li>Location sharing</li><li>Emergency contacts setup</li><li>False alarm prevention</li></ul>', 'emergency', 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800', 'https://example.com/videos/emergency-alerts.mp4', 20, 'beginner', FALSE, TRUE),
(UUID(), 'Workplace Safety', 'Navigate workplace safety concerns confidently', '<h2>Workplace Safety Guide</h2><p>Protect yourself at work:</p><ul><li>Recognize warning signs</li><li>Document incidents properly</li><li>Know your rights</li><li>Build support networks</li></ul>', 'workplace', 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=800', 'https://example.com/videos/workplace-safety.mp4', 35, 'intermediate', FALSE, TRUE),
(UUID(), 'Advanced Self-Defense', 'Advanced techniques for personal protection', '<h2>Advanced Defense Moves</h2><p>For those ready to take their safety skills further:</p><ul><li>Breaking free from chokes</li><li>Using everyday objects for defense</li><li>Ground defense basics</li><li>Multiple attacker awareness</li></ul>', 'self-defense', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800', 'https://example.com/videos/advanced-self-defense.mp4', 60, 'advanced', TRUE, TRUE),
(UUID(), 'Home Security', 'Secure your home from potential threats', '<h2>Home Security Essentials</h2><p>Make your home safer:</p><ul><li>Lock security basics</li><li>Smart home security</li><li>Safe rooms and hiding spots</li><li>Neighborhood safety</li></ul>', 'home-safety', 'https://images.unsplash.com/photo-1558002038-1055907df827?w=800', 'https://example.com/videos/home-security.mp4', 40, 'beginner', FALSE, TRUE);

-- ============================================
-- 5. ADD SAMPLE DATA FOR SAFETY_NEWS
-- ============================================

INSERT INTO safety_news (id, title, summary, content, category, image_url, author, source, published_at, is_featured, is_active, views_count) VALUES
(UUID(), 'New Safety App Launches Nationwide', 'A revolutionary safety application has been launched to help women feel safer in public spaces', '<h2>New Safety App Available</h2><p>A new safety application has been launched nationwide, featuring real-time location sharing, emergency alerts, and community support networks.</p><p>The app aims to reduce response times during emergencies and provide peace of mind for women traveling alone.</p>', 'technology', 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800', 'Sarah Johnson', 'Safety Today', DATE_SUB(NOW(), INTERVAL 1 DAY), TRUE, TRUE, 1520),
(UUID(), 'Government Announces New Women Safety Initiative', 'A comprehensive new program aims to improve public safety infrastructure across major cities', '<h2>Women Safety Initiative 2026</h2><p>The government has announced a new initiative to improve safety in public spaces, including better street lighting, increased police patrols, emergency call boxes in high-risk areas.</p>', 'government', 'https://images.unsplash.com/photo-1575505586569-646b2ca898fc?w=800', 'Priya Sharma', 'National News', DATE_SUB(NOW(), INTERVAL 2 DAY), TRUE, TRUE, 2340),
(UUID(), 'Self-Defense Classes See Surge in Enrollment', 'More women are signing up for self-defense courses following recent safety awareness campaigns', '<h2>Self-Defense Training Popularity Grows</h2><p>Self-defense academies across the country report a 50% increase in enrollment, particularly among young professionals and college students.</p><p>Instructors attribute this to increased awareness about personal safety.</p>', 'lifestyle', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800', 'Mike Chen', 'Health Weekly', DATE_SUB(NOW(), INTERVAL 3 DAY), FALSE, TRUE, 890),
(UUID(), 'Expert Tips for Safe Public Transportation', 'Transportation experts share essential tips for staying safe on buses, trains, and metros', '<h2>Safe Public Transit Guide</h2><p>Safety experts recommend these essential tips:</p><ul><li>Sit near the driver</li><li>Keep belongings secure</li><li>Trust your instincts</li><li>Know your stops</li></ul>', 'transportation', 'https://images.unsplash.com/photo-1542361800-716d50c7c9eb?w=800', 'Anita Rao', 'City Guide', DATE_SUB(NOW(), INTERVAL 4 DAY), FALSE, TRUE, 650),
(UUID(), 'Cyber Safety: Protecting Your Digital Identity', 'Cybersecurity experts warn about rising online threats targeting women', '<h2>Digital Safety Alert</h2><p>With the increase in online activities, cybersecurity experts are warning about new threats targeting women online, including identity theft and harassment.</p><p>Experts recommend using strong passwords and being cautious about sharing personal information.</p>', 'technology', 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800', 'David Kim', 'Tech Security', DATE_SUB(NOW(), INTERVAL 5 DAY), TRUE, TRUE, 1100),
(UUID(), 'Community Watch Programs Expanding', 'Neighborhood watch programs are expanding with new technology integration', '<h2>Modern Community Safety</h2><p>Community watch programs are getting a tech upgrade with real-time reporting apps and neighborhood communication platforms.</p><p>These programs have shown to reduce crime rates by up to 30% in participating areas.</p>', 'community', 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800', 'Lisa Park', 'Local News', DATE_SUB(NOW(), INTERVAL 6 DAY), FALSE, TRUE, 420);

-- ============================================
-- 6. ADD SAMPLE DATA FOR SAFETY_LAWS
-- ============================================

INSERT INTO safety_laws (id, title, description, content, category, jurisdiction, effective_date, penalty, is_active) VALUES
(UUID(), 'Violence Against Women Act', 'Comprehensive legislation protecting women from violence and harassment', '<h2>Violence Against Women Act (VAWA)</h2><p>This landmark legislation provides:</p><ul><li>Protection orders</li><li>Legal representation for victims</li><li>Support services</li><li>Crime victim compensation</li></ul>', 'protection', 'Federal', '1994-09-13', 'Varies by offense - up to life imprisonment for severe cases', TRUE),
(UUID(), 'Workplace Harassment Prevention Law', 'Employers must maintain harassment-free workplace environments', '<h2>Workplace Harassment Prevention</h2><p>Key provisions include:</p><ul><li>Mandatory training programs</li><li>Confidential reporting systems</li><li>Prompt investigation requirements</li><li>Anti-retaliation protections</li></ul>', 'workplace', 'National', '2013-04-04', 'Fines up to $50,000 for first offense, higher for repeat violations', TRUE),
(UUID(), 'Stalking Prevention and Protection Act', 'Laws addressing stalking behavior and providing victim protections', '<h2>Anti-Stalking Legislation</h2><p>This law addresses:</p><ul><li>Electronic surveillance</li><li>Repeated unwanted contact</li><li>Cyber stalking</li><li>Protection order violations</li></ul>', 'harassment', 'State', '2020-01-01', 'Up to 5 years imprisonment and fines up to $10,000', TRUE),
(UUID(), 'Domestic Violence Protection Order', 'Legal mechanism to protect victims of domestic violence', '<h2>Domestic Violence Protection</h2><p>Protection orders can include:</p><ul><li>No-contact orders</li><li>Stay-away orders</li><li>Custody provisions</li><li>Financial support requirements</li></ul>', 'domestic', 'State', '1990-01-01', 'Violation can result in arrest and criminal charges', TRUE),
(UUID(), 'Sexual Harassment Compensation Act', 'Legislation ensuring compensation for sexual harassment victims', '<h2>Compensation for Harassment Victims</h2><p>This act provides:</p><ul><li>Monetary compensation guidelines</li><li>Legal fee coverage</li><li>Lost wages reimbursement</li><li>Emotional distress damages</li></ul>', 'workplace', 'National', '2018-07-01', 'Compensation based on severity and impact', TRUE),
(UUID(), 'Online Harassment Prevention Law', 'Addressing digital harassment and cyberbullying', '<h2>Cyber Harassment Prevention</h2><p>The law covers:</p><ul><li>Online threats</li><li>Cyberbullying</li><li>Non-consensual sharing of content</li><li>Online impersonation</li></ul>', 'digital', 'Federal', '2022-06-15', 'Up to 3 years imprisonment and fines', TRUE);

-- ============================================
-- 7. ADD MENU ENTRIES FOR SAFETY MODULES
-- ============================================

-- Add Safety Tutorials to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-more', 15, 'SafetyTutorial', 'book-open', 'Safety Tutorials', 'Learn essential safety skills', '#8B5CF6', 'more', 'mobile', TRUE, '["safety.tutorial.view"]', '["safety_tutorial:view"]', 'safety', NOW(), NOW());

-- Add Safety News to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-more', 16, 'SafetyNews', 'newspaper', 'Safety News', 'Latest safety news & updates', '#3B82F6', 'more', 'mobile', TRUE, '["safety.news.view"]', '["safety_news:view"]', 'safety', NOW(), NOW());

-- Add Safety Laws to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-more', 17, 'SafetyLaw', 'shield', 'Safety Laws', 'Know your legal rights', '#10B981', 'more', 'mobile', TRUE, '["safety.laws.view"]', '["safety_laws:view"]', 'safety', NOW(), NOW());

-- ============================================
-- 8. ADD MENU ENTRIES TO HOME SECTION (Core Services)
-- ============================================

-- Add Safety Tutorials to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-core-services-container', 20, 'SafetyTutorial', 'book-open', 'Safety Tutorials', 'Learn essential safety skills', '#8B5CF6', 'home', 'mobile', TRUE, '["safety.tutorial.view"]', '["safety_tutorial:view"]', 'safety', NOW(), NOW());

-- Add Safety News to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-core-services-container', 21, 'SafetyNews', 'newspaper', 'Safety News', 'Latest safety news & updates', '#3B82F6', 'home', 'mobile', TRUE, '["safety.news.view"]', '["safety_news:view"]', 'safety', NOW(), NOW());

-- Add Safety Laws to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-core-services-container', 22, 'SafetyLaw', 'shield', 'Safety Laws', 'Know your legal rights', '#10B981', 'home', 'mobile', TRUE, '["safety.laws.view"]', '["safety_laws:view"]', 'safety', NOW(), NOW());

-- ============================================
-- 9. ADD PERMISSIONS FLAGS TO EXISTING USERS
-- ============================================

-- Add safety_tutorial permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.tutorial.view', true, '$.safety.tutorial.create', true, '$.safety.tutorial.edit', true, '$.safety.tutorial.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_tutorial.view', true, '$.safety_tutorial.create', true, '$.safety_tutorial.edit', true, '$.safety_tutorial.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_news permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.news.view', true, '$.safety.news.create', true, '$.safety.news.edit', true, '$.safety.news.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_news.view', true, '$.safety_news.create', true, '$.safety_news.edit', true, '$.safety_news.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_laws permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.laws.view', true, '$.safety.laws.create', true, '$.safety.laws.edit', true, '$.safety.laws.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_laws.view', true, '$.safety_laws.create', true, '$.safety_laws.edit', true, '$.safety_laws.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ============================================
-- 10. ADD PERMISSIONS FLAGS TO ROLE_PERMISSIONS TABLE
-- ============================================

-- Add safety_tutorial permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.tutorial.view', true, '$.safety.tutorial.create', true, '$.safety.tutorial.edit', true, '$.safety.tutorial.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_tutorial.view', true, '$.safety_tutorial.create', true, '$.safety_tutorial.edit', true, '$.safety_tutorial.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_news permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.news.view', true, '$.safety.news.create', true, '$.safety.news.edit', true, '$.safety.news.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_news.view', true, '$.safety_news.create', true, '$.safety_news.edit', true, '$.safety_news.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_laws permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.laws.view', true, '$.safety.laws.create', true, '$.safety.laws.edit', true, '$.safety.laws.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_laws.view', true, '$.safety_laws.create', true, '$.safety_laws.edit', true, '$.safety_laws.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ============================================
-- 11. VERIFICATION QUERIES
-- ============================================

SELECT 'Safety Modules Migration Completed Successfully!' AS message;

-- Verify tables were created
SELECT TABLE_NAME FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'safety_app' 
AND TABLE_NAME IN ('safety_tutorials', 'safety_news', 'safety_laws');

-- Verify sample data
SELECT 'safety_tutorials', COUNT(*) AS record_count FROM safety_tutorials
UNION ALL
SELECT 'safety_news', COUNT(*) FROM safety_news
UNION ALL
SELECT 'safety_laws', COUNT(*) FROM safety_laws;

-- Verify menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions 
FROM menus 
WHERE id IN ('menu-safety-tutorials', 'menu-safety-news', 'menu-safety-laws', 'svc-safety-tutorials', 'svc-safety-news', 'svc-safety-laws');

-- Verify permissions were added
SELECT id, JSON_EXTRACT(flags, '$.safety.tutorial.view') AS tutorial_view,
       JSON_EXTRACT(flags, '$.safety.news.view') AS news_view,
       JSON_EXTRACT(flags, '$.safety.laws.view') AS laws_view
FROM role_permissions;
