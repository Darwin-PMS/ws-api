-- Migration: Add themes, menus, and permissions tables
-- Created: 2026-03-04

-- ============================================
-- THEMES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS themes (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    config JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add index for active themes
CREATE INDEX IF NOT EXISTS idx_themes_active ON themes(is_active);
CREATE INDEX IF NOT EXISTS idx_themes_default ON themes(is_default);

-- ============================================
-- USER THEMES TABLE (User-Theme assignments)
-- ============================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

CREATE INDEX IF NOT EXISTS idx_user_themes_user ON user_themes(user_id);
CREATE INDEX IF NOT EXISTS idx_user_themes_theme ON user_themes(theme_id);

-- ============================================
-- MENUS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('primary', 'secondary', 'footer', 'sidebar') DEFAULT 'primary',
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_menus_type ON menus(type);
CREATE INDEX IF NOT EXISTS idx_menus_active ON menus(is_active);

-- ============================================
-- PERMISSIONS TABLE (User-specific permissions)
-- ============================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

CREATE INDEX IF NOT EXISTS idx_permissions_user ON permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_permissions_expires ON permissions(expires_at);

-- ============================================
-- ROLE PERMISSIONS TABLE (Role templates)
-- ============================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

CREATE INDEX IF NOT EXISTS idx_role_permissions_role ON role_permissions(role);

-- ============================================
-- INSERT DEFAULT THEMES
-- ============================================
INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-dark-default', 'Dark Default', 'Default dark theme with purple accents', TRUE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "secondaryLight": "#F472B6",
        "secondaryDark": "#DB2777",
        "background": "#0F0F14",
        "backgroundLight": "#1A1A24",
        "backgroundLighter": "#252532",
        "surface": "#1E1E2C",
        "surfaceElevated": "#252532",
        "glass": "rgba(30, 30, 44, 0.7)",
        "glassBorder": "rgba(139, 92, 246, 0.2)",
        "glassHighlight": "rgba(139, 92, 246, 0.1)",
        "text": "#FFFFFF",
        "textSecondary": "#A1A1AA",
        "textMuted": "#71717A",
        "textAccent": "#C4B5FD",
        "success": "#10B981",
        "warning": "#F59E0B",
        "error": "#EF4444",
        "danger": "#EF4444",
        "info": "#3B82F6",
        "userBubble": "#7C3AED",
        "aiBubble": "#1E1E2C",
        "aiBubbleBorder": "#3F3F5A",
        "card": "#1E1E2C",
        "tabBarBackground": "#14141B",
        "tabBarActive": "#8B5CF6",
        "tabBarInactive": "#71717A",
        "border": "#3F3F5A",
        "borderLight": "#27273A",
        "overlay": "rgba(0, 0, 0, 0.6)"
    },
    "typography": {
        "fontFamily": { "regular": "System", "medium": "System", "bold": "System" },
        "fontSize": { "xs": 10, "sm": 12, "md": 14, "lg": 16, "xl": 18, "xxl": 24, "xxxl": 32, "title": 28 },
        "fontWeight": { "regular": "400", "medium": "500", "semibold": "600", "bold": "700" },
        "lineHeight": { "tight": 1.2, "normal": 1.5, "relaxed": 1.75 }
    },
    "spacing": { "xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32, "xxl": 48 },
    "borderRadius": { "sm": 8, "md": 12, "lg": 16, "xl": 24, "full": 9999 },
    "shadows": {
        "sm": { "shadowColor": "#000", "shadowOffset": { "width": 0, "height": 2 }, "shadowOpacity": 0.1, "shadowRadius": 4, "elevation": 2 },
        "md": { "shadowColor": "#000", "shadowOffset": { "width": 0, "height": 4 }, "shadowOpacity": 0.15, "shadowRadius": 8, "elevation": 4 },
        "lg": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 8 }, "shadowOpacity": 0.25, "shadowRadius": 16, "elevation": 8 },
        "glow": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 0 }, "shadowOpacity": 0.5, "shadowRadius": 20, "elevation": 10 }
    }
}
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    description = VALUES(description),
    config = VALUES(config);

INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-light-default', 'Light Default', 'Default light theme', FALSE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "secondaryLight": "#F472B6",
        "secondaryDark": "#DB2777",
        "background": "#F8FAFC",
        "backgroundLight": "#F1F5F9",
        "backgroundLighter": "#E2E8F0",
        "surface": "#FFFFFF",
        "surfaceElevated": "#FFFFFF",
        "glass": "rgba(255, 255, 255, 0.8)",
        "glassBorder": "rgba(139, 92, 246, 0.15)",
        "glassHighlight": "rgba(139, 92, 246, 0.05)",
        "text": "#1E293B",
        "textSecondary": "#64748B",
        "textMuted": "#94A3B8",
        "textAccent": "#7C3AED",
        "success": "#059669",
        "warning": "#D97706",
        "error": "#DC2626",
        "danger": "#DC2626",
        "info": "#2563EB",
        "userBubble": "#7C3AED",
        "aiBubble": "#F1F5F9",
        "aiBubbleBorder": "#E2E8F0",
        "card": "#FFFFFF",
        "tabBarBackground": "#FFFFFF",
        "tabBarActive": "#8B5CF6",
        "tabBarInactive": "#94A3B8",
        "border": "#E2E8F0",
        "borderLight": "#F1F5F9",
        "overlay": "rgba(0, 0, 0, 0.4)"
    },
    "typography": {
        "fontFamily": { "regular": "System", "medium": "System", "bold": "System" },
        "fontSize": { "xs": 10, "sm": 12, "md": 14, "lg": 16, "xl": 18, "xxl": 24, "xxxl": 32, "title": 28 },
        "fontWeight": { "regular": "400", "medium": "500", "semibold": "600", "bold": "700" },
        "lineHeight": { "tight": 1.2, "normal": 1.5, "relaxed": 1.75 }
    },
    "spacing": { "xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32, "xxl": 48 },
    "borderRadius": { "sm": 8, "md": 12, "lg": 16, "xl": 24, "full": 9999 },
    "shadows": {
        "sm": { "shadowColor": "#1E293B", "shadowOffset": { "width": 0, "height": 2 }, "shadowOpacity": 0.1, "shadowRadius": 4, "elevation": 2 },
        "md": { "shadowColor": "#1E293B", "shadowOffset": { "width": 0, "height": 4 }, "shadowOpacity": 0.15, "shadowRadius": 8, "elevation": 4 },
        "lg": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 8 }, "shadowOpacity": 0.25, "shadowRadius": 16, "elevation": 8 },
        "glow": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 0 }, "shadowOpacity": 0.5, "shadowRadius": 20, "elevation": 10 }
    }
}
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    description = VALUES(description),
    config = VALUES(config);

-- ============================================
-- INSERT DEFAULT MENUS
-- ============================================
INSERT INTO menus (id, name, type, is_active, items) VALUES
('menu-primary-default', 'Primary Navigation', 'primary', TRUE, '
[
    { "id": "nav-home", "label": "Home", "icon": "home", "route": "Home", "order": 1, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] },
    { "id": "nav-notifications", "label": "Alerts", "icon": "notifications", "route": "Notifications", "order": 2, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin"], "badge": { "type": "count", "source": "/api/notifications/unread-count" } },
    { "id": "nav-ai-chat", "label": "AI Chat", "icon": "chatbubbles", "route": "AIChat", "order": 3, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"], "requiredFlags": ["ai.chat"], "requiredPermissions": ["ai:read"] },
    { "id": "nav-more", "label": "More", "icon": "menu", "route": "More", "order": 4, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] },
    { "id": "nav-profile", "label": "Profile", "icon": "person", "route": "Profile", "order": 5, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] }
]
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    items = VALUES(items);

INSERT INTO menus (id, name, type, is_active, items) VALUES
('menu-secondary-default', 'Core Services', 'secondary', TRUE, '
[
    { "id": "svc-women-safety", "label": "Women Safety", "subtitle": "SOS, emergency contacts & safety tips", "icon": "shield-checkmark", "color": "#EC4899", "screen": "WomenSafety", "order": 1, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian"], "requiredFlags": ["sos.emergency"], "category": "safety" },
    { "id": "svc-child-care", "label": "Child Care", "subtitle": "Tips, guidance & assistant", "icon": "happy", "color": "#10B981", "screen": "ChildCare", "order": 2, "isVisible": true, "requiredRoles": ["parent", "guardian"], "category": "family" },
    { "id": "svc-family", "label": "Family", "subtitle": "Manage family members & relationships", "icon": "people", "color": "#EC4899", "screen": "Family", "order": 3, "isVisible": true, "requiredRoles": ["parent", "guardian", "admin"], "requiredFlags": ["family.tracking"], "requiredPermissions": ["family:read"], "category": "family" },
    { "id": "svc-home-automation", "label": "Home Automation", "subtitle": "Control smart devices & appliances", "icon": "home", "color": "#3B82F6", "screen": "HomeAutomation", "order": 4, "isVisible": true, "requiredFlags": ["home.automation"], "requiredPermissions": ["automation:read"], "category": "lifestyle" },
    { "id": "svc-vision", "label": "Vision", "subtitle": "Image analysis with AI", "icon": "camera", "color": "#8B5CF6", "screen": "Vision", "order": 5, "isVisible": true, "requiredFlags": ["ai.vision"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-speech", "label": "Speech to Text", "subtitle": "Transcribe audio with AI", "icon": "mic", "color": "#10B981", "screen": "Speech", "order": 6, "isVisible": true, "requiredFlags": ["ai.speech"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-tts", "label": "Text to Speech", "subtitle": "Convert text to speech", "icon": "volume-high", "color": "#F59E0B", "screen": "TTS", "order": 7, "isVisible": true, "requiredFlags": ["ai.tts"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-models", "label": "Model Browser", "subtitle": "Browse and select AI models", "icon": "server", "color": "#8B5CF6", "screen": "ModelsList", "order": 8, "isVisible": true, "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-settings", "label": "Settings", "subtitle": "API key, preferences & about", "icon": "settings", "color": "#F59E0B", "screen": "Settings", "order": 9, "isVisible": true, "requiredPermissions": ["settings:read"], "category": "system" },
    { "id": "svc-profile", "label": "My Profile", "subtitle": "View & edit your profile", "icon": "person", "color": "#8B5CF6", "screen": "Profile", "order": 10, "isVisible": true, "requiredPermissions": ["users:read"], "category": "system" }
]
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    items = VALUES(items);

-- ============================================
-- INSERT DEFAULT ROLE PERMISSIONS
-- ============================================
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-admin', 'admin', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true }
', '
{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true } }
', '
{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-guardian', 'guardian', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": false }, "automation": { "read": true, "write": true } }
', '
{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": ["bulk-export"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-parent', 'parent', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "automation": { "read": false, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-woman', 'woman', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-friend', 'friend', '
{ "sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": false, "view_history": false }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Migration complete
SELECT 'Migration 001: themes, menus, permissions tables created successfully' as message;
