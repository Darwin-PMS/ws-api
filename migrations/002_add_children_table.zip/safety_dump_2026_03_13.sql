-- ==============================================================================
-- WOMEN SAFETY APP - COMPLETE DATABASE DUMP
-- Created: 2026-03-13
-- Database: safety_app
-- Version: 1.0.0 (Post-Compliance Update)
-- 
-- IMPORTANT: Password for ALL users is: Password@123
-- Bcrypt Hash: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ==============================================================================

-- ==============================================================================
-- DATABASE CREATION
-- ==============================================================================
CREATE DATABASE IF NOT EXISTS safety_app;
USE safety_app;

-- ==============================================================================
-- USERS TABLE (Updated with all 10 roles)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend') DEFAULT 'woman',
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    verification_code VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- USER CONSENT RECORDS (DPDP Act Compliance - Rule 6)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_consents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    consent_type VARCHAR(50) NOT NULL,
    consent_given BOOLEAN DEFAULT FALSE,
    consent_timestamp DATETIME,
    withdrawal_timestamp DATETIME,
    purpose TEXT,
    data_categories TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- DATA BREACH RECORDS (DPDP Act Compliance)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS data_breach_records (
    id VARCHAR(36) PRIMARY KEY,
    breach_description TEXT,
    breach_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    affected_users_count INT DEFAULT 0,
    data_categories_affected TEXT,
    remedial_actions TEXT,
    reported_to_board BOOLEAN DEFAULT FALSE,
    board_notification_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- GRIEVANCE RECORDS (IT Rules 2021 Compliance)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS grievances (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    complaint_type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    name VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(255),
    status ENUM('pending', 'acknowledged', 'in_progress', 'resolved', 'escalated', 'closed') DEFAULT 'pending',
    assigned_to VARCHAR(36),
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at DATETIME,
    resolved_at DATETIME,
    user_satisfaction BOOLEAN,
    appeal_to_gac BOOLEAN DEFAULT FALSE,
    gac_decision TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- EMERGENCY CONTACTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    relationship VARCHAR(50),
    is_primary BOOLEAN DEFAULT FALSE,
    notes TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    contact_type ENUM('personal', 'family', 'friend', 'work', 'emergency') DEFAULT 'personal',
    priority INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- DEFAULT EMERGENCY CONTACTS (System-wide - Government Helplines)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS default_emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description VARCHAR(255),
    country VARCHAR(50) DEFAULT 'India',
    service_type VARCHAR(50) DEFAULT 'emergency',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    icon VARCHAR(50),
    category ENUM('police', 'women_helpline', 'cybercrime', 'medical', 'fire', 'child', 'general') DEFAULT 'general',
    available_24_7 BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- USER EMERGENCY PREFERENCES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_emergency_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    enable_sos BOOLEAN DEFAULT TRUE,
    auto_share_location BOOLEAN DEFAULT FALSE,
    notify_emergency_contacts BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    shake_to_sos_enabled BOOLEAN DEFAULT TRUE,
    shake_count_required INT DEFAULT 5,
    emergency_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preferences (user_id)
);

-- ==============================================================================
-- SOS ALERTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DOUBLE,
    longitude DOUBLE,
    address TEXT,
    accuracy DOUBLE,
    status ENUM('initiated', 'sent', 'acknowledged', 'cancelled', 'resolved') DEFAULT 'initiated',
    alert_type ENUM('manual', 'shake', 'auto', 'scheduled') DEFAULT 'manual',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SOS LOCATION HISTORY
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_location_history (
    id VARCHAR(36) PRIMARY KEY,
    sos_id VARCHAR(36) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    accuracy DOUBLE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_id) REFERENCES sos_alerts(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GUARDIANS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS guardians (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    guardian_id VARCHAR(36) NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY MEMBERS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_members (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    member_name VARCHAR(100) NOT NULL,
    relationship VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(255),
    is_primary BOOLEAN DEFAULT FALSE,
    share_location BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY LOCATIONS TABLE (Real-time Location Sharing)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_locations (
    id VARCHAR(36) PRIMARY KEY,
    family_member_id VARCHAR(36) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    accuracy DOUBLE,
    address TEXT,
    battery_level INT,
    is_active BOOLEAN DEFAULT TRUE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_member_id) REFERENCES family_members(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SAFETY ZONES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    name VARCHAR(100) NOT NULL,
    zone_type ENUM('safe', 'unsafe', 'caution') DEFAULT 'safe',
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- INCIDENT REPORTS TABLE (Community Safety)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS incident_reports (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    incident_type ENUM('harassment', 'assault', 'stalking', 'theft', 'suspicious', 'safe', 'other') NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address TEXT,
    is_anonymous BOOLEAN DEFAULT FALSE,
    status ENUM('pending', 'verified', 'resolved', 'false') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SAFETY NEWS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_news (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50),
    source VARCHAR(100),
    image_url VARCHAR(500),
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE
);

-- ==============================================================================
-- SAFETY LAWS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_laws (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50),
    penalty TEXT,
    section VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- SAFETY TUTORIALS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_tutorials (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50),
    difficulty ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    duration_minutes INT,
    image_url VARCHAR(500),
    video_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- BEHAVIOR ANALYSIS TABLES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS behavior_routines (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    routine_name VARCHAR(100),
    location_type VARCHAR(50),
    typical_start_time TIME,
    typical_end_time TIME,
    days_of_week VARCHAR(20),
    confidence_score DOUBLE DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS behavior_anomalies (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_type VARCHAR(50),
    description TEXT,
    latitude DOUBLE,
    longitude DOUBLE,
    deviation_score DOUBLE,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS behavior_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type VARCHAR(50) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT,
    latitude DOUBLE,
    longitude DOUBLE,
    severity ENUM('low', 'medium', 'high') DEFAULT 'medium',
    is_read BOOLEAN DEFAULT FALSE,
    is_resolved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS behavior_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_detection_enabled BOOLEAN DEFAULT TRUE,
    routine_learning_enabled BOOLEAN DEFAULT TRUE,
    alert_notifications_enabled BOOLEAN DEFAULT TRUE,
    low_confidence_threshold DOUBLE DEFAULT 0.3,
    anomaly_sensitivity ENUM('low', 'medium', 'high') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_behavior_settings (user_id)
);

-- ==============================================================================
-- CYLINDER VERIFICATION TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS cylinder_verifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    cylinder_number VARCHAR(50),
    verification_result ENUM('genuine', 'suspected', 'invalid') DEFAULT 'pending',
    confidence_score DOUBLE,
    manufacturer VARCHAR(100),
    expiry_date DATE,
    region VARCHAR(50),
    image_url VARCHAR(500),
    verification_type VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- THOUGHT GENERATOR RECORDS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS thought_records (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    situation_type VARCHAR(50),
    generated_response TEXT,
    tone VARCHAR(50),
    is_favorite BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- APP SETTINGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS app_settings (
    id VARCHAR(36) PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(20) DEFAULT 'string',
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- THEMES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS themes (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    is_dark BOOLEAN DEFAULT FALSE,
    colors JSON,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- MENUS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(50),
    path VARCHAR(200),
    parent_id VARCHAR(36),
    display_order INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    roles JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- ROLES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS roles (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description TEXT,
    permissions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==============================================================================
-- CHILDREN TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS children (
    id VARCHAR(36) PRIMARY KEY,
    parent_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(20),
    school_name VARCHAR(200),
    grade VARCHAR(20),
    emergency_contact VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CONTENT FLAGS (For Moderation - IT Rules 2021)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS content_flags (
    id VARCHAR(36) PRIMARY KEY,
    reporter_id VARCHAR(36),
    content_type VARCHAR(50),
    content_id VARCHAR(36),
    reason VARCHAR(50),
    description TEXT,
    status ENUM('pending', 'reviewed', 'action_taken', 'dismissed') DEFAULT 'pending',
    reviewed_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- NCII (Non-Consensual Intimate Image) REPORTS - IT Rules 2026
-- ==============================================================================
CREATE TABLE IF NOT EXISTS ncii_reports (
    id VARCHAR(36) PRIMARY KEY,
    reporter_id VARCHAR(36),
    victim_id VARCHAR(36),
    content_description TEXT,
    platform_origin VARCHAR(100),
    status ENUM('pending', 'verified', 'removed', 'escalated') DEFAULT 'pending',
    removal_requested BOOLEAN DEFAULT FALSE,
    law_enforcement_notified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SYNTHETIC CONTENT REGISTRY (Deepfakes - IT Rules 2026)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS synthetic_content_registry (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    content_hash VARCHAR(100),
    content_type VARCHAR(50),
    is_ai_generated BOOLEAN DEFAULT FALSE,
    ai_disclosure_status ENUM('disclosed', 'undisclosed', 'pending_review') DEFAULT 'pending_review',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- INSERT DEFAULT DATA - GOVERNMENT HELPLINES (India)
-- ==============================================================================
INSERT INTO default_emergency_contacts (id, name, phone, description, service_type, category, display_order, icon, available_24_7) VALUES
(UUID(), 'Police Emergency', '112', 'All emergency services - Police, Fire, Ambulance', 'emergency', 'police', 1, 'call-emergency', TRUE),
(UUID(), 'Women Helpline', '1091', 'For women in distress - 24/7 support', 'emergency', 'women_helpline', 2, 'woman', TRUE),
(UUID(), 'Cybercrime Helpline', '1930', 'Report cybercrimes and online fraud - 24/7', 'emergency', 'cybercrime', 3, 'globe', TRUE),
(UUID(), 'National Emergency', '112', 'Pan-India emergency response system', 'emergency', 'police', 4, 'alert-circle', TRUE),
(UUID(), 'Child Helpline', '1098', 'For children in need of care and protection', 'emergency', 'child', 5, 'people', TRUE),
(UUID(), 'Senior Citizen Helpline', '1450', 'Assistance for elderly persons', 'emergency', 'general', 6, 'heart', TRUE),
(UUID(), 'Women & Child Helpline', '181', 'Women and child helpline', 'emergency', 'women_helpline', 7, 'women', TRUE);

-- ==============================================================================
-- INSERT DEFAULT ROLES
-- ==============================================================================
INSERT INTO roles (id, name, description, permissions) VALUES
(UUID(), 'system_admin', 'System Administrator with full access', JSON_ARRAY('all')),
(UUID(), 'agency_admin', 'Agency-level administrator', JSON_ARRAY('manage_users', 'view_reports', 'manage_settings')),
(UUID(), 'admin', 'App Administrator', JSON_ARRAY('manage_users', 'view_reports')),
(UUID(), 'supervisor', 'Supervisor with monitoring access', JSON_ARRAY('view_reports', 'manage_alerts')),
(UUID(), 'local_police', 'Local Police Officer', JSON_ARRAY('view_reports', 'receive_alerts')),
(UUID(), 'village_head', 'Village Head/Leader', JSON_ARRAY('view_reports', 'manage_community')),
(UUID(), 'guardian', 'Guardian for minor/dependent', JSON_ARRAY('monitor', 'view_location')),
(UUID(), 'parent', 'Parent of child user', JSON_ARRAY('monitor', 'view_location', 'manage_child')),
(UUID(), 'woman', 'Women Safety App User', JSON_ARRAY('use_features', 'report_incident')),
(UUID(), 'friend', 'Trusted Friend Contact', JSON_ARRAY('receive_alerts'));

-- ==============================================================================
-- INSERT DEFAULT MENUS
-- ==============================================================================
INSERT INTO menus (id, name, icon, path, display_order, is_active, roles) VALUES
(UUID(), 'Home', 'home', '/home', 1, TRUE, JSON_ARRAY('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend')),
(UUID(), 'Notifications', 'notifications', '/notifications', 2, TRUE, JSON_ARRAY('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend')),
(UUID(), 'AI Chat', 'chatbubbles', '/chat', 3, TRUE, JSON_ARRAY('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend')),
(UUID(), 'Women Safety', 'shield-checkmark', '/women-safety', 4, TRUE, JSON_ARRAY('woman', 'parent', 'guardian')),
(UUID(), 'Emergency Helplines', 'call', '/emergency-helplines', 5, TRUE, JSON_ARRAY('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend')),
(UUID(), 'Safety Map', 'map', '/safety-map', 6, TRUE, JSON_ARRAY('woman', 'parent', 'guardian', 'local_police', 'village_head')),
(UUID(), 'Safe Route', 'navigate', '/safe-route', 7, TRUE, JSON_ARRAY('woman', 'parent', 'guardian')),
(UUID(), 'Fake Call', 'call-outline', '/fake-call', 8, TRUE, JSON_ARRAY('woman', 'parent', 'guardian')),
(UUID(), 'Family', 'people', '/family', 9, TRUE, JSON_ARRAY('woman', 'parent', 'guardian')),
(UUID(), 'Child Care', 'happy', '/child-care', 10, TRUE, JSON_ARRAY('parent', 'guardian')),
(UUID(), 'Safety News', 'newspaper', '/safety-news', 11, TRUE, JSON_ARRAY('woman', 'parent', 'guardian', 'local_police', 'village_head')),
(UUID(), 'Safety Laws', 'book', '/safety-laws', 12, TRUE, JSON_ARRAY('woman', 'parent', 'guardian', 'local_police', 'village_head')),
(UUID(), 'Safety Tutorials', 'play-circle', '/safety-tutorials', 13, TRUE, JSON_ARRAY('woman', 'parent', 'guardian')),
(UUID(), 'Settings', 'settings', '/settings', 14, TRUE, JSON_ARRAY('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend'));

-- ==============================================================================
-- INSERT DEFAULT APP SETTINGS
-- ==============================================================================
INSERT INTO app_settings (setting_key, setting_value, setting_type, description) VALUES
('app_name', 'Women Safety App', 'string', 'Application name'),
('app_version', '1.0.0', 'string', 'Current app version'),
('max_emergency_contacts', '5', 'number', 'Maximum emergency contacts per user'),
('sos_shake_count', '5', 'number', 'Number of shakes required to trigger SOS'),
('sos_time_window', '3000', 'number', 'Time window for shake detection in milliseconds'),
('location_update_interval', '30000', 'number', 'Location update interval in milliseconds'),
('location_retention_days', '90', 'number', 'Days to retain location history'),
('grievance_response_hours', '24', 'number', 'Hours to acknowledge grievance'),
('grievance_resolution_days', '15', 'number', 'Days to resolve grievance'),
('ncii_removal_hours', '24', 'number', 'Hours to remove NCII content'),
('content_takedown_hours', '3', 'number', 'Hours to take down unlawful content'),
('breach_notification_hours', '72', 'number', 'Hours to notify Data Protection Board'),
('cert_in_reporting_hours', '6', 'number', 'Hours to report to CERT-In'),
('enable_shake_sos', 'true', 'boolean', 'Enable shake to trigger SOS'),
('enable_background_location', 'true', 'boolean', 'Enable background location tracking'),
('enable_face_recognition', 'false', 'boolean', 'Enable facial recognition'),
('default_theme', 'light', 'string', 'Default app theme'),
('maintenance_mode', 'false', 'boolean', 'Enable maintenance mode'),
('cybercrime_url', 'https://cybercrime.gov.in', 'string', 'Cybercrime reporting portal URL'),
('shebox_url', 'https://shebox.nic.in', 'string', 'SHe-Box portal URL'),
('cert_in_email', 'incident@cert-in.org.in', 'string', 'CERT-In incident email');

-- ==============================================================================
-- INSERT DEFAULT THEME
-- ==============================================================================
INSERT INTO themes (id, name, is_dark, colors, is_default) VALUES
(UUID(), 'Light', FALSE, '{"primary": "#6200EE", "secondary": "#03DAC6", "background": "#FFFFFF", "surface": "#F5F5F5", "error": "#B00020", "text": "#000000", "textSecondary": "#666666"}', TRUE),
(UUID(), 'Dark', TRUE, '{"primary": "#BB86FC", "secondary": "#03DAC6", "background": "#121212", "surface": "#1E1E1E", "error": "#CF6679", "text": "#FFFFFF", "textSecondary": "#B0B0B0"}', FALSE);

-- ==============================================================================
-- INSERT SAMPLE SAFETY NEWS
-- ==============================================================================
INSERT INTO safety_news (id, title, content, category, source, published_at) VALUES
(UUID(), 'Government Launches New Women Safety Portal', 'The Ministry of Women and Child Development has launched a new portal for women safety. The portal provides resources for safety tips, emergency contacts, and legal information.', 'government', 'PIB', NOW()),
(UUID(), 'Cybercrime Cases Rising - Stay Safe Online', 'Cybercrime against women has increased by 40%. Experts advise not to share personal photos online and to report any harassment immediately to cybercrime.gov.in', 'advisory', 'Cyber Crime Unit', NOW()),
(UUID(), 'New Safety App Features Released', 'The latest update includes shake-to-SOS, live location sharing, and integration with local police control rooms for faster response.', 'app_update', 'Women Safety App', NOW());

-- ==============================================================================
-- INSERT SAMPLE SAFETY LAWS
-- ==============================================================================
INSERT INTO safety_laws (id, title, description, category, penalty) VALUES
(UUID(), 'Section 354A IPC', 'Sexual harassment and punishment for harassment', 'criminal', 'Imprisonment up to 3 years or fine'),
(UUID(), 'Section 354D IPC', 'Stalking - following or contacting a woman repeatedly', 'criminal', 'Imprisonment up to 3 years for first offense'),
(UUID(), 'Section 509 IPC', 'Word, gesture or act intended to insult woman\'s modesty', 'criminal', 'Imprisonment up to 1 year or fine'),
(UUID(), 'IT Act Section 66E', 'Violation of privacy - publishing/transmitting person\'s private parts', 'cyber', 'Imprisonment up to 3 years and fine'),
(UUID(), 'IT Act Section 67', 'Publishing or transmitting obscene material', 'cyber', 'Imprisonment up to 3 years and fine'),
(UUID(), 'DPDP Act 2023', 'Digital Personal Data Protection - Right to privacy', 'data_protection', 'Penalty up to ₹250 crore');

-- ==============================================================================
-- INSERT SAMPLE SAFETY TUTORIALS
-- ==============================================================================
INSERT INTO safety_tutorials (id, title, content, category, difficulty, duration_minutes) VALUES
(UUID(), 'How to Use SOS Feature', 'Learn how to trigger emergency alerts and notify your emergency contacts with your live location.', 'features', 'beginner', 5),
(UUID(), 'Setting Up Emergency Contacts', 'Step-by-step guide to adding and managing your emergency contacts.', 'features', 'beginner', 3),
(UUID(), 'Using Fake Call Feature', 'Learn how to use the fake call feature to get out of uncomfortable situations.', 'self_defense', 'beginner', 4),
(UUID(), 'Reporting Cybercrime', 'How to report cybercrimes on cybercrime.gov.in and what information to provide.', 'online_safety', 'intermediate', 6),
(UUID(), 'Shake to SOS Setup', 'Enable shake-to-SOS for hands-free emergency alerts. Shake your phone 5 times quickly.', 'features', 'beginner', 2),
(UUID(), 'Safety Apps Comparison', 'Compare different women safety apps and their features.', 'resources', 'intermediate', 8);

-- ==============================================================================
-- SAMPLE USERS (Password: Password@123 for all)
-- ==============================================================================
INSERT INTO users (id, first_name, last_name, email, phone, password, role, is_verified) VALUES
(UUID(), 'Admin', 'User', 'admin@safetyapp.in', '9876543210', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'system_admin', TRUE),
(UUID(), 'Test', 'Woman', 'woman@test.com', '9876543211', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE),
(UUID(), 'Test', 'Parent', 'parent@test.com', '9876543212', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'parent', TRUE);

-- ==============================================================================
-- END OF DUMP FILE
-- ==============================================================================
-- Generated: 2026-03-13
-- Women Safety App Database Dump Complete
-- ==============================================================================
