-- ==============================================================================
-- EMERGENCY CONTACTS: DEFAULT AND USER-SPECIFIC
-- Created: 2026-03-05
-- Purpose: Support both default emergency numbers and user-specific contacts
-- ==============================================================================

-- ==============================================================================
-- STEP 1: CREATE DEFAULT EMERGENCY CONTACTS TABLE (System-wide)
-- ==============================================================================

CREATE TABLE IF NOT EXISTS default_emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description VARCHAR(255),
    country VARCHAR(50) DEFAULT 'India',
    service_type VARCHAR(50) DEFAULT 'emergency',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- STEP 2: UPDATE USER EMERGENCY CONTACTS TABLE
-- ==============================================================================

-- Add new columns to emergency_contacts table if not exists
ALTER TABLE emergency_contacts 
ADD COLUMN IF NOT EXISTS notes TEXT,
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS contact_type ENUM('personal', 'family', 'friend', 'work', 'emergency') DEFAULT 'personal';

-- ==============================================================================
-- STEP 3: INSERT DEFAULT EMERGENCY CONTACTS (India)
-- ==============================================================================

INSERT INTO default_emergency_contacts (id, name, phone, description, country, service_type, display_order, icon) VALUES
('default-police', 'Police', '100', 'Police Emergency', 'India', 'emergency', 1, 'shield'),
('default-ambulance', 'Ambulance', '102', 'Medical Emergency', 'India', 'emergency', 2, 'medkit'),
('default-fire', 'Fire Department', '101', 'Fire Emergency', 'India', 'emergency', 3, 'flame'),
('default-women-helpline', 'Women Helpline', '1091', 'Women Safety Emergency', 'India', 'emergency', 4, 'woman'),
('default-child-helpline', 'Child Helpline', '1098', 'Child Emergency', 'India', 'emergency', 5, 'people'),
('default-ncrb', 'NCRB', '155260', 'National Crime Reporting', 'India', 'emergency', 6, 'shield-checkmark');

-- ==============================================================================
-- STEP 4: CREATE USER EMERGENCY PREFERENCES TABLE
-- ==============================================================================

CREATE TABLE IF NOT EXISTS user_emergency_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    enable_sos BOOLEAN DEFAULT TRUE,
    auto_share_location BOOLEAN DEFAULT FALSE,
    notify_emergency_contacts BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    emergency_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preferences (user_id)
);

-- ==============================================================================
-- STEP 5: SEED DEFAULT USER EMERGENCY PREFERENCES
-- ==============================================================================

-- Insert default preferences for existing users (will be created on user registration)
-- This is just a template that gets copied when user is created

-- ==============================================================================
-- QUERIES TO GET EMERGENCY CONTACTS
-- ==============================================================================

-- Get all emergency contacts for a user (default + user-specific)
-- This combines both default and user-added contacts

-- Get default contacts
SELECT * FROM default_emergency_contacts WHERE is_active = TRUE ORDER BY display_order;

-- Get user-specific contacts
SELECT * FROM emergency_contacts WHERE user_id = ? ORDER BY is_primary DESC;

-- Get all contacts for a user (combined)
-- SELECT * FROM (
--     SELECT id, name, phone, 'default' as source FROM default_emergency_contacts WHERE is_active = TRUE
--     UNION ALL
--     SELECT id, name, phone, 'user' as source FROM emergency_contacts WHERE user_id = ?
-- ) ORDER BY source, is_primary;

SELECT 'Emergency contacts migration completed successfully' AS status;
