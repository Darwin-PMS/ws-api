-- Migration: Add themes, menus, and permissions tables
-- Created: 2026-03-04

-- ============================================
-- THEMES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS themes (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    config JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add index for active themes
CREATE INDEX IF NOT EXISTS idx_themes_active ON themes(is_active);
CREATE INDEX IF NOT EXISTS idx_themes_default ON themes(is_default);

-- ============================================
-- USER THEMES TABLE (User-Theme assignments)
-- ============================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

CREATE INDEX IF NOT EXISTS idx_user_themes_user ON user_themes(user_id);
CREATE INDEX IF NOT EXISTS idx_user_themes_theme ON user_themes(theme_id);

-- ============================================
-- MENUS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('primary', 'secondary', 'footer', 'sidebar') DEFAULT 'primary',
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_menus_type ON menus(type);
CREATE INDEX IF NOT EXISTS idx_menus_active ON menus(is_active);

-- ============================================
-- PERMISSIONS TABLE (User-specific permissions)
-- ============================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

CREATE INDEX IF NOT EXISTS idx_permissions_user ON permissions(user_id);
CREATE INDEX IF NOT EXISTS idx_permissions_expires ON permissions(expires_at);

-- ============================================
-- ROLE PERMISSIONS TABLE (Role templates)
-- ============================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

CREATE INDEX IF NOT EXISTS idx_role_permissions_role ON role_permissions(role);

-- ============================================
-- INSERT DEFAULT THEMES
-- ============================================
INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-dark-default', 'Dark Default', 'Default dark theme with purple accents', TRUE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "secondaryLight": "#F472B6",
        "secondaryDark": "#DB2777",
        "background": "#0F0F14",
        "backgroundLight": "#1A1A24",
        "backgroundLighter": "#252532",
        "surface": "#1E1E2C",
        "surfaceElevated": "#252532",
        "glass": "rgba(30, 30, 44, 0.7)",
        "glassBorder": "rgba(139, 92, 246, 0.2)",
        "glassHighlight": "rgba(139, 92, 246, 0.1)",
        "text": "#FFFFFF",
        "textSecondary": "#A1A1AA",
        "textMuted": "#71717A",
        "textAccent": "#C4B5FD",
        "success": "#10B981",
        "warning": "#F59E0B",
        "error": "#EF4444",
        "danger": "#EF4444",
        "info": "#3B82F6",
        "userBubble": "#7C3AED",
        "aiBubble": "#1E1E2C",
        "aiBubbleBorder": "#3F3F5A",
        "card": "#1E1E2C",
        "tabBarBackground": "#14141B",
        "tabBarActive": "#8B5CF6",
        "tabBarInactive": "#71717A",
        "border": "#3F3F5A",
        "borderLight": "#27273A",
        "overlay": "rgba(0, 0, 0, 0.6)"
    },
    "typography": {
        "fontFamily": { "regular": "System", "medium": "System", "bold": "System" },
        "fontSize": { "xs": 10, "sm": 12, "md": 14, "lg": 16, "xl": 18, "xxl": 24, "xxxl": 32, "title": 28 },
        "fontWeight": { "regular": "400", "medium": "500", "semibold": "600", "bold": "700" },
        "lineHeight": { "tight": 1.2, "normal": 1.5, "relaxed": 1.75 }
    },
    "spacing": { "xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32, "xxl": 48 },
    "borderRadius": { "sm": 8, "md": 12, "lg": 16, "xl": 24, "full": 9999 },
    "shadows": {
        "sm": { "shadowColor": "#000", "shadowOffset": { "width": 0, "height": 2 }, "shadowOpacity": 0.1, "shadowRadius": 4, "elevation": 2 },
        "md": { "shadowColor": "#000", "shadowOffset": { "width": 0, "height": 4 }, "shadowOpacity": 0.15, "shadowRadius": 8, "elevation": 4 },
        "lg": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 8 }, "shadowOpacity": 0.25, "shadowRadius": 16, "elevation": 8 },
        "glow": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 0 }, "shadowOpacity": 0.5, "shadowRadius": 20, "elevation": 10 }
    }
}
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    description = VALUES(description),
    config = VALUES(config);

INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-light-default', 'Light Default', 'Default light theme', FALSE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "secondaryLight": "#F472B6",
        "secondaryDark": "#DB2777",
        "background": "#F8FAFC",
        "backgroundLight": "#F1F5F9",
        "backgroundLighter": "#E2E8F0",
        "surface": "#FFFFFF",
        "surfaceElevated": "#FFFFFF",
        "glass": "rgba(255, 255, 255, 0.8)",
        "glassBorder": "rgba(139, 92, 246, 0.15)",
        "glassHighlight": "rgba(139, 92, 246, 0.05)",
        "text": "#1E293B",
        "textSecondary": "#64748B",
        "textMuted": "#94A3B8",
        "textAccent": "#7C3AED",
        "success": "#059669",
        "warning": "#D97706",
        "error": "#DC2626",
        "danger": "#DC2626",
        "info": "#2563EB",
        "userBubble": "#7C3AED",
        "aiBubble": "#F1F5F9",
        "aiBubbleBorder": "#E2E8F0",
        "card": "#FFFFFF",
        "tabBarBackground": "#FFFFFF",
        "tabBarActive": "#8B5CF6",
        "tabBarInactive": "#94A3B8",
        "border": "#E2E8F0",
        "borderLight": "#F1F5F9",
        "overlay": "rgba(0, 0, 0, 0.4)"
    },
    "typography": {
        "fontFamily": { "regular": "System", "medium": "System", "bold": "System" },
        "fontSize": { "xs": 10, "sm": 12, "md": 14, "lg": 16, "xl": 18, "xxl": 24, "xxxl": 32, "title": 28 },
        "fontWeight": { "regular": "400", "medium": "500", "semibold": "600", "bold": "700" },
        "lineHeight": { "tight": 1.2, "normal": 1.5, "relaxed": 1.75 }
    },
    "spacing": { "xs": 4, "sm": 8, "md": 16, "lg": 24, "xl": 32, "xxl": 48 },
    "borderRadius": { "sm": 8, "md": 12, "lg": 16, "xl": 24, "full": 9999 },
    "shadows": {
        "sm": { "shadowColor": "#1E293B", "shadowOffset": { "width": 0, "height": 2 }, "shadowOpacity": 0.1, "shadowRadius": 4, "elevation": 2 },
        "md": { "shadowColor": "#1E293B", "shadowOffset": { "width": 0, "height": 4 }, "shadowOpacity": 0.15, "shadowRadius": 8, "elevation": 4 },
        "lg": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 8 }, "shadowOpacity": 0.25, "shadowRadius": 16, "elevation": 8 },
        "glow": { "shadowColor": "#8B5CF6", "shadowOffset": { "width": 0, "height": 0 }, "shadowOpacity": 0.5, "shadowRadius": 20, "elevation": 10 }
    }
}
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    description = VALUES(description),
    config = VALUES(config);

-- ============================================
-- INSERT DEFAULT MENUS
-- ============================================
INSERT INTO menus (id, name, type, is_active, items) VALUES
('menu-primary-default', 'Primary Navigation', 'primary', TRUE, '
[
    { "id": "nav-home", "label": "Home", "icon": "home", "route": "Home", "order": 1, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] },
    { "id": "nav-notifications", "label": "Alerts", "icon": "notifications", "route": "Notifications", "order": 2, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin"], "badge": { "type": "count", "source": "/api/notifications/unread-count" } },
    { "id": "nav-ai-chat", "label": "AI Chat", "icon": "chatbubbles", "route": "AIChat", "order": 3, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"], "requiredFlags": ["ai.chat"], "requiredPermissions": ["ai:read"] },
    { "id": "nav-more", "label": "More", "icon": "menu", "route": "More", "order": 4, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] },
    { "id": "nav-profile", "label": "Profile", "icon": "person", "route": "Profile", "order": 5, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian", "admin", "friend"] }
]
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    items = VALUES(items);

INSERT INTO menus (id, name, type, is_active, items) VALUES
('menu-secondary-default', 'Core Services', 'secondary', TRUE, '
[
    { "id": "svc-women-safety", "label": "Women Safety", "subtitle": "SOS, emergency contacts & safety tips", "icon": "shield-checkmark", "color": "#EC4899", "screen": "WomenSafety", "order": 1, "isVisible": true, "requiredRoles": ["woman", "parent", "guardian"], "requiredFlags": ["sos.emergency"], "category": "safety" },
    { "id": "svc-child-care", "label": "Child Care", "subtitle": "Tips, guidance & assistant", "icon": "happy", "color": "#10B981", "screen": "ChildCare", "order": 2, "isVisible": true, "requiredRoles": ["parent", "guardian"], "category": "family" },
    { "id": "svc-family", "label": "Family", "subtitle": "Manage family members & relationships", "icon": "people", "color": "#EC4899", "screen": "Family", "order": 3, "isVisible": true, "requiredRoles": ["parent", "guardian", "admin"], "requiredFlags": ["family.tracking"], "requiredPermissions": ["family:read"], "category": "family" },
    { "id": "svc-home-automation", "label": "Home Automation", "subtitle": "Control smart devices & appliances", "icon": "home", "color": "#3B82F6", "screen": "HomeAutomation", "order": 4, "isVisible": true, "requiredFlags": ["home.automation"], "requiredPermissions": ["automation:read"], "category": "lifestyle" },
    { "id": "svc-vision", "label": "Vision", "subtitle": "Image analysis with AI", "icon": "camera", "color": "#8B5CF6", "screen": "Vision", "order": 5, "isVisible": true, "requiredFlags": ["ai.vision"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-speech", "label": "Speech to Text", "subtitle": "Transcribe audio with AI", "icon": "mic", "color": "#10B981", "screen": "Speech", "order": 6, "isVisible": true, "requiredFlags": ["ai.speech"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-tts", "label": "Text to Speech", "subtitle": "Convert text to speech", "icon": "volume-high", "color": "#F59E0B", "screen": "TTS", "order": 7, "isVisible": true, "requiredFlags": ["ai.tts"], "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-models", "label": "Model Browser", "subtitle": "Browse and select AI models", "icon": "server", "color": "#8B5CF6", "screen": "ModelsList", "order": 8, "isVisible": true, "requiredPermissions": ["ai:read"], "category": "ai" },
    { "id": "svc-settings", "label": "Settings", "subtitle": "API key, preferences & about", "icon": "settings", "color": "#F59E0B", "screen": "Settings", "order": 9, "isVisible": true, "requiredPermissions": ["settings:read"], "category": "system" },
    { "id": "svc-profile", "label": "My Profile", "subtitle": "View & edit your profile", "icon": "person", "color": "#8B5CF6", "screen": "Profile", "order": 10, "isVisible": true, "requiredPermissions": ["users:read"], "category": "system" }
]
')
ON DUPLICATE KEY UPDATE 
    name = VALUES(name),
    items = VALUES(items);

-- ============================================
-- INSERT DEFAULT ROLE PERMISSIONS
-- ============================================
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-admin', 'admin', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true }
', '
{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true } }
', '
{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-guardian', 'guardian', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": false }, "automation": { "read": true, "write": true } }
', '
{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": ["bulk-export"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-parent', 'parent', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "automation": { "read": false, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-woman', 'woman', '
{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
('perm-friend', 'friend', '
{ "sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": false, "view_history": false }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Migration complete
SELECT 'Migration 001: themes, menus, permissions tables created successfully' as message;
-- Create children table for childcare feature
CREATE TABLE IF NOT EXISTS children (
    id VARCHAR(36) PRIMARY KEY,
    parent_id VARCHAR(36) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    date_of_birth DATE NOT NULL,
    gender ENUM('male', 'female', 'other'),
    blood_group VARCHAR(10),
    allergies JSON,
    medications JSON,
    emergency_contact VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_parent_id (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- Migration: Add app_settings table for storing app-wide configuration
-- Created: 2026-03-05

-- ============================================
-- APP SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS app_settings (
    id VARCHAR(36) PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add index for fast key lookups
CREATE INDEX IF NOT EXISTS idx_app_settings_key ON app_settings(setting_key);

-- Insert default Groq API key (empty by default, should be updated via admin)
INSERT INTO app_settings (id, setting_key, setting_value, description, is_encrypted) 
VALUES (
    UUID(), 
    'groq_key', 
    '', 
    'Groq API key for AI chat functionality',
    TRUE
) ON DUPLICATE KEY UPDATE setting_key = setting_key;
-- Migration: Update menus table with additional fields
-- Created: 2026-03-05
-- Adds: bgColor, textColor, hoverBgColor, hoverTextColor, label, route, icon, order, puspose, for, isVisible

-- ============================================
-- ALTER MENUS TABLE - ADD NEW COLUMNS
-- ============================================

-- Add new columns to menus table (only if they don't exist)
ALTER TABLE menus 
ADD COLUMN IF NOT EXISTS bgColor VARCHAR(100) DEFAULT '#8B5CF6',
ADD COLUMN IF NOT EXISTS textColor VARCHAR(100) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS hoverBgColor VARCHAR(100) DEFAULT '#7C3AED',
ADD COLUMN IF NOT EXISTS hoverTextColor VARCHAR(100) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS label VARCHAR(100),
ADD COLUMN IF NOT EXISTS route VARCHAR(100),
ADD COLUMN IF NOT EXISTS icon VARCHAR(100),
ADD COLUMN IF NOT EXISTS menu_order VARCHAR(100) DEFAULT '0',
ADD COLUMN IF NOT EXISTS puspose ENUM('home', 'more', 'profile') DEFAULT 'more',
ADD COLUMN IF NOT EXISTS menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
ADD COLUMN IF NOT EXISTS isVisible BOOLEAN DEFAULT TRUE;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_menus_puspose ON menus(puspose);
CREATE INDEX IF NOT EXISTS idx_menus_for ON menus(menu_for);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_visible ON menus(isVisible);

-- ============================================
-- UPDATE EXISTING MENUS WITH DEFAULT VALUES
-- ============================================

-- Update primary menu with new field values
UPDATE menus 
SET 
    bgColor = COALESCE(bgColor, '#8B5CF6'),
    textColor = COALESCE(textColor, '#FFFFFF'),
    hoverBgColor = COALESCE(hoverBgColor, '#7C3AED'),
    hoverTextColor = COALESCE(hoverTextColor, '#FFFFFF'),
    menu_order = COALESCE(menu_order, '0'),
    puspose = COALESCE(puspose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    isVisible = COALESCE(isVisible, TRUE)
WHERE type = 'primary';

-- Update secondary menu with new field values
UPDATE menus 
SET 
    bgColor = COALESCE(bgColor, '#EC4899'),
    textColor = COALESCE(textColor, '#FFFFFF'),
    hoverBgColor = COALESCE(hoverBgColor, '#DB2777'),
    hoverTextColor = COALESCE(hoverTextColor, '#FFFFFF'),
    menu_order = COALESCE(menu_order, '1'),
    puspose = COALESCE(puspose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    isVisible = COALESCE(isVisible, TRUE)
WHERE type = 'secondary';

-- Migration complete
SELECT 'Migration 003: menus table updated with additional fields successfully' as message;
-- Migration: Add parent-child hierarchical support to menus table
-- Created: 2026-03-05
-- Purpose: Enable menus to have parent-child relationships for hierarchical navigation

-- ============================================
-- STEP 0: Handle existing data
-- ============================================

-- Note: If menus already exist, we need to ensure the new columns exist
-- Run this to add columns without dropping existing data

-- ============================================
-- STEP 1: Add new columns for parent support
-- ============================================

ALTER TABLE menus 
ADD COLUMN IF NOT EXISTS parent_id VARCHAR(36) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS menu_order INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS bg_color VARCHAR(20) DEFAULT '#8B5CF6',
ADD COLUMN IF NOT EXISTS text_color VARCHAR(20) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
ADD COLUMN IF NOT EXISTS hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS label VARCHAR(100),
ADD COLUMN IF NOT EXISTS route VARCHAR(100),
ADD COLUMN IF NOT EXISTS icon VARCHAR(50),
ADD COLUMN IF NOT EXISTS subtitle VARCHAR(255),
ADD COLUMN IF NOT EXISTS purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
ADD COLUMN IF NOT EXISTS menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
ADD COLUMN IF NOT EXISTS is_visible BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS required_flags JSON,
ADD COLUMN IF NOT EXISTS required_permissions JSON,
ADD COLUMN IF NOT EXISTS required_roles JSON,
ADD COLUMN IF NOT EXISTS category VARCHAR(50);

-- Add foreign key constraint
ALTER TABLE menus 
ADD CONSTRAINT IF NOT EXISTS fk_menus_parent 
FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL;

-- ============================================
-- STEP 2: Create indexes for performance
-- ============================================

CREATE INDEX IF NOT EXISTS idx_menus_parent ON menus(parent_id);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_purpose ON menus(purpose);
CREATE INDEX IF NOT EXISTS idx_menus_menu_for ON menus(menu_for);

-- ============================================
-- STEP 3: Update existing menus with default values
-- ============================================

-- Update primary menu
UPDATE menus 
SET 
    bg_color = COALESCE(bg_color, '#8B5CF6'),
    text_color = COALESCE(text_color, '#FFFFFF'),
    hover_bg_color = COALESCE(hover_bg_color, '#7C3AED'),
    hover_text_color = COALESCE(hover_text_color, '#FFFFFF'),
    menu_order = COALESCE(menu_order, 0),
    purpose = COALESCE(purpose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    is_visible = COALESCE(is_visible, TRUE)
WHERE type = 'primary';

-- Update secondary menu
UPDATE menus 
SET 
    bg_color = COALESCE(bg_color, '#EC4899'),
    text_color = COALESCE(text_color, '#FFFFFF'),
    hover_bg_color = COALESCE(hover_bg_color, '#DB2777'),
    hover_text_color = COALESCE(hover_text_color, '#FFFFFF'),
    menu_order = COALESCE(menu_order, 1),
    purpose = COALESCE(purpose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    is_visible = COALESCE(is_visible, TRUE)
WHERE type = 'secondary';

-- Migration complete
SELECT 'Migration: Parent-child hierarchical support added to menus table' as status;
-- ==============================================================================
-- COMPLETE MENUS TABLE WITH PARENT-CHILD HIERARCHY
-- Created: 2026-03-05
-- Description: Full SQL script to create menus table and insert all menu items 
--              separately with parent-child relationships
-- ==============================================================================

-- ==============================================================================
-- STEP 1: DROP EXISTING TABLES (if you want fresh start)
-- ==============================================================================
-- Uncomment the following line if you want to drop and recreate:
-- DROP TABLE IF EXISTS menus;

-- ==============================================================================
-- STEP 2: CREATE MENUS TABLE WITH PARENT SUPPORT
-- ==============================================================================

CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    parent_id VARCHAR(36) DEFAULT NULL,
    menu_order INT DEFAULT 0,
    bg_color VARCHAR(20) DEFAULT '#8B5CF6',
    text_color VARCHAR(20) DEFAULT '#FFFFFF',
    hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
    hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
    label VARCHAR(100),
    route VARCHAR(100),
    icon VARCHAR(50),
    subtitle VARCHAR(255),
    purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
    menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
    is_visible BOOLEAN DEFAULT TRUE,
    required_flags JSON,
    required_permissions JSON,
    required_roles JSON,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL
);

-- ==============================================================================
-- STEP 3: CREATE INDEXES FOR PERFORMANCE
-- ==============================================================================

CREATE INDEX IF NOT EXISTS idx_menus_type ON menus(type);
CREATE INDEX IF NOT EXISTS idx_menus_parent ON menus(parent_id);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_purpose ON menus(purpose);
CREATE INDEX IF NOT EXISTS idx_menus_menu_for ON menus(menu_for);
CREATE INDEX IF NOT EXISTS idx_menus_active ON menus(is_active);

-- ==============================================================================
-- STEP 4: DELETE EXISTING MENUS AND INSERT FRESH DATA
-- ==============================================================================

-- First delete existing menus to avoid duplicates
DELETE FROM menus WHERE type IN ('primary', 'secondary');

-- Primary Menu Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible) 
VALUES (
    'menu-primary-main',
    'Primary Navigation',
    'primary',
    TRUE,
    '[]',
    0,
    '#8B5CF6',
    '#FFFFFF',
    'home',
    'mobile',
    TRUE
);

-- Primary Menu Items - Each as separate row with parent_id (use INSERT IGNORE)

-- Home Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-home',
    'Home',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    1,
    'Home',
    'home',
    'Home',
    'home',
    'mobile',
    TRUE
);

-- Notifications Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-notifications',
    'Notifications',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    2,
    'Notifications',
    'notifications',
    'Alerts',
    'home',
    'mobile',
    TRUE
);

-- AI Chat Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-ai-chat',
    'AI Chat',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    3,
    'AIChat',
    'chatbubbles',
    'AI Chat',
    'home',
    'mobile',
    TRUE,
    '["ai.chat"]',
    '["ai:read"]'
);

-- More Tab (with children - dropdown)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-more',
    'More',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    4,
    'More',
    'menu',
    'More',
    'home',
    'mobile',
    TRUE
);

-- Profile Tab
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible)
VALUES (
    'menu-profile',
    'Profile',
    'primary',
    TRUE,
    '[]',
    'menu-primary-main',
    5,
    'Profile',
    'person',
    'Profile',
    'home',
    'mobile',
    TRUE
);

-- ==============================================================================
-- STEP 5: INSERT CHILDREN FOR "MORE" MENU
-- ==============================================================================

-- More > Women Safety
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles)
VALUES (
    'menu-more-women-safety',
    'Women Safety',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    1,
    'WomenSafety',
    'shield-checkmark',
    'Women Safety',
    '#EC4899',
    'more',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]'
);

-- More > Child Care
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles)
VALUES (
    'menu-more-child-care',
    'Child Care',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    2,
    'ChildCare',
    'happy',
    'Child Care',
    '#10B981',
    'more',
    'mobile',
    TRUE,
    '["parent", "guardian"]'
);

-- More > Family
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, required_permissions)
VALUES (
    'menu-more-family',
    'Family',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    3,
    'Family',
    'people',
    'Family',
    '#EC4899',
    'more',
    'mobile',
    TRUE,
    '["parent", "guardian", "admin"]',
    '["family.tracking"]',
    '["family:read"]'
);

-- More > Home Automation
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-home-automation',
    'Home Automation',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    4,
    'HomeAutomation',
    'home',
    'Home Automation',
    '#3B82F6',
    'more',
    'mobile',
    TRUE,
    '["home.automation"]',
    '["automation:read"]'
);

-- More > Vision AI
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-vision',
    'Vision AI',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    5,
    'Vision',
    'camera',
    'Vision AI',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["ai.vision"]',
    '["ai:read"]'
);

-- More > Speech to Text
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-speech',
    'Speech to Text',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    6,
    'Speech',
    'mic',
    'Speech to Text',
    '#10B981',
    'more',
    'mobile',
    TRUE,
    '["ai.speech"]',
    '["ai:read"]'
);

-- More > Text to Speech
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-tts',
    'Text to Speech',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    7,
    'TTS',
    'volume-high',
    'Text to Speech',
    '#F59E0B',
    'more',
    'mobile',
    TRUE,
    '["ai.tts"]',
    '["ai:read"]'
);

-- More > Model Browser
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-models',
    'Model Browser',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    8,
    'ModelsList',
    'server',
    'Model Browser',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["ai:read"]'
);

-- More > Settings
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-settings',
    'Settings',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    9,
    'Settings',
    'settings',
    'Settings',
    '#F59E0B',
    'more',
    'mobile',
    TRUE,
    '["settings:read"]'
);

-- More > My Profile
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_permissions)
VALUES (
    'menu-more-profile',
    'My Profile',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    10,
    'Profile',
    'person',
    'My Profile',
    '#8B5CF6',
    'more',
    'mobile',
    TRUE,
    '["users:read"]'
);

-- ==============================================================================
-- STEP 6: INSERT CORE SERVICES MENU (Home Screen Cards)
-- ==============================================================================

-- Core Services Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible)
VALUES (
    'menu-core-services',
    'Core Services',
    'secondary',
    TRUE,
    '[]',
    1,
    '#EC4899',
    '#FFFFFF',
    'home',
    'mobile',
    TRUE
);

-- Core Service: Women Safety
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'svc-women-safety',
    'Women Safety',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    1,
    'WomenSafety',
    'shield-checkmark',
    'Women Safety',
    'SOS, emergency contacts & safety tips',
    '#EC4899',
    'home',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["sos.emergency"]',
    'safety'
);

-- Core Service: Child Care
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, category)
VALUES (
    'svc-child-care',
    'Child Care',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    2,
    'ChildCare',
    'happy',
    'Child Care',
    'Tips, guidance & assistant',
    '#10B981',
    'home',
    'mobile',
    TRUE,
    '["parent", "guardian"]',
    'family'
);

-- Core Service: Family
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, required_permissions, category)
VALUES (
    'svc-family',
    'Family',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    3,
    'Family',
    'people',
    'Family',
    'Manage family members & relationships',
    '#EC4899',
    'home',
    'mobile',
    TRUE,
    '["parent", "guardian", "admin"]',
    '["family.tracking"]',
    '["family:read"]',
    'family'
);

-- Core Service: Home Automation
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-home-automation',
    'Home Automation',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    4,
    'HomeAutomation',
    'home',
    'Home Automation',
    'Control smart devices & appliances',
    '#3B82F6',
    'home',
    'mobile',
    TRUE,
    '["home.automation"]',
    '["automation:read"]',
    'lifestyle'
);

-- Core Service: Vision AI
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-vision',
    'Vision',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    5,
    'Vision',
    'camera',
    'Vision',
    'Image analysis with AI',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["ai.vision"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Speech to Text
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-speech',
    'Speech to Text',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    6,
    'Speech',
    'mic',
    'Speech to Text',
    'Transcribe audio with AI',
    '#10B981',
    'home',
    'mobile',
    TRUE,
    '["ai.speech"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Text to Speech
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-tts',
    'Text to Speech',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    7,
    'TTS',
    'volume-high',
    'Text to Speech',
    'Convert text to speech',
    '#F59E0B',
    'home',
    'mobile',
    TRUE,
    '["ai.tts"]',
    '["ai:read"]',
    'ai'
);

-- Core Service: Model Browser
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-models',
    'Model Browser',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    8,
    'ModelsList',
    'server',
    'Model Browser',
    'Browse and select AI models',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["ai:read"]',
    'ai'
);

-- Core Service: Settings
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-settings',
    'Settings',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    9,
    'Settings',
    'settings',
    'Settings',
    'API key, preferences & about',
    '#F59E0B',
    'home',
    'mobile',
    TRUE,
    '["settings:read"]',
    'system'
);

-- Core Service: My Profile
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_permissions, category)
VALUES (
    'svc-profile',
    'My Profile',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    10,
    'Profile',
    'person',
    'My Profile',
    'View & edit your profile',
    '#8B5CF6',
    'home',
    'mobile',
    TRUE,
    '["users:read"]',
    'system'
);

-- ==============================================================================
-- STEP 7: VERIFICATION QUERIES
-- ==============================================================================

-- Check all menus with their parent relationships
SELECT 
    m.id,
    m.name,
    m.type,
    m.menu_order,
    m.route,
    m.icon,
    m.label,
    m.purpose,
    m.menu_for,
    m.is_visible,
    p.name AS parent_name,
    p.type AS parent_type
FROM menus m
LEFT JOIN menus p ON m.parent_id = p.id
ORDER BY m.type, m.menu_order;

-- Get hierarchy tree for primary menu
SELECT 
    m.id,
    m.name,
    m.menu_order,
    m.route,
    m.icon,
    m.label,
    m.parent_id,
    p.name AS parent_name
FROM menus m
LEFT JOIN menus p ON m.parent_id = p.id
WHERE m.type = 'primary'
ORDER BY m.menu_order;

-- Get services by category
SELECT 
    category,
    COUNT(*) as count
FROM menus
WHERE type = 'secondary' 
AND parent_id = 'menu-core-services'
GROUP BY category;

SELECT 'Full menu hierarchy setup completed successfully!' AS status;
-- ==============================================================================
-- CYLINDER VERIFICATION MODULE MENU ENTRIES
-- Created: 2026-03-06
-- Description: SQL script to add Cylinder Verification module to menus table
-- ==============================================================================

-- Add Cylinder Verification to Core Services (Home Screen)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-cylinder-verification',
    'Cylinder Verification',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    5,
    'CylinderVerification',
    'flame',
    'Cylinder Verification',
    'Verify gas cylinder validity & expiration',
    '#EF4444',
    'home',
    'mobile',
    TRUE,
    '["safety.inspection"]',
    '["cylinder:read"]',
    'safety'
);

-- Add Cylinder Verification to More Menu (under More >)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-cylinder-verification',
    'Cylinder Verification',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    11,
    'CylinderVerification',
    'flame',
    'Cylinder Verification',
    '#EF4444',
    'more',
    'mobile',
    TRUE,
    '["safety.inspection"]',
    '["cylinder:read"]'
);

-- Verify the entries were added
SELECT id, name, route, icon, label, category, purpose, menu_for 
FROM menus 
WHERE id IN ('svc-cylinder-verification', 'menu-more-cylinder-verification');
-- ==============================================================================
-- EMERGENCY CONTACTS: DEFAULT AND USER-SPECIFIC
-- Created: 2026-03-05
-- Purpose: Support both default emergency numbers and user-specific contacts
-- ==============================================================================

-- ==============================================================================
-- STEP 1: CREATE DEFAULT EMERGENCY CONTACTS TABLE (System-wide)
-- ==============================================================================

CREATE TABLE IF NOT EXISTS default_emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description VARCHAR(255),
    country VARCHAR(50) DEFAULT 'India',
    service_type VARCHAR(50) DEFAULT 'emergency',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- STEP 2: UPDATE USER EMERGENCY CONTACTS TABLE
-- ==============================================================================

-- Add new columns to emergency_contacts table if not exists
ALTER TABLE emergency_contacts 
ADD COLUMN IF NOT EXISTS notes TEXT,
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS contact_type ENUM('personal', 'family', 'friend', 'work', 'emergency') DEFAULT 'personal';

-- ==============================================================================
-- STEP 3: INSERT DEFAULT EMERGENCY CONTACTS (India)
-- ==============================================================================

INSERT INTO default_emergency_contacts (id, name, phone, description, country, service_type, display_order, icon) VALUES
('default-police', 'Police', '100', 'Police Emergency', 'India', 'emergency', 1, 'shield'),
('default-ambulance', 'Ambulance', '102', 'Medical Emergency', 'India', 'emergency', 2, 'medkit'),
('default-fire', 'Fire Department', '101', 'Fire Emergency', 'India', 'emergency', 3, 'flame'),
('default-women-helpline', 'Women Helpline', '1091', 'Women Safety Emergency', 'India', 'emergency', 4, 'woman'),
('default-child-helpline', 'Child Helpline', '1098', 'Child Emergency', 'India', 'emergency', 5, 'people'),
('default-ncrb', 'NCRB', '155260', 'National Crime Reporting', 'India', 'emergency', 6, 'shield-checkmark');

-- ==============================================================================
-- STEP 4: CREATE USER EMERGENCY PREFERENCES TABLE
-- ==============================================================================

CREATE TABLE IF NOT EXISTS user_emergency_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    enable_sos BOOLEAN DEFAULT TRUE,
    auto_share_location BOOLEAN DEFAULT FALSE,
    notify_emergency_contacts BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    emergency_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preferences (user_id)
);

-- ==============================================================================
-- STEP 5: SEED DEFAULT USER EMERGENCY PREFERENCES
-- ==============================================================================

-- Insert default preferences for existing users (will be created on user registration)
-- This is just a template that gets copied when user is created

-- ==============================================================================
-- QUERIES TO GET EMERGENCY CONTACTS
-- ==============================================================================

-- Get all emergency contacts for a user (default + user-specific)
-- This combines both default and user-added contacts

-- Get default contacts
SELECT * FROM default_emergency_contacts WHERE is_active = TRUE ORDER BY display_order;

-- Get user-specific contacts
SELECT * FROM emergency_contacts WHERE user_id = ? ORDER BY is_primary DESC;

-- Get all contacts for a user (combined)
-- SELECT * FROM (
--     SELECT id, name, phone, 'default' as source FROM default_emergency_contacts WHERE is_active = TRUE
--     UNION ALL
--     SELECT id, name, phone, 'user' as source FROM emergency_contacts WHERE user_id = ?
-- ) ORDER BY source, is_primary;

SELECT 'Emergency contacts migration completed successfully' AS status;
-- Behavior Analysis System Database Migration
-- Creates tables for behavior patterns, anomalies, feedback, alerts, and sensor data

-- ========================
-- Behavior Patterns Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_patterns (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    pattern_type ENUM('route', 'location', 'time', 'activity', 'commute') NOT NULL,
    pattern_name VARCHAR(100),
    pattern_data JSON NOT NULL,
    confidence DECIMAL(3,2) DEFAULT 0.50,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_patterns_user (user_id),
    INDEX idx_patterns_type (pattern_type)
);

-- ========================
-- Anomaly Events Table
-- ========================
CREATE TABLE IF NOT EXISTS anomaly_events (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_type ENUM('unexpected_stop', 'route_deviation', 'unusual_inactivity', 'abnormal_speed', 'sensor_anomaly', 'fall_detected') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    location_name VARCHAR(255),
    accuracy DECIMAL(6,2),
    speed DECIMAL(6,2),
    duration_minutes INT,
    context_data JSON,
    ai_analysis TEXT,
    is_confirmed BOOLEAN DEFAULT NULL,
    confirmed_at TIMESTAMP NULL,
    feedback_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_anomaly_user_time (user_id, created_at),
    INDEX idx_anomaly_type (anomaly_type),
    INDEX idx_anomaly_severity (severity)
);

-- ========================
-- Behavior Feedback Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_feedback (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_id VARCHAR(36) NOT NULL,
    feedback_type ENUM('false_positive', 'accurate', 'needs_review', 'helpful') NOT NULL,
    user_notes TEXT,
    expected_behavior VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (anomaly_id) REFERENCES anomaly_events(id) ON DELETE CASCADE,
    INDEX idx_feedback_anomaly (anomaly_id),
    INDEX idx_feedback_user (user_id)
);

-- ========================
-- Behavior Alerts Table
-- ========================
CREATE TABLE IF NOT EXISTS behavior_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    anomaly_id VARCHAR(36),
    alert_type ENUM('sos', 'warning', 'notification', 'trusted_contact', 'emergency_service') NOT NULL,
    status ENUM('pending', 'sent', 'delivered', 'acknowledged', 'resolved', 'failed') DEFAULT 'pending',
    recipient_type ENUM('user', 'trusted_contact', 'emergency_service', 'system') NOT NULL,
    recipient_id VARCHAR(36),
    recipient_name VARCHAR(100),
    recipient_phone VARCHAR(20),
    recipient_email VARCHAR(255),
    message TEXT,
    location_latitude DECIMAL(10,8),
    location_longitude DECIMAL(11,8),
    map_link VARCHAR(500),
    response_data JSON,
    sent_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (anomaly_id) REFERENCES anomaly_events(id) ON DELETE SET NULL,
    INDEX idx_alerts_user (user_id),
    INDEX idx_alerts_status (status),
    INDEX idx_alerts_type (alert_type)
);

-- ========================
-- Sensor Data Table
-- ========================
CREATE TABLE IF NOT EXISTS sensor_data (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sensor_type ENUM('accelerometer', 'gyroscope', 'heart_rate', 'steps', 'fall_detect', 'barometer', 'pedometer') NOT NULL,
    data JSON NOT NULL,
    source ENUM('phone', 'smartwatch', 'external') DEFAULT 'phone',
    device_id VARCHAR(100),
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sensor_user_time (user_id, recorded_at),
    INDEX idx_sensor_type (sensor_type)
);

-- ========================
-- User Behavior Settings Table
-- ========================
CREATE TABLE IF NOT EXISTS user_behavior_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    monitoring_enabled BOOLEAN DEFAULT TRUE,
    detection_settings JSON DEFAULT JSON_OBJECT(
        'stopDetection', TRUE,
        'routeDeviation', TRUE,
        'inactivityDetection', TRUE,
        'speedAnalysis', TRUE,
        'sensorAnalysis', TRUE
    ),
    sensitivity_settings JSON DEFAULT JSON_OBJECT(
        'level', 'medium',
        'stopDurationMultiplier', 2.0,
        'routeDeviationMultiplier', 1.5,
        'inactivityMultiplier', 1.5
    ),
    alert_settings JSON DEFAULT JSON_OBJECT(
        'alertThreshold', 3,
        'autoAlertContacts', TRUE,
        'alertDelay', 30,
        'severityThreshold', 'medium'
    ),
    notification_settings JSON DEFAULT JSON_OBJECT(
        'pushNotifications', TRUE,
        'smsAlerts', TRUE,
        'soundEnabled', TRUE,
        'vibrationEnabled', TRUE
    ),
    privacy_settings JSON DEFAULT JSON_OBJECT(
        'shareWithContacts', TRUE,
        'shareLocationHistory', FALSE,
        'contributeAnonymizedData', TRUE,
        'allowSensorDataCollection', TRUE
    ),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ========================
-- Trusted Contacts for Behavior Alerts
-- ========================
CREATE TABLE IF NOT EXISTS behavior_trusted_contacts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    contact_id VARCHAR(36) NOT NULL,
    notify_on_anomaly BOOLEAN DEFAULT TRUE,
    notify_on_warning BOOLEAN DEFAULT FALSE,
    notify_on_critical_only BOOLEAN DEFAULT FALSE,
    alert_delay_seconds INT DEFAULT 0,
    contact_priority INT DEFAULT 1,
    custom_message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (contact_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_behavior_contact (user_id, contact_id)
);

-- ========================
-- Location History Enhanced (Extended from existing)
-- ========================
ALTER TABLE location_history 
ADD COLUMN IF NOT EXISTS activity_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS speed_kmh DECIMAL(6,2),
ADD COLUMN IF NOT EXISTS is_stationary BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS place_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS place_id VARCHAR(36);

-- Create index for enhanced location history
CREATE INDEX IF NOT EXISTS idx_location_user_time_activity 
ON location_history(user_id, created_at, activity_type);

-- ========================
-- Context Snapshots Enhanced (Extended from existing)
-- ========================
ALTER TABLE context_snapshots 
ADD COLUMN IF NOT EXISTS context_type VARCHAR(50),
ADD COLUMN IF NOT EXISTS risk_level INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS pattern_matched BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS pattern_id VARCHAR(36),
ADD COLUMN IF NOT EXISTS sensor_data JSON;

-- Insert default behavior settings for existing users
INSERT INTO user_behavior_settings (id, user_id)
SELECT UUID(), id FROM users
WHERE id NOT IN (SELECT user_id FROM user_behavior_settings);

-- Insert default emergency contacts as behavior alert recipients
INSERT INTO behavior_trusted_contacts (id, user_id, contact_id, contact_priority)
SELECT UUID(), u.id, e.id, 99
FROM users u
CROSS JOIN emergency_contacts e
WHERE e.is_primary = TRUE
AND u.id NOT IN (SELECT DISTINCT user_id FROM behavior_trusted_contacts WHERE contact_priority = 99);

-- Create procedure to clean old sensor data
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS cleanup_old_sensor_data()
BEGIN
    DELETE FROM sensor_data 
    WHERE recorded_at < DATE_SUB(NOW(), INTERVAL 7 DAY);
    
    DELETE FROM location_history 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
    
    DELETE FROM anomaly_events 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR)
    AND (is_confirmed = TRUE OR is_confirmed = FALSE);
END //
DELIMITER ;

-- Create event to run cleanup weekly
CREATE EVENT IF NOT EXISTS weekly_sensor_cleanup
ON SCHEDULE EVERY 1 WEEK
DO CALL cleanup_old_sensor_data();

SELECT 'Behavior Analysis tables created successfully' AS result;
-- ============================================
-- THOUGHT GENERATOR & AI VISION & SPEECH MENU MIGRATION
-- Created: 2026-03-07
-- Purpose: Add ThoughtGenerator, Vision, Speech, TTS screens to menus and link with users
-- ============================================

USE safety_app;

-- ============================================
-- ADD THOUGHT GENERATOR MENU (Using INSERT IGNORE to avoid duplicates)
-- ============================================

-- Add to 'More' menu (menu-thought-generator)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
('menu-thought-generator', 'Thought Generator', 'secondary', TRUE, '[]', 'menu-more', 9, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered thought suggestions', '#EC4899', 'more', 'mobile', TRUE, NULL, '["ai.chat"]', 'ai', NOW(), NOW());

-- Also add to Core Services (svc-thought-generator)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
('svc-thought-generator', 'Thought Generator', 'secondary', TRUE, '[]', 'menu-core-services-container', 12, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered thought suggestions', '#EC4899', 'home', 'mobile', TRUE, NULL, '["ai.chat"]', 'ai', NOW(), NOW());

-- ============================================
-- UPDATE EXISTING MENU ORDER IF NEEDED
-- ============================================
-- Ensure ThoughtGenerator is in the correct position in More menu
UPDATE menus SET menu_order = 9, route = 'ThoughtGenerator', icon = 'bulb', label = 'Thought Generator' 
WHERE id = 'menu-thought-generator' AND route != 'ThoughtGenerator';

-- ============================================
-- ADD ALL AI PERMISSIONS FOR USERS (chat, vision, speech, tts)
-- ============================================

-- Add ai.chat, ai.vision, ai.speech, ai.tts flags to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE flags IS NOT NULL;

-- Add ai.chat, ai.vision, ai.speech, ai.tts flags to all existing users in role_permissions table
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE flags IS NOT NULL;

-- Grant ai.chat, ai.vision, ai.speech, ai.tts permission to all users
UPDATE permissions SET 
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE permissions IS NOT NULL;

-- ============================================
-- UPDATE MENU ROUTE NAMES TO MATCH NAVIGATOR
-- ============================================
-- Fix route names to match the navigator screen names
UPDATE menus SET route = 'SpeechToText' WHERE route = 'Speech' OR route = 'speech-to-text';
UPDATE menus SET route = 'TextToSpeech' WHERE route = 'TTS' OR route = 'text-to-speech';
UPDATE menus SET route = 'SpeechToText' WHERE label LIKE '%Speech to Text%';
UPDATE menus SET route = 'TextToSpeech' WHERE label LIKE '%Text to Speech%';

-- ============================================
-- VERIFICATION
-- ============================================
SELECT 'ThoughtGenerator, AI Vision, Speech, TTS menu migration completed!' as message;

-- Show Speech and TextToSpeech menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_roles, required_flags 
FROM menus 
WHERE route IN ('SpeechToText', 'TextToSpeech', 'ThoughtGenerator', 'Vision');

-- Verify permissions were updated
SELECT id, user_id, flags FROM permissions LIMIT 5;

-- Verify role permissions were updated
SELECT id, role, flags FROM role_permissions;
-- ==============================================================================
-- BEHAVIOR PATTERN ANALYSIS MODULE - MENU RELOCATION
-- Created: 2026-03-07
-- Description: SQL script to add Behavior Pattern module to Women Safety category
--              and make it prominent in Core Services
-- ==============================================================================

-- ==============================================================================
-- STEP 1: Add Behavior Pattern to Women Safety Menu (under More > Women Safety)
-- ==============================================================================

-- First, check if menu-women-safety exists
SELECT id, name FROM menus WHERE id = 'menu-women-safety';

-- Add Behavior Pattern to Women Safety submenu
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'menu-women-safety-behavior-pattern',
    'Behavior Pattern',
    'secondary',
    TRUE,
    '[]',
    'menu-women-safety',
    4,
    'BehaviorPattern',
    'analytics',
    'Behavior Pattern',
    'Track and analyze behavioral patterns',
    '#6366F1',
    'more',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["behavior.analysis"]',
    'safety'
)
ON DUPLICATE KEY UPDATE 
    label = VALUES(label),
    route = VALUES(route),
    icon = VALUES(icon),
    subtitle = VALUES(subtitle),
    bg_color = VALUES(bg_color),
    required_roles = VALUES(required_roles),
    required_flags = VALUES(required_flags),
    category = VALUES(category);

-- ==============================================================================
-- STEP 2: Add Behavior Pattern to Core Services (Home Screen)
-- ==============================================================================

-- First, check if the Core Services container exists
SELECT id, name FROM menus WHERE id = 'menu-core-services-container';

-- Add Behavior Pattern as a child of Safety Features in Core Services
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category)
VALUES (
    'svc-behavior-pattern',
    'Behavior Pattern',
    'secondary',
    TRUE,
    '[]',
    'svc-women-safety',
    2,
    'BehaviorPattern',
    'analytics',
    'Behavior Pattern',
    'Track and analyze behavioral patterns',
    '#6366F1',
    'home',
    'mobile',
    TRUE,
    '["woman", "parent", "guardian"]',
    '["behavior.analysis"]',
    'safety'
)
ON DUPLICATE KEY UPDATE 
    label = VALUES(label),
    route = VALUES(route),
    icon = VALUES(icon),
    subtitle = VALUES(subtitle),
    bg_color = VALUES(bg_color),
    required_roles = VALUES(required_roles),
    required_flags = VALUES(required_flags),
    category = VALUES(category);

-- ==============================================================================
-- STEP 3: Update existing Behavior Pattern entry (if under Child Care)
-- ==============================================================================

-- Check and update existing behavior pattern menu under Child Care to also show for women
UPDATE menus 
SET required_roles = '["woman", "parent", "guardian"]',
    category = 'safety'
WHERE id = 'menu-behavior-pattern' 
AND category = 'family';

-- ==============================================================================
-- STEP 4: Verify the entries
-- ==============================================================================

-- Check all Behavior Pattern related entries
SELECT id, name, route, icon, label, subtitle, category, parent_id, required_roles 
FROM menus 
WHERE name LIKE '%Behavior%' OR label LIKE '%Behavior%' OR route = 'BehaviorPattern';

-- Check Women Safety submenu items
SELECT id, name, route, icon, label, menu_order, category 
FROM menus 
WHERE parent_id = 'menu-women-safety' OR parent_id = 'svc-women-safety'
ORDER BY menu_order;

-- Check Core Services safety features
SELECT id, name, route, icon, label, category, parent_id 
FROM menus 
WHERE category = 'safety' AND (purpose = 'home' OR purpose = 'more')
ORDER BY menu_order;
-- ============================================
-- SAFETY TUTORIALS, NEWS, AND LAWS MODULE MIGRATION
-- Created: 2026-03-08
-- Purpose: Add Safety Tutorial, News, and Laws modules with menus and permissions
-- ============================================

USE safety_app;

-- ============================================
-- 1. CREATE SAFETY_TUTORIALS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_tutorials (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    video_url VARCHAR(500),
    duration INT DEFAULT 0 COMMENT 'Duration in minutes',
    difficulty ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    is_premium BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_is_active (is_active),
    INDEX idx_difficulty (difficulty)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. CREATE SAFETY_NEWS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_news (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    summary TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    author VARCHAR(100),
    source VARCHAR(200),
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_featured BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_is_featured (is_featured),
    INDEX idx_is_active (is_active),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. CREATE SAFETY_LAWS TABLE
-- ============================================

CREATE TABLE IF NOT EXISTS safety_laws (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    jurisdiction VARCHAR(100),
    effective_date DATE,
    penalty TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_jurisdiction (jurisdiction),
    INDEX idx_is_active (is_active),
    INDEX idx_effective_date (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. ADD SAMPLE DATA FOR SAFETY_TUTORIALS
-- ============================================

INSERT INTO safety_tutorials (id, title, description, content, category, image_url, video_url, duration, difficulty, is_premium, is_active) VALUES
(UUID(), 'Self-Defense Basics', 'Learn essential self-defense techniques every woman should know', '<h2>Basic Self-Defense Techniques</h2><p>This tutorial covers fundamental self-defense moves including:</p><ul><li>Palm strike</li><li>Knee defense</li><li>Escaping wrist grabs</li><li>Creating distance</li></ul>', 'self-defense', 'https://images.unsplash.com/photo-1551632811-561732d1e306?w=800', 'https://example.com/videos/self-defense-basics.mp4', 30, 'beginner', FALSE, TRUE),
(UUID(), 'Digital Safety Guide', 'Protect yourself from online threats and harassment', '<h2>Digital Safety Essentials</h2><p>Learn how to:</p><ul><li>Secure your social media accounts</li><li>Recognize phishing attempts</li><li>Protect your personal information</li><li>Handle online harassment</li></ul>', 'digital-safety', 'https://images.unsplash.com/photo-1563206767-5b1d97289374?w=800', 'https://example.com/videos/digital-safety.mp4', 45, 'beginner', FALSE, TRUE),
(UUID(), 'Travel Safety Tips', 'Stay safe while traveling alone', '<h2>Safe Travel Guidelines</h2><p>Essential tips for solo travelers:</p><ul><li>Research your destination</li><li>Share your itinerary</li><li>Choose safe accommodations</li><li>Stay aware of your surroundings</li></ul>', 'travel-safety', 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=800', 'https://example.com/videos/travel-safety.mp4', 25, 'beginner', FALSE, TRUE),
(UUID(), 'Emergency Alert Systems', 'How to effectively use emergency alert systems', '<h2>Using Emergency Alerts</h2><p>Master the use of emergency apps and systems:</p><ul><li>SOS button usage</li><li>Location sharing</li><li>Emergency contacts setup</li><li>False alarm prevention</li></ul>', 'emergency', 'https://images.unsplash.com/photo-1517048676732-d65bc937f952?w=800', 'https://example.com/videos/emergency-alerts.mp4', 20, 'beginner', FALSE, TRUE),
(UUID(), 'Workplace Safety', 'Navigate workplace safety concerns confidently', '<h2>Workplace Safety Guide</h2><p>Protect yourself at work:</p><ul><li>Recognize warning signs</li><li>Document incidents properly</li><li>Know your rights</li><li>Build support networks</li></ul>', 'workplace', 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?w=800', 'https://example.com/videos/workplace-safety.mp4', 35, 'intermediate', FALSE, TRUE),
(UUID(), 'Advanced Self-Defense', 'Advanced techniques for personal protection', '<h2>Advanced Defense Moves</h2><p>For those ready to take their safety skills further:</p><ul><li>Breaking free from chokes</li><li>Using everyday objects for defense</li><li>Ground defense basics</li><li>Multiple attacker awareness</li></ul>', 'self-defense', 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800', 'https://example.com/videos/advanced-self-defense.mp4', 60, 'advanced', TRUE, TRUE),
(UUID(), 'Home Security', 'Secure your home from potential threats', '<h2>Home Security Essentials</h2><p>Make your home safer:</p><ul><li>Lock security basics</li><li>Smart home security</li><li>Safe rooms and hiding spots</li><li>Neighborhood safety</li></ul>', 'home-safety', 'https://images.unsplash.com/photo-1558002038-1055907df827?w=800', 'https://example.com/videos/home-security.mp4', 40, 'beginner', FALSE, TRUE);

-- ============================================
-- 5. ADD SAMPLE DATA FOR SAFETY_NEWS
-- ============================================

INSERT INTO safety_news (id, title, summary, content, category, image_url, author, source, published_at, is_featured, is_active, views_count) VALUES
(UUID(), 'New Safety App Launches Nationwide', 'A revolutionary safety application has been launched to help women feel safer in public spaces', '<h2>New Safety App Available</h2><p>A new safety application has been launched nationwide, featuring real-time location sharing, emergency alerts, and community support networks.</p><p>The app aims to reduce response times during emergencies and provide peace of mind for women traveling alone.</p>', 'technology', 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800', 'Sarah Johnson', 'Safety Today', DATE_SUB(NOW(), INTERVAL 1 DAY), TRUE, TRUE, 1520),
(UUID(), 'Government Announces New Women Safety Initiative', 'A comprehensive new program aims to improve public safety infrastructure across major cities', '<h2>Women Safety Initiative 2026</h2><p>The government has announced a new initiative to improve safety in public spaces, including better street lighting, increased police patrols, emergency call boxes in high-risk areas.</p>', 'government', 'https://images.unsplash.com/photo-1575505586569-646b2ca898fc?w=800', 'Priya Sharma', 'National News', DATE_SUB(NOW(), INTERVAL 2 DAY), TRUE, TRUE, 2340),
(UUID(), 'Self-Defense Classes See Surge in Enrollment', 'More women are signing up for self-defense courses following recent safety awareness campaigns', '<h2>Self-Defense Training Popularity Grows</h2><p>Self-defense academies across the country report a 50% increase in enrollment, particularly among young professionals and college students.</p><p>Instructors attribute this to increased awareness about personal safety.</p>', 'lifestyle', 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800', 'Mike Chen', 'Health Weekly', DATE_SUB(NOW(), INTERVAL 3 DAY), FALSE, TRUE, 890),
(UUID(), 'Expert Tips for Safe Public Transportation', 'Transportation experts share essential tips for staying safe on buses, trains, and metros', '<h2>Safe Public Transit Guide</h2><p>Safety experts recommend these essential tips:</p><ul><li>Sit near the driver</li><li>Keep belongings secure</li><li>Trust your instincts</li><li>Know your stops</li></ul>', 'transportation', 'https://images.unsplash.com/photo-1542361800-716d50c7c9eb?w=800', 'Anita Rao', 'City Guide', DATE_SUB(NOW(), INTERVAL 4 DAY), FALSE, TRUE, 650),
(UUID(), 'Cyber Safety: Protecting Your Digital Identity', 'Cybersecurity experts warn about rising online threats targeting women', '<h2>Digital Safety Alert</h2><p>With the increase in online activities, cybersecurity experts are warning about new threats targeting women online, including identity theft and harassment.</p><p>Experts recommend using strong passwords and being cautious about sharing personal information.</p>', 'technology', 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800', 'David Kim', 'Tech Security', DATE_SUB(NOW(), INTERVAL 5 DAY), TRUE, TRUE, 1100),
(UUID(), 'Community Watch Programs Expanding', 'Neighborhood watch programs are expanding with new technology integration', '<h2>Modern Community Safety</h2><p>Community watch programs are getting a tech upgrade with real-time reporting apps and neighborhood communication platforms.</p><p>These programs have shown to reduce crime rates by up to 30% in participating areas.</p>', 'community', 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800', 'Lisa Park', 'Local News', DATE_SUB(NOW(), INTERVAL 6 DAY), FALSE, TRUE, 420);

-- ============================================
-- 6. ADD SAMPLE DATA FOR SAFETY_LAWS
-- ============================================

INSERT INTO safety_laws (id, title, description, content, category, jurisdiction, effective_date, penalty, is_active) VALUES
(UUID(), 'Violence Against Women Act', 'Comprehensive legislation protecting women from violence and harassment', '<h2>Violence Against Women Act (VAWA)</h2><p>This landmark legislation provides:</p><ul><li>Protection orders</li><li>Legal representation for victims</li><li>Support services</li><li>Crime victim compensation</li></ul>', 'protection', 'Federal', '1994-09-13', 'Varies by offense - up to life imprisonment for severe cases', TRUE),
(UUID(), 'Workplace Harassment Prevention Law', 'Employers must maintain harassment-free workplace environments', '<h2>Workplace Harassment Prevention</h2><p>Key provisions include:</p><ul><li>Mandatory training programs</li><li>Confidential reporting systems</li><li>Prompt investigation requirements</li><li>Anti-retaliation protections</li></ul>', 'workplace', 'National', '2013-04-04', 'Fines up to $50,000 for first offense, higher for repeat violations', TRUE),
(UUID(), 'Stalking Prevention and Protection Act', 'Laws addressing stalking behavior and providing victim protections', '<h2>Anti-Stalking Legislation</h2><p>This law addresses:</p><ul><li>Electronic surveillance</li><li>Repeated unwanted contact</li><li>Cyber stalking</li><li>Protection order violations</li></ul>', 'harassment', 'State', '2020-01-01', 'Up to 5 years imprisonment and fines up to $10,000', TRUE),
(UUID(), 'Domestic Violence Protection Order', 'Legal mechanism to protect victims of domestic violence', '<h2>Domestic Violence Protection</h2><p>Protection orders can include:</p><ul><li>No-contact orders</li><li>Stay-away orders</li><li>Custody provisions</li><li>Financial support requirements</li></ul>', 'domestic', 'State', '1990-01-01', 'Violation can result in arrest and criminal charges', TRUE),
(UUID(), 'Sexual Harassment Compensation Act', 'Legislation ensuring compensation for sexual harassment victims', '<h2>Compensation for Harassment Victims</h2><p>This act provides:</p><ul><li>Monetary compensation guidelines</li><li>Legal fee coverage</li><li>Lost wages reimbursement</li><li>Emotional distress damages</li></ul>', 'workplace', 'National', '2018-07-01', 'Compensation based on severity and impact', TRUE),
(UUID(), 'Online Harassment Prevention Law', 'Addressing digital harassment and cyberbullying', '<h2>Cyber Harassment Prevention</h2><p>The law covers:</p><ul><li>Online threats</li><li>Cyberbullying</li><li>Non-consensual sharing of content</li><li>Online impersonation</li></ul>', 'digital', 'Federal', '2022-06-15', 'Up to 3 years imprisonment and fines', TRUE);

-- ============================================
-- 7. ADD MENU ENTRIES FOR SAFETY MODULES
-- ============================================

-- Add Safety Tutorials to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-more', 15, 'SafetyTutorial', 'book-open', 'Safety Tutorials', 'Learn essential safety skills', '#8B5CF6', 'more', 'mobile', TRUE, '["safety.tutorial.view"]', '["safety_tutorial:view"]', 'safety', NOW(), NOW());

-- Add Safety News to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-more', 16, 'SafetyNews', 'newspaper', 'Safety News', 'Latest safety news & updates', '#3B82F6', 'more', 'mobile', TRUE, '["safety.news.view"]', '["safety_news:view"]', 'safety', NOW(), NOW());

-- Add Safety Laws to More menu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-more', 17, 'SafetyLaw', 'shield', 'Safety Laws', 'Know your legal rights', '#10B981', 'more', 'mobile', TRUE, '["safety.laws.view"]', '["safety_laws:view"]', 'safety', NOW(), NOW());

-- ============================================
-- 8. ADD MENU ENTRIES TO HOME SECTION (Core Services)
-- ============================================

-- Add Safety Tutorials to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-core-services-container', 20, 'SafetyTutorial', 'book-open', 'Safety Tutorials', 'Learn essential safety skills', '#8B5CF6', 'home', 'mobile', TRUE, '["safety.tutorial.view"]', '["safety_tutorial:view"]', 'safety', NOW(), NOW());

-- Add Safety News to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-core-services-container', 21, 'SafetyNews', 'newspaper', 'Safety News', 'Latest safety news & updates', '#3B82F6', 'home', 'mobile', TRUE, '["safety.news.view"]', '["safety_news:view"]', 'safety', NOW(), NOW());

-- Add Safety Laws to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-core-services-container', 22, 'SafetyLaw', 'shield', 'Safety Laws', 'Know your legal rights', '#10B981', 'home', 'mobile', TRUE, '["safety.laws.view"]', '["safety_laws:view"]', 'safety', NOW(), NOW());

-- ============================================
-- 9. ADD PERMISSIONS FLAGS TO EXISTING USERS
-- ============================================

-- Add safety_tutorial permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.tutorial.view', true, '$.safety.tutorial.create', true, '$.safety.tutorial.edit', true, '$.safety.tutorial.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_tutorial.view', true, '$.safety_tutorial.create', true, '$.safety_tutorial.edit', true, '$.safety_tutorial.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_news permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.news.view', true, '$.safety.news.create', true, '$.safety.news.edit', true, '$.safety.news.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_news.view', true, '$.safety_news.create', true, '$.safety_news.edit', true, '$.safety_news.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_laws permissions to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.laws.view', true, '$.safety.laws.create', true, '$.safety.laws.edit', true, '$.safety.laws.delete', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_laws.view', true, '$.safety_laws.create', true, '$.safety_laws.edit', true, '$.safety_laws.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ============================================
-- 10. ADD PERMISSIONS FLAGS TO ROLE_PERMISSIONS TABLE
-- ============================================

-- Add safety_tutorial permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.tutorial.view', true, '$.safety.tutorial.create', true, '$.safety.tutorial.edit', true, '$.safety.tutorial.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_tutorial.view', true, '$.safety_tutorial.create', true, '$.safety_tutorial.edit', true, '$.safety_tutorial.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_news permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.news.view', true, '$.safety.news.create', true, '$.safety.news.edit', true, '$.safety.news.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_news.view', true, '$.safety_news.create', true, '$.safety_news.edit', true, '$.safety_news.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_laws permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.laws.view', true, '$.safety.laws.create', true, '$.safety.laws.edit', true, '$.safety.laws.delete', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_laws.view', true, '$.safety_laws.create', true, '$.safety_laws.edit', true, '$.safety_laws.delete', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ============================================
-- 11. VERIFICATION QUERIES
-- ============================================

SELECT 'Safety Modules Migration Completed Successfully!' AS message;

-- Verify tables were created
SELECT TABLE_NAME FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'safety_app' 
AND TABLE_NAME IN ('safety_tutorials', 'safety_news', 'safety_laws');

-- Verify sample data
SELECT 'safety_tutorials', COUNT(*) AS record_count FROM safety_tutorials
UNION ALL
SELECT 'safety_news', COUNT(*) FROM safety_news
UNION ALL
SELECT 'safety_laws', COUNT(*) FROM safety_laws;

-- Verify menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions 
FROM menus 
WHERE id IN ('menu-safety-tutorials', 'menu-safety-news', 'menu-safety-laws', 'svc-safety-tutorials', 'svc-safety-news', 'svc-safety-laws');

-- Verify permissions were added
SELECT id, JSON_EXTRACT(flags, '$.safety.tutorial.view') AS tutorial_view,
       JSON_EXTRACT(flags, '$.safety.news.view') AS news_view,
       JSON_EXTRACT(flags, '$.safety.laws.view') AS laws_view
FROM role_permissions;
-- ==============================================================================
-- WOMEN SAFETY, SAFETY MAP, AND SAFE ROUTE MODULES MIGRATION
-- Created: 2026-03-08
-- Purpose: Add database tables for Women Safety, Safety Map, and Safe Route modules
-- ==============================================================================

USE safety_app;

-- ==============================================================================
-- PART 1: WOMEN SAFETY MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 1.1 SOS ALERTS LOG (Enhanced version)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sos_alerts_log (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type ENUM('sos', 'panic', 'distress', 'emergency') DEFAULT 'sos',
    status ENUM('initiated', 'in_progress', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'initiated',
    latitude DOUBLE,
    longitude DOUBLE,
    address VARCHAR(500),
    accuracy DECIMAL(10,2),
    trigger_method ENUM('button', 'shake', 'voice', 'timer', 'auto') DEFAULT 'button',
    message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status),
    INDEX idx_alert_type (alert_type),
    INDEX idx_started_at (started_at),
    INDEX idx_is_active (is_active),
    INDEX idx_location (latitude, longitude)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.2 SOS LOCATION HISTORY (Track SOS location updates)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sos_location_history (
    id VARCHAR(36) PRIMARY KEY,
    sos_alert_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    accuracy DECIMAL(10,2),
    speed DECIMAL(10,2),
    heading DECIMAL(10,2),
    altitude DOUBLE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_sos_alert_id (sos_alert_id),
    INDEX idx_user_id (user_id),
    INDEX idx_timestamp (timestamp)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.3 FAKE CALL LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fake_call_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    caller_name VARCHAR(100) NOT NULL,
    caller_number VARCHAR(20),
    scheduled_duration INT DEFAULT 30 COMMENT 'Duration in seconds',
    actual_duration INT DEFAULT 0 COMMENT 'Actual duration in seconds',
    ringtone_type VARCHAR(50) DEFAULT 'default',
    call_status ENUM('scheduled', 'ringing', 'answered', 'missed', 'cancelled', 'completed') DEFAULT 'scheduled',
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    is_automated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_call_status (call_status),
    INDEX idx_scheduled_at (scheduled_at),
    INDEX idx_started_at (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.4 FAKE CALL SETTINGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS fake_call_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    default_caller_name VARCHAR(100) DEFAULT 'Mom',
    default_caller_number VARCHAR(20),
    default_duration INT DEFAULT 30,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    vibration_enabled BOOLEAN DEFAULT TRUE,
    answer_automatically BOOLEAN DEFAULT FALSE,
    custom_greeting TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.5 SIREN LOGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS siren_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    siren_type ENUM('panic', 'emergency', 'car', 'custom') DEFAULT 'panic',
    volume_level INT DEFAULT 100 COMMENT 'Volume percentage 0-100',
    duration_seconds INT DEFAULT 0,
    trigger_method ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
    latitude DOUBLE,
    longitude DOUBLE,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_siren_type (siren_type),
    INDEX idx_started_at (started_at),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.6 RECORDING LOGS (Audio/Video)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS recording_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sos_alert_id VARCHAR(36),
    recording_type ENUM('audio', 'video', 'both') DEFAULT 'audio',
    file_path VARCHAR(500),
    file_size BIGINT COMMENT 'Size in bytes',
    duration_seconds INT DEFAULT 0,
    format VARCHAR(20) DEFAULT 'm4a',
    quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DOUBLE,
    longitude DOUBLE,
    is_automatically_triggered BOOLEAN DEFAULT FALSE,
    transcription TEXT,
    is_uploaded BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    recording_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recording_ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_sos_alert_id (sos_alert_id),
    INDEX idx_recording_type (recording_type),
    INDEX idx_recording_started_at (recording_started_at),
    INDEX idx_is_uploaded (is_uploaded),
    INDEX idx_is_deleted (is_deleted)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 1.7 WOMEN SAFETY PREFERENCES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS women_safety_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    sos_enabled BOOLEAN DEFAULT TRUE,
    sos_button_size ENUM('small', 'medium', 'large') DEFAULT 'large',
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_auto_call_enabled BOOLEAN DEFAULT FALSE,
    sos_location_sharing_enabled BOOLEAN DEFAULT TRUE,
    sos_notify_contacts BOOLEAN DEFAULT TRUE,
    sos_message_template TEXT,
    fake_call_enabled BOOLEAN DEFAULT TRUE,
    siren_enabled BOOLEAN DEFAULT TRUE,
    auto_recording_on_sos BOOLEAN DEFAULT TRUE,
    audio_quality ENUM('low', 'medium', 'high') DEFAULT 'high',
    video_quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    shake_to_activate BOOLEAN DEFAULT FALSE,
    voice_activation_enabled BOOLEAN DEFAULT FALSE,
    voice_activation_phrase VARCHAR(100),
    timer_based_sos BOOLEAN DEFAULT FALSE,
    timer_duration_minutes INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 2: SAFETY MAP MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 2.1 MAP INCIDENTS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS map_incidents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    incident_type ENUM('harassment', 'assault', 'theft', 'suspicious_activity', 'unsafe_area', 'police_presence', 'accident', 'road_block', 'natural_disaster', 'other') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by VARCHAR(36),
    verification_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    report_count INT DEFAULT 1,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    photo_url VARCHAR(500),
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    tags JSON,
    expires_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_incident_type (incident_type),
    INDEX idx_severity (severity),
    INDEX idx_location (latitude, longitude),
    INDEX idx_city (city),
    INDEX idx_is_verified (is_verified),
    INDEX idx_verification_status (verification_status),
    INDEX idx_is_active (is_active),
    INDEX idx_created_at (created_at),
    INDEX idx_expires_at (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.2 SAFE ZONES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS safe_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    zone_type ENUM('police_station', 'hospital', 'fire_station', 'public_space', 'cafe', 'shop', 'residential', 'public_transport', 'other') NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500 COMMENT 'Zone radius in meters',
    zone_shape ENUM('circle', 'polygon') DEFAULT 'circle',
    polygon_coords JSON,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    amenity_details JSON COMMENT 'Details like operating hours, phone, etc.',
    safety_rating DECIMAL(3,2) DEFAULT 5.00 COMMENT 'Safety rating 1-5',
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_zone_type (zone_type),
    INDEX idx_location (latitude, longitude),
    INDEX idx_city (city),
    INDEX idx_is_verified (is_verified),
    INDEX idx_is_public (is_public),
    INDEX idx_is_active (is_active),
    INDEX idx_safety_rating (safety_rating)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.3 AREA SAFETY RATINGS
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS area_safety_ratings (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    center_latitude DOUBLE NOT NULL,
    center_longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 1000,
    overall_rating DECIMAL(3,2) DEFAULT 3.00,
    incident_count INT DEFAULT 0,
    safe_zone_count INT DEFAULT 0,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    rating_breakdown JSON COMMENT '{"harassment": 3.0, "theft": 3.5, "assault": 4.0, "overall": 3.5}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_area_name (area_name),
    INDEX idx_city (city),
    INDEX idx_location (center_latitude, center_longitude),
    INDEX idx_overall_rating (overall_rating),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 2.4 INCIDENT VOTES (Community verification)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incident_votes (
    id VARCHAR(36) PRIMARY KEY,
    incident_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    vote_type ENUM('upvote', 'downvote') DEFAULT 'upvote',
    is_helpful BOOLEAN DEFAULT TRUE,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES map_incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_incident_user_vote (incident_id, user_id),
    INDEX idx_incident_id (incident_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 3: SAFE ROUTE MODULE TABLES
-- ==============================================================================

-- ------------------------------------------------------------------------------
-- 3.1 ROUTE HISTORY
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    origin_name VARCHAR(255),
    origin_latitude DOUBLE NOT NULL,
    origin_longitude DOUBLE NOT NULL,
    destination_name VARCHAR(255),
    destination_latitude DOUBLE NOT NULL,
    destination_longitude DOUBLE NOT NULL,
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    route_distance DECIMAL(10,2) COMMENT 'Distance in kilometers',
    route_duration INT COMMENT 'Duration in minutes',
    safety_score DECIMAL(5,2) COMMENT 'Safety score 0-100',
    route_path JSON COMMENT 'Encoded polyline or coordinates array',
    alternative_routes JSON COMMENT 'Alternative routes if any',
    is_favorite BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_travel_mode (travel_mode),
    INDEX idx_safety_score (safety_score),
    INDEX idx_is_favorite (is_favorite),
    INDEX idx_is_completed (is_completed),
    INDEX idx_started_at (started_at),
    INDEX idx_completed_at (completed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.2 ROUTE PREFERENCES
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    preferred_travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    avoid_highways BOOLEAN DEFAULT FALSE,
    avoid_tolls BOOLEAN DEFAULT FALSE,
    avoid_ferries BOOLEAN DEFAULT FALSE,
    prefer_lit_streets BOOLEAN DEFAULT TRUE,
    prefer_popular_areas BOOLEAN DEFAULT TRUE,
    minimum_safety_score INT DEFAULT 50 COMMENT 'Minimum safety score threshold',
    maximum_walk_distance INT DEFAULT 2000 COMMENT 'Max walking distance in meters',
    prefer_alternative_routes BOOLEAN DEFAULT TRUE,
    time_of_day_preference JSON COMMENT '{"morning": "8:00", "evening": "18:00"}',
    saved_locations JSON COMMENT 'Saved locations for quick access',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.3 ROUTE WAYPOINTS (Waypoints along a route)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS route_waypoints (
    id VARCHAR(36) PRIMARY KEY,
    route_id VARCHAR(36) NOT NULL,
    waypoint_order INT NOT NULL,
    waypoint_name VARCHAR(255),
    waypoint_type ENUM('safety_check', 'safe_zone', 'police_station', 'hospital', 'cafe', 'rest_stop', 'other') DEFAULT 'safety_check',
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    distance_from_start DECIMAL(10,2) COMMENT 'Distance from start in km',
    estimated_time_from_start INT COMMENT 'Time from start in minutes',
    safety_rating DECIMAL(3,2),
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES route_history(id) ON DELETE CASCADE,
    INDEX idx_route_id (route_id),
    INDEX idx_waypoint_order (waypoint_order),
    INDEX idx_waypoint_type (waypoint_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------------------
-- 3.4 SAFETY TIPS (AI-generated or curated safety tips)
-- ------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS safety_tips (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('general', 'walking', 'driving', 'public_transport', 'night', 'emergency', 'digital') DEFAULT 'general',
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit', 'all') DEFAULT 'all',
    time_of_day ENUM('morning', 'afternoon', 'evening', 'night', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_travel_mode (travel_mode),
    INDEX idx_time_of_day (time_of_day),
    INDEX idx_is_active (is_active),
    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- PART 4: ADD MENU ENTRIES FOR NEW MODULES
-- ==============================================================================

-- Add Women Safety menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-women-safety', 'Women Safety', 'primary', TRUE, '[]', 'menu-more', 10, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'Personal safety features', '#EC4899', 'more', 'mobile', TRUE, '["women.safety.view"]', '["women_safety:view"]', 'safety', NOW(), NOW());

-- Add Safety Map menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-more', 11, 'SafetyMap', 'map', 'Safety Map', 'Community safety map', '#10B981', 'more', 'mobile', TRUE, '["safety.map.view"]', '["safety_map:view"]', 'safety', NOW(), NOW());

-- Add Safe Route menu under More
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-more', 12, 'SafeRoute', 'navigate', 'Safe Route', 'AI-powered safe routes', '#3B82F6', 'more', 'mobile', TRUE, '["safe.route.view"]', '["safe_route:view"]', 'safety', NOW(), NOW());

-- Add Fake Call to Women Safety submenu
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('menu-women-safety-fake-call', 'Fake Call', 'secondary', TRUE, '[]', 'menu-women-safety', 1, 'FakeCall', 'call', 'Fake Call', 'Simulate incoming calls', '#8B5CF6', 'more', 'mobile', TRUE, '["fake.call.use"]', '["fake_call:use"]', 'safety', NOW(), NOW());

-- Add Women Safety to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-women-safety', 'Women Safety', 'primary', TRUE, '[]', 'menu-core-services-container', 10, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'Personal safety features', '#EC4899', 'home', 'mobile', TRUE, '["women.safety.view"]', '["women_safety:view"]', 'safety', NOW(), NOW());

-- Add Safety Map to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-core-services-container', 11, 'SafetyMap', 'map', 'Safety Map', 'Community safety map', '#10B981', 'home', 'mobile', TRUE, '["safety.map.view"]', '["safety_map:view"]', 'safety', NOW(), NOW());

-- Add Safe Route to Core Services
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category, created_at, updated_at) VALUES
('svc-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-core-services-container', 12, 'SafeRoute', 'navigate', 'Safe Route', 'AI-powered safe routes', '#3B82F6', 'home', 'mobile', TRUE, '["safe.route.view"]', '["safe_route:view"]', 'safety', NOW(), NOW());

-- ==============================================================================
-- PART 5: ADD PERMISSIONS TO EXISTING USERS AND ROLES
-- ==============================================================================

-- Add women_safety permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.women.safety.view', true, '$.women.safety.sos', true, '$.women.safety.fakeCall', true, '$.women.safety.siren', true, '$.women.safety.recording', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.women_safety.view', true, '$.women_safety.sos', true, '$.women_safety.fake_call', true, '$.women_safety.siren', true, '$.women_safety.recording', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_map permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.map.view', true, '$.safety.map.report', true, '$.safety.map.vote', true, '$.safe.zone.add', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safety_map.view', true, '$.safety_map.report', true, '$.safety_map.vote', true, '$.safe_zone.add', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safe_route permissions to all existing users
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safe.route.view', true, '$.safe.route.create', true, '$.safe.route.history', true, '$.safe.route.favorite', true),
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.safe_route.view', true, '$.safe_route.create', true, '$.safe_route.history', true, '$.safe_route.favorite', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add women_safety permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.women.safety.view', true, '$.women.safety.sos', true, '$.women.safety.fakeCall', true, '$.women.safety.siren', true, '$.women.safety.recording', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.women_safety.view', true, '$.women_safety.sos', true, '$.women_safety.fake_call', true, '$.women_safety.siren', true, '$.women_safety.recording', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safety_map permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safety.map.view', true, '$.safety.map.report', true, '$.safety.map.vote', true, '$.safe.zone.add', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safety_map.view', true, '$.safety_map.report', true, '$.safety_map.vote', true, '$.safe_zone.add', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- Add safe_route permissions to all roles
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.safe.route.view', true, '$.safe.route.create', true, '$.safe.route.history', true, '$.safe.route.favorite', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.safe_route.view', true, '$.safe_route.create', true, '$.safe_route.history', true, '$.safe_route.favorite', true)
WHERE flags IS NOT NULL OR flags IS NULL;

-- ==============================================================================
-- PART 6: ADD SAMPLE DATA
-- ==============================================================================

-- Add sample safety tips
INSERT INTO safety_tips (id, title, content, category, travel_mode, time_of_day, is_active, display_order) VALUES
(UUID(), 'Stay Aware of Your Surroundings', 'Always be aware of your surroundings. Avoid using headphones or looking at your phone while walking, especially in unfamiliar areas.', 'general', 'walking', 'all', TRUE, 1),
(UUID(), 'Trust Your Instincts', 'If something feels wrong, trust your gut feelings. It\'s better to be safe than sorry. Leave the area immediately if you feel unsafe.', 'general', 'all', 'all', TRUE, 2),
(UUID(), 'Share Your Itinerary', 'Always share your travel plans with a trusted friend or family member. Keep them updated on your whereabouts.', 'general', 'all', 'all', TRUE, 3),
(UUID(), 'Use Well-Lit Paths', 'Stick to well-lit, populated areas when walking at night. Avoid shortcuts through dark alleys or isolated areas.', 'walking', 'walking', 'night', TRUE, 4),
(UUID(), 'Keep Emergency Contacts Handy', 'Save emergency contacts on speed dial. Include local police and emergency services numbers.', 'emergency', 'all', 'all', TRUE, 5),
(UUID(), 'Plan Your Route in Advance', 'Before heading out, plan your route and familiarise yourself with the area. Know where police stations and safe zones are located.', 'general', 'all', 'all', TRUE, 6),
(UUID(), 'Avoid Isolated Bus Stops', 'Wait at busy, well-lit bus stops. If possible, travel with a companion during late hours.', 'public_transport', 'transit', 'night', TRUE, 7),
(UUID(), 'Lock Your Vehicle', 'Always lock your car doors and keep windows closed. Never leave valuables visible inside your vehicle.', 'driving', 'driving', 'all', TRUE, 8);

-- ==============================================================================
-- PART 7: VERIFICATION QUERIES
-- ==============================================================================

SELECT 'Women Safety, Safety Map, and Safe Route Modules Migration Completed Successfully!' AS message;

-- Verify tables were created
SELECT TABLE_NAME FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'safety_app' 
AND TABLE_NAME IN (
    'sos_alerts_log', 'sos_location_history', 'fake_call_logs', 'fake_call_settings', 
    'siren_logs', 'recording_logs', 'women_safety_preferences',
    'map_incidents', 'safe_zones', 'area_safety_ratings', 'incident_votes',
    'route_history', 'route_preferences', 'route_waypoints', 'safety_tips'
);

-- Verify menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions 
FROM menus 
WHERE id IN (
    'menu-women-safety', 'menu-safety-map', 'menu-safe-route', 
    'menu-women-safety-fake-call',
    'svc-women-safety', 'svc-safety-map', 'svc-safe-route'
);

-- Verify sample data
SELECT 'safety_tips', COUNT(*) AS record_count FROM safety_tips;
-- Migration: Add Extended Roles, SOS Cases, and Area-Based Access Control
-- Created: 2026-03-08
-- Description: Adds new roles for authorities and community leaders, plus SOS case management

-- ============================================
-- GEOGRAPHIC AREAS TABLE (Villages/Wards)
-- ============================================
CREATE TABLE IF NOT EXISTS geographic_areas (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
    parent_area_id VARCHAR(36) DEFAULT NULL,
    code VARCHAR(50) UNIQUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    population INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL
);

CREATE INDEX idx_areas_parent ON geographic_areas(parent_area_id);
CREATE INDEX idx_areas_type ON geographic_areas(type);
CREATE INDEX idx_areas_code ON geographic_areas(code);

-- ============================================
-- USER AREA ASSIGNMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_area_assignments (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    area_id VARCHAR(36) NOT NULL,
    role_in_area ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
    is_primary BOOLEAN DEFAULT FALSE,
    assigned_by VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_area (user_id, area_id, is_primary)
);

CREATE INDEX idx_user_area_user ON user_area_assignments(user_id);
CREATE INDEX idx_user_area_area ON user_area_assignments(area_id);
CREATE INDEX idx_user_area_active ON user_area_assignments(is_active);

-- ============================================
-- SOS CASES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS sos_cases (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    
    -- Victim Information
    victim_user_id VARCHAR(36),
    victim_name VARCHAR(100),
    victim_phone VARCHAR(20),
    victim_area_id VARCHAR(36),
    
    -- Case Details
    status ENUM('pending', 'acknowledged', 'investigating', 'resolved', 'closed', 'escalated') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    category VARCHAR(100),
    description TEXT,
    
    -- Location
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address TEXT,
    area_id VARCHAR(36),
    
    -- Assignment
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by VARCHAR(36),
    
    -- Resolution
    resolution_notes TEXT,
    resolved_at TIMESTAMP NULL,
    resolved_by VARCHAR(36),
    
    -- Timeline
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (victim_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_sos_cases_status ON sos_cases(status);
CREATE INDEX idx_sos_cases_priority ON sos_cases(priority);
CREATE INDEX idx_sos_cases_area ON sos_cases(area_id);
CREATE INDEX idx_sos_cases_assigned ON sos_cases(assigned_to);
CREATE INDEX idx_sos_cases_victim ON sos_cases(victim_user_id);
CREATE INDEX idx_sos_cases_number ON sos_cases(case_number);

-- ============================================
-- SOS CASE ACTIVITY LOG
-- ============================================
CREATE TABLE IF NOT EXISTS sos_case_activity (
    id VARCHAR(36) PRIMARY KEY,
    case_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES sos_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_case_activity_case ON sos_case_activity(case_id);
CREATE INDEX idx_case_activity_user ON sos_case_activity(user_id);

-- ============================================
-- ROLE ASSIGNMENTS LOG (Audit Trail)
-- ============================================
CREATE TABLE IF NOT EXISTS role_assignment_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    previous_role VARCHAR(50),
    new_role VARCHAR(50) NOT NULL,
    assigned_by VARCHAR(36),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_role_history_user ON role_assignment_history(user_id);
CREATE INDEX idx_role_history_date ON role_assignment_history(created_at);

-- ============================================
-- INSERT NEW ROLE PERMISSIONS
-- ============================================

-- System Admin - Can manage all admins and system settings
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', '
{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true } }
', '
{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Agency Admin - Can manage agency-specific users and cases
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'agency_admin', '
{ "sos.emergency": true, "sos.manage_agency": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": false, "areas.manage": true, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": true, "delete": false, "assign_roles": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": false }, "automation": { "read": true, "write": false }, "areas": { "read": true, "write": true }, "roles": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["SystemSettings", "RoleManagement"], "readOnlyFields": ["user.role", "system_settings"], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Local Police - Can view and manage SOS in their jurisdiction
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'local_police', '
{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "sos.investigate": true, "sos.resolve": true, "ai.chat": false, "ai.vision": true, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true, "investigate": true, "resolve": true, "assign": false }, "ai": { "read": false, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "WomenSafety", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_features", "family_tracking"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Village Head / Ward Admin - Community leader oversight
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'village_head', '
{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "ai.chat": true, "ai.vision": false, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_vision", "advanced_settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Supervisor - Can manage field workers/volunteers
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'supervisor', '
{ "sos.emergency": true, "sos.view_area": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "assign": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["role_management", "system_settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- ============================================
-- ADD AREA COLUMN TO USERS TABLE (if not exists)
-- ============================================
-- Note: This is a one-time migration, will be skipped if column exists
-- ALTER TABLE users ADD COLUMN area_id VARCHAR(36) DEFAULT NULL;
-- ALTER TABLE users ADD FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL;

-- ============================================
-- ADD ROLE COLUMN TO USERS TABLE FOR SYSTEM ADMIN FLAG (if not exists)
-- ============================================
-- Note: Admin level hierarchy
-- admin - standard admin
-- system_admin - super admin (can manage other admins)

-- ============================================
-- INSERT SAMPLE GEOGRAPHIC AREAS (India - Sample)
-- ============================================
INSERT INTO geographic_areas (id, name, type, code, is_active) VALUES
(UUID(), 'Maharashtra', 'state', 'MH', TRUE),
(UUID(), 'Uttar Pradesh', 'state', 'UP', TRUE),
(UUID(), 'Karnataka', 'state', 'KA', TRUE)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ============================================
-- GRANT PERMISSIONS TO ADMIN ROLE (Extend existing)
-- ============================================
UPDATE role_permissions 
SET flags = JSON_SET(flags, '$.users.manage', TRUE, '$.areas.manage', TRUE, '$.sos.case_management', TRUE)
WHERE role = 'admin';

-- Migration complete
SELECT 'Migration 012: Extended roles, SOS cases, and area-based access created successfully' as message;
-- ==============================================================================
-- WOMEN SAFETY APP - MISSING TABLES MIGRATION
-- Created: 2026-03-13
-- Purpose: Add missing tables from safety_app_2026_03_8.sql to safety_dump_2026_03_13.sql
-- Password: Password@123 for all users
-- Bcrypt: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ==============================================================================

USE safety_app;

-- ==============================================================================
-- FAMILIES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS families (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY RELATIONSHIPS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_relationships (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    from_user_id VARCHAR(36) NOT NULL,
    to_user_id VARCHAR(36) NOT NULL,
    relationship_type ENUM('parent', 'child', 'spouse', 'sibling', 'grandparent', 'grandchild', 'other') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_relationship (family_id, from_user_id, to_user_id, relationship_type),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY PLACES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_places (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    place_type ENUM('home', 'school', 'daycare', 'park', 'clinic', 'hospital', 'relative_home', 'work', 'sports', 'other') NOT NULL,
    address TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius_meters INT DEFAULT 100,
    privacy_tag ENUM('do_not_log') DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CONTEXT SNAPSHOTS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS context_snapshots (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    place_id VARCHAR(36),
    place_type VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_type ENUM('arriving', 'leaving', 'dwell', 'transit') DEFAULT 'dwell',
    candidate_context_types JSON,
    confidence DECIMAL(3, 2) DEFAULT 0.50,
    raw_event_ids JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SUGGESTIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS suggestions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    type ENUM('log_activity', 'reminder', 'safety_prompt', 'photo_suggestion') NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    status ENUM('pending', 'shown', 'accepted', 'dismissed', 'snoozed') DEFAULT 'pending',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shown_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL
);

-- ==============================================================================
-- FAMILY ACTIVITY LOGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_activity_logs (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    activity_type VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    started_at TIMESTAMP NOT NULL,
    ended_at TIMESTAMP NULL,
    place_id VARCHAR(36),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- CONSENT SETTINGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS consent_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    location_enabled BOOLEAN DEFAULT FALSE,
    activity_enabled BOOLEAN DEFAULT FALSE,
    calendar_enabled BOOLEAN DEFAULT FALSE,
    analytics_enabled BOOLEAN DEFAULT FALSE,
    family_agent_enabled BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME NULL,
    quiet_hours_end TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- AUDIT LOGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    family_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id VARCHAR(36),
    metadata JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE SET NULL
);

-- ==============================================================================
-- USER THEMES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

-- ==============================================================================
-- PERMISSIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

-- ==============================================================================
-- ROLE PERMISSIONS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

-- ==============================================================================
-- HOME DEVICES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS home_devices (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    device_type ENUM('light', 'fan', 'ac', 'door', 'camera', 'thermostat', 'plug', 'sensor') NOT NULL,
    room VARCHAR(100) DEFAULT 'Living Room',
    status ENUM('on', 'off') DEFAULT 'off',
    brightness INT DEFAULT 100,
    speed INT DEFAULT 0,
    temperature INT DEFAULT 24,
    is_locked BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- REFRESH TOKENS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CHILD ACTIVITIES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS child_activities (
    id VARCHAR(36) PRIMARY KEY,
    child_id VARCHAR(36) NOT NULL,
    activity_type ENUM('feeding', 'sleep', 'medicine', 'diaper', 'other') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
);

-- ==============================================================================
-- LOCATION HISTORY TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS location_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(6,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GEOFENCES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geofences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius INT DEFAULT 100,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- USER SETTINGS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    notification_enabled BOOLEAN DEFAULT TRUE,
    location_sharing BOOLEAN DEFAULT TRUE,
    auto_sos BOOLEAN DEFAULT FALSE,
    shake_to_sos BOOLEAN DEFAULT FALSE,
    sos_timer INT DEFAULT 30,
    shake_sensitivity INT DEFAULT 3,
    volume_press_enabled BOOLEAN DEFAULT FALSE,
    power_press_enabled BOOLEAN DEFAULT FALSE,
    voice_enabled BOOLEAN DEFAULT FALSE,
    auto_sos_enabled BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GEOGRAPHIC AREAS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geographic_areas (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
    parent_area_id VARCHAR(36) DEFAULT NULL,
    code VARCHAR(50) UNIQUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    population INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL
);

-- ==============================================================================
-- USER AREA ASSIGNMENTS TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_area_assignments (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    area_id VARCHAR(36) NOT NULL,
    role_in_area ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
    is_primary BOOLEAN DEFAULT FALSE,
    assigned_by VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_area (user_id, area_id, is_primary)
);

-- ==============================================================================
-- SOS CASES TABLE (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_cases (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    victim_user_id VARCHAR(36),
    victim_name VARCHAR(100),
    victim_phone VARCHAR(20),
    victim_area_id VARCHAR(36),
    status ENUM('pending', 'acknowledged', 'investigating', 'resolved', 'closed', 'escalated') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    category VARCHAR(100),
    description TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address TEXT,
    area_id VARCHAR(36),
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by VARCHAR(36),
    resolution_notes TEXT,
    resolved_at TIMESTAMP NULL,
    resolved_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (victim_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS CASE ACTIVITY LOG (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_case_activity (
    id VARCHAR(36) PRIMARY KEY,
    case_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES sos_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- ROLE ASSIGNMENT HISTORY (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_assignment_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    previous_role VARCHAR(50),
    new_role VARCHAR(50) NOT NULL,
    assigned_by VARCHAR(36),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS ALERTS LOG (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_alerts_log (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type ENUM('sos', 'panic', 'distress', 'emergency') DEFAULT 'sos',
    status ENUM('initiated', 'in_progress', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'initiated',
    latitude DOUBLE,
    longitude DOUBLE,
    address VARCHAR(500),
    accuracy DECIMAL(10,2),
    trigger_method ENUM('button', 'shake', 'voice', 'timer', 'auto') DEFAULT 'button',
    message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- WOMEN SAFETY PREFERENCES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS women_safety_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    sos_enabled BOOLEAN DEFAULT TRUE,
    sos_button_size ENUM('small', 'medium', 'large') DEFAULT 'large',
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_auto_call_enabled BOOLEAN DEFAULT FALSE,
    sos_location_sharing_enabled BOOLEAN DEFAULT TRUE,
    sos_notify_contacts BOOLEAN DEFAULT TRUE,
    sos_message_template TEXT,
    fake_call_enabled BOOLEAN DEFAULT TRUE,
    siren_enabled BOOLEAN DEFAULT TRUE,
    auto_recording_on_sos BOOLEAN DEFAULT TRUE,
    audio_quality ENUM('low', 'medium', 'high') DEFAULT 'high',
    video_quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    shake_to_activate BOOLEAN DEFAULT FALSE,
    voice_activation_enabled BOOLEAN DEFAULT FALSE,
    voice_activation_phrase VARCHAR(100),
    timer_based_sos BOOLEAN DEFAULT FALSE,
    timer_duration_minutes INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    caller_name VARCHAR(100) NOT NULL,
    caller_number VARCHAR(20),
    scheduled_duration INT DEFAULT 30,
    actual_duration INT DEFAULT 0,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    call_status ENUM('scheduled', 'ringing', 'answered', 'missed', 'cancelled', 'completed') DEFAULT 'scheduled',
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    is_automated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL SETTINGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    default_caller_name VARCHAR(100) DEFAULT 'Mom',
    default_caller_number VARCHAR(20),
    default_duration INT DEFAULT 30,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    vibration_enabled BOOLEAN DEFAULT TRUE,
    answer_automatically BOOLEAN DEFAULT FALSE,
    custom_greeting TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SIREN LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS siren_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    siren_type ENUM('panic', 'emergency', 'car', 'custom') DEFAULT 'panic',
    volume_level INT DEFAULT 100,
    duration_seconds INT DEFAULT 0,
    trigger_method ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
    latitude DOUBLE,
    longitude DOUBLE,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- RECORDING LOGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS recording_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sos_alert_id VARCHAR(36),
    recording_type ENUM('audio', 'video', 'both') DEFAULT 'audio',
    file_path VARCHAR(500),
    file_size BIGINT,
    duration_seconds INT DEFAULT 0,
    format VARCHAR(20) DEFAULT 'm4a',
    quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DOUBLE,
    longitude DOUBLE,
    is_automatically_triggered BOOLEAN DEFAULT FALSE,
    transcription TEXT,
    is_uploaded BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    recording_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recording_ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE SET NULL
);

-- ==============================================================================
-- MAP INCIDENTS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS map_incidents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    incident_type ENUM('harassment', 'assault', 'theft', 'suspicious_activity', 'unsafe_area', 'police_presence', 'accident', 'road_block', 'natural_disaster', 'other') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by VARCHAR(36),
    verification_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    report_count INT DEFAULT 1,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    photo_url VARCHAR(500),
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    tags JSON,
    expires_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SAFE ZONES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safe_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    zone_type ENUM('police_station', 'hospital', 'fire_station', 'public_space', 'cafe', 'shop', 'residential', 'public_transport', 'other') NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500,
    zone_shape ENUM('circle', 'polygon') DEFAULT 'circle',
    polygon_coords JSON,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    amenity_details JSON,
    safety_rating DECIMAL(3,2) DEFAULT 5.00,
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- AREA SAFETY RATINGS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS area_safety_ratings (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    center_latitude DOUBLE NOT NULL,
    center_longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 1000,
    overall_rating DECIMAL(3,2) DEFAULT 3.00,
    incident_count INT DEFAULT 0,
    safe_zone_count INT DEFAULT 0,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    rating_breakdown JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INCIDENT VOTES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS incident_votes (
    id VARCHAR(36) PRIMARY KEY,
    incident_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    vote_type ENUM('upvote', 'downvote') DEFAULT 'upvote',
    is_helpful BOOLEAN DEFAULT TRUE,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES map_incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_incident_user_vote (incident_id, user_id)
);

-- ==============================================================================
-- ROUTE HISTORY (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    origin_name VARCHAR(255),
    origin_latitude DOUBLE NOT NULL,
    origin_longitude DOUBLE NOT NULL,
    destination_name VARCHAR(255),
    destination_latitude DOUBLE NOT NULL,
    destination_longitude DOUBLE NOT NULL,
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    route_distance DECIMAL(10,2),
    route_duration INT,
    safety_score DECIMAL(5,2),
    route_path JSON,
    alternative_routes JSON,
    is_favorite BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- ROUTE PREFERENCES (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    preferred_travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    avoid_highways BOOLEAN DEFAULT FALSE,
    avoid_tolls BOOLEAN DEFAULT FALSE,
    avoid_ferries BOOLEAN DEFAULT FALSE,
    prefer_lit_streets BOOLEAN DEFAULT TRUE,
    prefer_popular_areas BOOLEAN DEFAULT TRUE,
    minimum_safety_score INT DEFAULT 50,
    maximum_walk_distance INT DEFAULT 2000,
    prefer_alternative_routes BOOLEAN DEFAULT TRUE,
    time_of_day_preference JSON,
    saved_locations JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SAFETY TIPS (Missing in dump)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_tips (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('general', 'walking', 'driving', 'public_transport', 'night', 'emergency', 'digital') DEFAULT 'general',
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit', 'all') DEFAULT 'all',
    time_of_day ENUM('morning', 'afternoon', 'evening', 'night', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INSERT ROLE PERMISSIONS (ALL 10 ROLES)
-- ==============================================================================

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', 
'{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'admin', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'woman', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- ==============================================================================
-- INSERT USER PERMISSIONS
-- ==============================================================================
INSERT INTO permissions (id, user_id, flags, permissions, ui_restrictions)
SELECT UUID(), id, 
    (SELECT flags FROM role_permissions WHERE role = users.role),
    (SELECT base_permissions FROM role_permissions WHERE role = users.role),
    (SELECT ui_restrictions FROM role_permissions WHERE role = users.role)
FROM users;

-- ==============================================================================
-- INSERT FAMILIES
-- ==============================================================================
INSERT INTO families (id, name, description, created_by) VALUES
('family-001', 'Patel Family', 'Rajesh Patel family', 'user-guardian-001'),
('family-002', 'Sharma Family', 'Priya Sharma family', 'user-guardian-002'),
('family-003', 'Kumar Family', 'Amit and Sneha Kumar family', 'user-parent-001'),
('family-004', 'Singh Family', 'Anjali Singh family', 'user-woman-001');

-- ==============================================================================
-- INSERT FAMILY MEMBERS
-- ==============================================================================
INSERT INTO family_members (id, family_id, user_id, role, nickname) VALUES
('fm-001', 'family-001', 'user-guardian-001', 'head', 'Dad'),
('fm-002', 'family-001', 'user-woman-001', 'member', 'Daughter'),
('fm-003', 'family-002', 'user-guardian-002', 'head', 'Mom'),
('fm-004', 'family-002', 'user-woman-003', 'member', 'Daughter'),
('fm-005', 'family-003', 'user-parent-001', 'head', 'Father'),
('fm-006', 'family-003', 'user-parent-002', 'head', 'Mother'),
('fm-007', 'family-004', 'user-woman-001', 'head', 'Self');

-- ==============================================================================
-- INSERT FAMILY PLACES
-- ==============================================================================
INSERT INTO family_places (id, family_id, name, place_type, address, latitude, longitude, radius_meters, is_active, created_by) VALUES
('fp-001', 'family-001', 'Patel Home', 'home', '123 Main Road, Mumbai', 19.0760, 72.8777, 100, TRUE, 'user-guardian-001'),
('fp-002', 'family-001', 'St. Mary School', 'school', '456 Education Lane, Mumbai', 19.0780, 72.8800, 200, TRUE, 'user-guardian-001'),
('fp-003', 'family-002', 'Sharma Residence', 'home', '789 Oak Street, Delhi', 28.6139, 77.2090, 100, TRUE, 'user-guardian-002'),
('fp-004', 'family-003', 'Kumar House', 'home', '321 Pine Avenue, Bangalore', 12.9716, 77.5946, 100, TRUE, 'user-parent-001');

-- ==============================================================================
-- INSERT GEOGRAPHIC AREAS
-- ==============================================================================
INSERT INTO geographic_areas (id, name, type, code, latitude, longitude, is_active) VALUES
('geo-state-mh', 'Maharashtra', 'state', 'MH', 19.7515, 75.7139, TRUE),
('geo-state-up', 'Uttar Pradesh', 'state', 'UP', 26.8467, 80.9462, TRUE),
('geo-district-mumbai', 'Mumbai', 'district', 'MH-MUM', 19.0760, 72.8777, TRUE),
('geo-district-delhi', 'Delhi', 'district', 'DL-DEL', 28.6139, 77.2090, TRUE);

-- ==============================================================================
-- INSERT USER AREA ASSIGNMENTS
-- ==============================================================================
INSERT INTO user_area_assignments (id, user_id, area_id, role_in_area, is_primary, assigned_by) VALUES
(UUID(), 'user-police-001', 'geo-district-mumbai', 'police', TRUE, 'user-system-admin-001'),
(UUID(), 'user-supervisor-001', 'geo-state-mh', 'supervisor', TRUE, 'user-system-admin-001');

-- ==============================================================================
-- INSERT HOME DEVICES
-- ==============================================================================
INSERT INTO home_devices (id, user_id, name, device_type, room, status, brightness, is_locked) VALUES
('hd-001', 'user-guardian-001', 'Living Room Light', 'light', 'Living Room', 'on', 80, TRUE),
('hd-002', 'user-guardian-001', 'Bedroom Fan', 'fan', 'Bedroom', 'on', 3, TRUE),
('hd-003', 'user-parent-001', 'Baby Room Monitor', 'camera', 'Baby Room', 'on', 0, TRUE);

-- ==============================================================================
-- INSERT GEOFENCES
-- ==============================================================================
INSERT INTO geofences (id, user_id, name, latitude, longitude, radius, is_active) VALUES
('geo-001', 'user-guardian-001', 'Home', 19.0760, 72.8777, 100, TRUE),
('geo-002', 'user-parent-001', 'Home', 12.9716, 77.5946, 100, TRUE);

-- ==============================================================================
-- INSERT LOCATION HISTORY
-- ==============================================================================
INSERT INTO location_history (id, user_id, latitude, longitude, accuracy) VALUES
('lh-001', 'user-woman-001', 13.0827, 80.2707, 10),
('lh-002', 'user-guardian-001', 19.0760, 72.8777, 5);

-- ==============================================================================
-- INSERT USER SETTINGS
-- ==============================================================================
INSERT INTO user_settings (id, user_id, notification_enabled, location_sharing, auto_sos, shake_to_sos, sos_timer, shake_sensitivity)
SELECT UUID(), id, TRUE, TRUE, FALSE, FALSE, 30, 3 FROM users;

-- ==============================================================================
-- INSERT WOMEN SAFETY PREFERENCES
-- ==============================================================================
INSERT INTO women_safety_preferences (id, user_id, sos_enabled, sos_button_size, sos_vibration_enabled, sos_sound_enabled, sos_location_sharing_enabled, fake_call_enabled, siren_enabled)
SELECT UUID(), id, TRUE, 'large', TRUE, TRUE, TRUE, TRUE, TRUE
FROM users WHERE role IN ('woman', 'parent', 'guardian');

-- ==============================================================================
-- INSERT FAKE CALL SETTINGS
-- ==============================================================================
INSERT INTO fake_call_settings (id, user_id, default_caller_name, default_duration, vibration_enabled, is_active)
SELECT UUID(), id, 'Mom', 30, TRUE, TRUE
FROM users WHERE role IN ('woman', 'parent', 'guardian');

-- ==============================================================================
-- INSERT SAFETY TIPS
-- ==============================================================================
INSERT IGNORE INTO safety_tips (id, title, content, category, travel_mode, time_of_day, is_active, display_order) VALUES
('tip-001', 'Stay Aware', 'Always be aware of your surroundings and trust your instincts', 'general', 'all', 'all', TRUE, 1),
('tip-002', 'Share Your Location', 'Keep your location shared with trusted contacts while traveling', 'general', 'walking', 'all', TRUE, 2),
('tip-003', 'Emergency Contacts', 'Keep emergency numbers saved and easily accessible', 'emergency', 'all', 'all', TRUE, 3),
('tip-004', 'Night Safety', 'Stay in well-lit areas and avoid shortcuts through dark alleys', 'walking', 'walking', 'night', TRUE, 4);

-- ==============================================================================
-- INSERT USER THEMES
-- ==============================================================================
INSERT INTO user_themes (id, user_id, theme_id, is_active)
SELECT UUID(), id, (SELECT id FROM themes LIMIT 1), TRUE FROM users;

-- ==============================================================================
-- INSERT CONSENT SETTINGS
-- ==============================================================================
INSERT INTO consent_settings (id, user_id, location_enabled, activity_enabled, family_agent_enabled)
SELECT UUID(), id, FALSE, FALSE, TRUE FROM users;

-- ==============================================================================
-- MIGRATION COMPLETE
-- ==============================================================================
SELECT 'Missing Tables Migration Complete - 2026-03-13' AS message;

-- ==============================================================================
-- END OF MIGRATION FILE
-- ==============================================================================