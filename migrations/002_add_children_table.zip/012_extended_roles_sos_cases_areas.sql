-- Migration: Add Extended Roles, SOS Cases, and Area-Based Access Control
-- Created: 2026-03-08
-- Description: Adds new roles for authorities and community leaders, plus SOS case management

-- ============================================
-- GEOGRAPHIC AREAS TABLE (Villages/Wards)
-- ============================================
CREATE TABLE IF NOT EXISTS geographic_areas (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
    parent_area_id VARCHAR(36) DEFAULT NULL,
    code VARCHAR(50) UNIQUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    population INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL
);

CREATE INDEX idx_areas_parent ON geographic_areas(parent_area_id);
CREATE INDEX idx_areas_type ON geographic_areas(type);
CREATE INDEX idx_areas_code ON geographic_areas(code);

-- ============================================
-- USER AREA ASSIGNMENTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_area_assignments (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    area_id VARCHAR(36) NOT NULL,
    role_in_area ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
    is_primary BOOLEAN DEFAULT FALSE,
    assigned_by VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_area (user_id, area_id, is_primary)
);

CREATE INDEX idx_user_area_user ON user_area_assignments(user_id);
CREATE INDEX idx_user_area_area ON user_area_assignments(area_id);
CREATE INDEX idx_user_area_active ON user_area_assignments(is_active);

-- ============================================
-- SOS CASES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS sos_cases (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    
    -- Victim Information
    victim_user_id VARCHAR(36),
    victim_name VARCHAR(100),
    victim_phone VARCHAR(20),
    victim_area_id VARCHAR(36),
    
    -- Case Details
    status ENUM('pending', 'acknowledged', 'investigating', 'resolved', 'closed', 'escalated') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    category VARCHAR(100),
    description TEXT,
    
    -- Location
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address TEXT,
    area_id VARCHAR(36),
    
    -- Assignment
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by VARCHAR(36),
    
    -- Resolution
    resolution_notes TEXT,
    resolved_at TIMESTAMP NULL,
    resolved_by VARCHAR(36),
    
    -- Timeline
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (victim_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_sos_cases_status ON sos_cases(status);
CREATE INDEX idx_sos_cases_priority ON sos_cases(priority);
CREATE INDEX idx_sos_cases_area ON sos_cases(area_id);
CREATE INDEX idx_sos_cases_assigned ON sos_cases(assigned_to);
CREATE INDEX idx_sos_cases_victim ON sos_cases(victim_user_id);
CREATE INDEX idx_sos_cases_number ON sos_cases(case_number);

-- ============================================
-- SOS CASE ACTIVITY LOG
-- ============================================
CREATE TABLE IF NOT EXISTS sos_case_activity (
    id VARCHAR(36) PRIMARY KEY,
    case_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES sos_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_case_activity_case ON sos_case_activity(case_id);
CREATE INDEX idx_case_activity_user ON sos_case_activity(user_id);

-- ============================================
-- ROLE ASSIGNMENTS LOG (Audit Trail)
-- ============================================
CREATE TABLE IF NOT EXISTS role_assignment_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    previous_role VARCHAR(50),
    new_role VARCHAR(50) NOT NULL,
    assigned_by VARCHAR(36),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_role_history_user ON role_assignment_history(user_id);
CREATE INDEX idx_role_history_date ON role_assignment_history(created_at);

-- ============================================
-- INSERT NEW ROLE PERMISSIONS
-- ============================================

-- System Admin - Can manage all admins and system settings
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', '
{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true } }
', '
{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Agency Admin - Can manage agency-specific users and cases
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'agency_admin', '
{ "sos.emergency": true, "sos.manage_agency": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": false, "areas.manage": true, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": true, "delete": false, "assign_roles": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": false }, "automation": { "read": true, "write": false }, "areas": { "read": true, "write": true }, "roles": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["SystemSettings", "RoleManagement"], "readOnlyFields": ["user.role", "system_settings"], "disabledFeatures": [] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Local Police - Can view and manage SOS in their jurisdiction
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'local_police', '
{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "sos.investigate": true, "sos.resolve": true, "ai.chat": false, "ai.vision": true, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true, "investigate": true, "resolve": true, "assign": false }, "ai": { "read": false, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "WomenSafety", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_features", "family_tracking"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Village Head / Ward Admin - Community leader oversight
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'village_head', '
{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "ai.chat": true, "ai.vision": false, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_vision", "advanced_settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- Supervisor - Can manage field workers/volunteers
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'supervisor', '
{ "sos.emergency": true, "sos.view_area": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": true }
', '
{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "assign": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true } }
', '
{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["role_management", "system_settings"] }
')
ON DUPLICATE KEY UPDATE 
    flags = VALUES(flags),
    base_permissions = VALUES(base_permissions),
    ui_restrictions = VALUES(ui_restrictions);

-- ============================================
-- ADD AREA COLUMN TO USERS TABLE (if not exists)
-- ============================================
-- Note: This is a one-time migration, will be skipped if column exists
-- ALTER TABLE users ADD COLUMN area_id VARCHAR(36) DEFAULT NULL;
-- ALTER TABLE users ADD FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL;

-- ============================================
-- ADD ROLE COLUMN TO USERS TABLE FOR SYSTEM ADMIN FLAG (if not exists)
-- ============================================
-- Note: Admin level hierarchy
-- admin - standard admin
-- system_admin - super admin (can manage other admins)

-- ============================================
-- INSERT SAMPLE GEOGRAPHIC AREAS (India - Sample)
-- ============================================
INSERT INTO geographic_areas (id, name, type, code, is_active) VALUES
(UUID(), 'Maharashtra', 'state', 'MH', TRUE),
(UUID(), 'Uttar Pradesh', 'state', 'UP', TRUE),
(UUID(), 'Karnataka', 'state', 'KA', TRUE)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ============================================
-- GRANT PERMISSIONS TO ADMIN ROLE (Extend existing)
-- ============================================
UPDATE role_permissions 
SET flags = JSON_SET(flags, '$.users.manage', TRUE, '$.areas.manage', TRUE, '$.sos.case_management', TRUE)
WHERE role = 'admin';

-- Migration complete
SELECT 'Migration 012: Extended roles, SOS cases, and area-based access created successfully' as message;
