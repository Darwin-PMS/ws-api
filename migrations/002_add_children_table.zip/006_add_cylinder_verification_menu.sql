-- ==============================================================================
-- CYLINDER VERIFICATION MODULE MENU ENTRIES
-- Created: 2026-03-06
-- Description: SQL script to add Cylinder Verification module to menus table
-- ==============================================================================

-- Add Cylinder Verification to Core Services (Home Screen)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions, category)
VALUES (
    'svc-cylinder-verification',
    'Cylinder Verification',
    'secondary',
    TRUE,
    '[]',
    'menu-core-services',
    5,
    'CylinderVerification',
    'flame',
    'Cylinder Verification',
    'Verify gas cylinder validity & expiration',
    '#EF4444',
    'home',
    'mobile',
    TRUE,
    '["safety.inspection"]',
    '["cylinder:read"]',
    'safety'
);

-- Add Cylinder Verification to More Menu (under More >)
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_flags, required_permissions)
VALUES (
    'menu-more-cylinder-verification',
    'Cylinder Verification',
    'secondary',
    TRUE,
    '[]',
    'menu-more',
    11,
    'CylinderVerification',
    'flame',
    'Cylinder Verification',
    '#EF4444',
    'more',
    'mobile',
    TRUE,
    '["safety.inspection"]',
    '["cylinder:read"]'
);

-- Verify the entries were added
SELECT id, name, route, icon, label, category, purpose, menu_for 
FROM menus 
WHERE id IN ('svc-cylinder-verification', 'menu-more-cylinder-verification');
