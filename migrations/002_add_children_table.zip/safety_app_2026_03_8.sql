-- ==============================================================================
-- WOMEN SAFETY APP - COMPLETE DATABASE DUMP
-- Created: 2026-03-08
-- Database: safety_app
-- 
-- IMPORTANT: Password for ALL users is: Password@123
-- Bcrypt Hash: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ==============================================================================

-- ==============================================================================
-- DATABASE CREATION
-- ==============================================================================
CREATE DATABASE IF NOT EXISTS safety_app;
USE safety_app;

-- ==============================================================================
-- USERS TABLE (Updated with all 10 roles)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('system_admin', 'agency_admin', 'admin', 'supervisor', 'local_police', 'village_head', 'guardian', 'parent', 'woman', 'friend') DEFAULT 'woman',
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    verification_code VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- EMERGENCY CONTACTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    relationship VARCHAR(50),
    is_primary BOOLEAN DEFAULT FALSE,
    notes TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    contact_type ENUM('personal', 'family', 'friend', 'work', 'emergency') DEFAULT 'personal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- DEFAULT EMERGENCY CONTACTS (System-wide)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS default_emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description VARCHAR(255),
    country VARCHAR(50) DEFAULT 'India',
    service_type VARCHAR(50) DEFAULT 'emergency',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- USER EMERGENCY PREFERENCES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_emergency_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    enable_sos BOOLEAN DEFAULT TRUE,
    auto_share_location BOOLEAN DEFAULT FALSE,
    notify_emergency_contacts BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    emergency_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preferences (user_id)
);

-- ==============================================================================
-- GUARDIANS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS guardians (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    guardian_id VARCHAR(36) NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SOS ALERTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    status ENUM('active', 'resolved', 'cancelled') DEFAULT 'active',
    message TEXT,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- LOCATION HISTORY TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS location_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(6,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CHILDREN TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS children (
    id VARCHAR(36) PRIMARY KEY,
    parent_id VARCHAR(36) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100),
    date_of_birth DATE NOT NULL,
    gender ENUM('male', 'female', 'other'),
    blood_group VARCHAR(10),
    allergies JSON,
    medications JSON,
    emergency_contact VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_parent_id (parent_id)
);

-- ==============================================================================
-- CHILD ACTIVITIES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS child_activities (
    id VARCHAR(36) PRIMARY KEY,
    child_id VARCHAR(36) NOT NULL,
    activity_type ENUM('feeding', 'sleep', 'medicine', 'diaper', 'other') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
);

-- ==============================================================================
-- NOTIFICATIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT,
    type ENUM('sos', 'safety', 'system', 'child') DEFAULT 'system',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- GEOFENCES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geofences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius INT DEFAULT 100,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- USER SETTINGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    notification_enabled BOOLEAN DEFAULT TRUE,
    location_sharing BOOLEAN DEFAULT TRUE,
    auto_sos BOOLEAN DEFAULT FALSE,
    shake_to_sos BOOLEAN DEFAULT FALSE,
    sos_timer INT DEFAULT 30,
    shake_sensitivity INT DEFAULT 3,
    volume_press_enabled BOOLEAN DEFAULT FALSE,
    power_press_enabled BOOLEAN DEFAULT FALSE,
    voice_enabled BOOLEAN DEFAULT FALSE,
    auto_sos_enabled BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- APP SETTINGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS app_settings (
    id VARCHAR(36) PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- REFRESH TOKENS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- HOME AUTOMATION DEVICES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS home_devices (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    device_type ENUM('light', 'fan', 'ac', 'door', 'camera', 'thermostat', 'plug', 'sensor') NOT NULL,
    room VARCHAR(100) DEFAULT 'Living Room',
    status ENUM('on', 'off') DEFAULT 'off',
    brightness INT DEFAULT 100,
    speed INT DEFAULT 0,
    temperature INT DEFAULT 24,
    is_locked BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILIES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS families (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY MEMBERS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_members (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    role ENUM('head', 'member') DEFAULT 'member',
    nickname VARCHAR(100),
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_family_user (family_id, user_id),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY RELATIONSHIPS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_relationships (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    from_user_id VARCHAR(36) NOT NULL,
    to_user_id VARCHAR(36) NOT NULL,
    relationship_type ENUM('parent', 'child', 'spouse', 'sibling', 'grandparent', 'grandchild', 'other') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_relationship (family_id, from_user_id, to_user_id, relationship_type),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAMILY PLACES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_places (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    place_type ENUM('home', 'school', 'daycare', 'park', 'clinic', 'hospital', 'relative_home', 'work', 'sports', 'other') NOT NULL,
    address TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius_meters INT DEFAULT 100,
    privacy_tag ENUM('do_not_log') DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- CONTEXT SNAPSHOTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS context_snapshots (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    place_id VARCHAR(36),
    place_type VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_type ENUM('arriving', 'leaving', 'dwell', 'transit') DEFAULT 'dwell',
    candidate_context_types JSON,
    confidence DECIMAL(3, 2) DEFAULT 0.50,
    raw_event_ids JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SUGGESTIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS suggestions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    type ENUM('log_activity', 'reminder', 'safety_prompt', 'photo_suggestion') NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    status ENUM('pending', 'shown', 'accepted', 'dismissed', 'snoozed') DEFAULT 'pending',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shown_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL
);

-- ==============================================================================
-- FAMILY ACTIVITY LOGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS family_activity_logs (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    activity_type VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    started_at TIMESTAMP NOT NULL,
    ended_at TIMESTAMP NULL,
    place_id VARCHAR(36),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ==============================================================================
-- CONSENT SETTINGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS consent_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    location_enabled BOOLEAN DEFAULT FALSE,
    activity_enabled BOOLEAN DEFAULT FALSE,
    calendar_enabled BOOLEAN DEFAULT FALSE,
    analytics_enabled BOOLEAN DEFAULT FALSE,
    family_agent_enabled BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME NULL,
    quiet_hours_end TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- AUDIT LOGS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    family_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id VARCHAR(36),
    metadata JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE SET NULL
);

-- ==============================================================================
-- THEMES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS themes (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    config JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- USER THEMES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

-- ==============================================================================
-- MENUS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    parent_id VARCHAR(36) DEFAULT NULL,
    menu_order INT DEFAULT 0,
    bg_color VARCHAR(20) DEFAULT '#8B5CF6',
    text_color VARCHAR(20) DEFAULT '#FFFFFF',
    hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
    hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
    label VARCHAR(100),
    route VARCHAR(100),
    icon VARCHAR(50),
    subtitle VARCHAR(255),
    purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
    menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
    is_visible BOOLEAN DEFAULT TRUE,
    required_flags JSON,
    required_permissions JSON,
    required_roles JSON,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL
);

-- ==============================================================================
-- PERMISSIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

-- ==============================================================================
-- ROLE PERMISSIONS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

-- ==============================================================================
-- GEOGRAPHIC AREAS TABLE (For Authority Roles)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS geographic_areas (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
    parent_area_id VARCHAR(36) DEFAULT NULL,
    code VARCHAR(50) UNIQUE,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    population INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL
);

-- ==============================================================================
-- USER AREA ASSIGNMENTS TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS user_area_assignments (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    area_id VARCHAR(36) NOT NULL,
    role_in_area ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
    is_primary BOOLEAN DEFAULT FALSE,
    assigned_by VARCHAR(36),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    valid_until TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_area (user_id, area_id, is_primary)
);

-- ==============================================================================
-- SOS CASES TABLE
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_cases (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(50) UNIQUE NOT NULL,
    victim_user_id VARCHAR(36),
    victim_name VARCHAR(100),
    victim_phone VARCHAR(20),
    victim_area_id VARCHAR(36),
    status ENUM('pending', 'acknowledged', 'investigating', 'resolved', 'closed', 'escalated') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    category VARCHAR(100),
    description TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_address TEXT,
    area_id VARCHAR(36),
    assigned_to VARCHAR(36),
    assigned_at TIMESTAMP NULL,
    assigned_by VARCHAR(36),
    resolution_notes TEXT,
    resolved_at TIMESTAMP NULL,
    resolved_by VARCHAR(36),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (victim_user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (victim_area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (area_id) REFERENCES geographic_areas(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS CASE ACTIVITY LOG
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_case_activity (
    id VARCHAR(36) PRIMARY KEY,
    case_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (case_id) REFERENCES sos_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- ROLE ASSIGNMENTS LOG (Audit Trail)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS role_assignment_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    previous_role VARCHAR(50),
    new_role VARCHAR(50) NOT NULL,
    assigned_by VARCHAR(36),
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SOS ALERTS LOG (Enhanced)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS sos_alerts_log (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    alert_type ENUM('sos', 'panic', 'distress', 'emergency') DEFAULT 'sos',
    status ENUM('initiated', 'in_progress', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'initiated',
    latitude DOUBLE,
    longitude DOUBLE,
    address VARCHAR(500),
    accuracy DECIMAL(10,2),
    trigger_method ENUM('button', 'shake', 'voice', 'timer', 'auto') DEFAULT 'button',
    message TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL LOGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    caller_name VARCHAR(100) NOT NULL,
    caller_number VARCHAR(20),
    scheduled_duration INT DEFAULT 30,
    actual_duration INT DEFAULT 0,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    call_status ENUM('scheduled', 'ringing', 'answered', 'missed', 'cancelled', 'completed') DEFAULT 'scheduled',
    scheduled_at TIMESTAMP NULL,
    started_at TIMESTAMP NULL,
    ended_at TIMESTAMP NULL,
    is_automated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- FAKE CALL SETTINGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS fake_call_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    default_caller_name VARCHAR(100) DEFAULT 'Mom',
    default_caller_number VARCHAR(20),
    default_duration INT DEFAULT 30,
    ringtone_type VARCHAR(50) DEFAULT 'default',
    vibration_enabled BOOLEAN DEFAULT TRUE,
    answer_automatically BOOLEAN DEFAULT FALSE,
    custom_greeting TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SIREN LOGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS siren_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    siren_type ENUM('panic', 'emergency', 'car', 'custom') DEFAULT 'panic',
    volume_level INT DEFAULT 100,
    duration_seconds INT DEFAULT 0,
    trigger_method ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
    latitude DOUBLE,
    longitude DOUBLE,
    is_active BOOLEAN DEFAULT TRUE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- RECORDING LOGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS recording_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    sos_alert_id VARCHAR(36),
    recording_type ENUM('audio', 'video', 'both') DEFAULT 'audio',
    file_path VARCHAR(500),
    file_size BIGINT,
    duration_seconds INT DEFAULT 0,
    format VARCHAR(20) DEFAULT 'm4a',
    quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    latitude DOUBLE,
    longitude DOUBLE,
    is_automatically_triggered BOOLEAN DEFAULT FALSE,
    transcription TEXT,
    is_uploaded BOOLEAN DEFAULT FALSE,
    is_deleted BOOLEAN DEFAULT FALSE,
    recording_started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recording_ended_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (sos_alert_id) REFERENCES sos_alerts_log(id) ON DELETE SET NULL
);

-- ==============================================================================
-- WOMEN SAFETY PREFERENCES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS women_safety_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    sos_enabled BOOLEAN DEFAULT TRUE,
    sos_button_size ENUM('small', 'medium', 'large') DEFAULT 'large',
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_auto_call_enabled BOOLEAN DEFAULT FALSE,
    sos_location_sharing_enabled BOOLEAN DEFAULT TRUE,
    sos_notify_contacts BOOLEAN DEFAULT TRUE,
    sos_message_template TEXT,
    fake_call_enabled BOOLEAN DEFAULT TRUE,
    siren_enabled BOOLEAN DEFAULT TRUE,
    auto_recording_on_sos BOOLEAN DEFAULT TRUE,
    audio_quality ENUM('low', 'medium', 'high') DEFAULT 'high',
    video_quality ENUM('low', 'medium', 'high') DEFAULT 'medium',
    shake_to_activate BOOLEAN DEFAULT FALSE,
    voice_activation_enabled BOOLEAN DEFAULT FALSE,
    voice_activation_phrase VARCHAR(100),
    timer_based_sos BOOLEAN DEFAULT FALSE,
    timer_duration_minutes INT DEFAULT 60,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- MAP INCIDENTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS map_incidents (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    incident_type ENUM('harassment', 'assault', 'theft', 'suspicious_activity', 'unsafe_area', 'police_presence', 'accident', 'road_block', 'natural_disaster', 'other') NOT NULL,
    severity ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    title VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by VARCHAR(36),
    verification_status ENUM('pending', 'verified', 'rejected', 'expired') DEFAULT 'pending',
    report_count INT DEFAULT 1,
    is_anonymous BOOLEAN DEFAULT FALSE,
    witness_count INT DEFAULT 0,
    photo_url VARCHAR(500),
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    tags JSON,
    expires_at TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (verified_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- SAFE ZONES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safe_zones (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    zone_type ENUM('police_station', 'hospital', 'fire_station', 'public_space', 'cafe', 'shop', 'residential', 'public_transport', 'other') NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 500,
    zone_shape ENUM('circle', 'polygon') DEFAULT 'circle',
    polygon_coords JSON,
    address VARCHAR(500),
    area_name VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    amenity_details JSON,
    safety_rating DECIMAL(3,2) DEFAULT 5.00,
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- ==============================================================================
-- AREA SAFETY RATINGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS area_safety_ratings (
    id VARCHAR(36) PRIMARY KEY,
    area_name VARCHAR(255) NOT NULL,
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100) DEFAULT 'India',
    center_latitude DOUBLE NOT NULL,
    center_longitude DOUBLE NOT NULL,
    radius_meters INT DEFAULT 1000,
    overall_rating DECIMAL(3,2) DEFAULT 3.00,
    incident_count INT DEFAULT 0,
    safe_zone_count INT DEFAULT 0,
    last_calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    rating_breakdown JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INCIDENT VOTES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS incident_votes (
    id VARCHAR(36) PRIMARY KEY,
    incident_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    vote_type ENUM('upvote', 'downvote') DEFAULT 'upvote',
    is_helpful BOOLEAN DEFAULT TRUE,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES map_incidents(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_incident_user_vote (incident_id, user_id)
);

-- ==============================================================================
-- ROUTE HISTORY
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    origin_name VARCHAR(255),
    origin_latitude DOUBLE NOT NULL,
    origin_longitude DOUBLE NOT NULL,
    destination_name VARCHAR(255),
    destination_latitude DOUBLE NOT NULL,
    destination_longitude DOUBLE NOT NULL,
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    route_distance DECIMAL(10,2),
    route_duration INT,
    safety_score DECIMAL(5,2),
    route_path JSON,
    alternative_routes JSON,
    is_favorite BOOLEAN DEFAULT FALSE,
    is_completed BOOLEAN DEFAULT FALSE,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- ROUTE PREFERENCES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS route_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL UNIQUE,
    preferred_travel_mode ENUM('walking', 'driving', 'cycling', 'transit') DEFAULT 'walking',
    avoid_highways BOOLEAN DEFAULT FALSE,
    avoid_tolls BOOLEAN DEFAULT FALSE,
    avoid_ferries BOOLEAN DEFAULT FALSE,
    prefer_lit_streets BOOLEAN DEFAULT TRUE,
    prefer_popular_areas BOOLEAN DEFAULT TRUE,
    minimum_safety_score INT DEFAULT 50,
    maximum_walk_distance INT DEFAULT 2000,
    prefer_alternative_routes BOOLEAN DEFAULT TRUE,
    time_of_day_preference JSON,
    saved_locations JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ==============================================================================
-- SAFETY TIPS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_tips (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    category ENUM('general', 'walking', 'driving', 'public_transport', 'night', 'emergency', 'digital') DEFAULT 'general',
    travel_mode ENUM('walking', 'driving', 'cycling', 'transit', 'all') DEFAULT 'all',
    time_of_day ENUM('morning', 'afternoon', 'evening', 'night', 'all') DEFAULT 'all',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- SAFETY TUTORIALS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_tutorials (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    video_url VARCHAR(500),
    duration INT DEFAULT 0,
    difficulty ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
    is_premium BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- SAFETY NEWS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_news (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    summary TEXT,
    content TEXT,
    category VARCHAR(100),
    image_url VARCHAR(500),
    author VARCHAR(100),
    source VARCHAR(200),
    published_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_featured BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    views_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- SAFETY LAWS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS safety_laws (
    id VARCHAR(36) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    content TEXT,
    category VARCHAR(100),
    jurisdiction VARCHAR(100),
    effective_date DATE,
    penalty TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ==============================================================================
-- INSERT USERS (ALL 10 ROLES)
-- Password: Password@123 (bcrypt hash: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.)
-- ==============================================================================

INSERT INTO users (id, first_name, last_name, email, phone, password, role, is_verified, is_active) VALUES
-- System Admin
('user-system-admin-001', 'Super', 'Admin', 'sysadmin@safetyapp.com', '+919990000001', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'system_admin', TRUE, TRUE),
-- Agency Admin
('user-agency-admin-001', 'Agency', 'Director', 'agency.admin@safetyapp.com', '+919990000002', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'agency_admin', TRUE, TRUE),
-- Admin
('user-admin-001', 'System', 'Administrator', 'admin@safetyapp.com', '+919990000003', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'admin', TRUE, TRUE),
-- Supervisor
('user-supervisor-001', 'Field', 'Supervisor', 'supervisor@safetyapp.com', '+919990000004', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'supervisor', TRUE, TRUE),
-- Local Police
('user-police-001', 'Police', 'Inspector', 'police@safetyapp.com', '+919990000005', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'local_police', TRUE, TRUE),
-- Village Head
('user-village-head-001', 'Village', 'Head', 'villagehead@safetyapp.com', '+919990000006', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'village_head', TRUE, TRUE),
-- Guardian
('user-guardian-001', 'Rajesh', 'Patel', 'rajesh.patel@email.com', '+919990000007', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'guardian', TRUE, TRUE),
('user-guardian-002', 'Priya', 'Sharma', 'priya.sharma@email.com', '+919990000008', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'guardian', TRUE, TRUE),
-- Parent
('user-parent-001', 'Amit', 'Kumar', 'amit.kumar@email.com', '+919990000009', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'parent', TRUE, TRUE),
('user-parent-002', 'Sneha', 'Kumar', 'sneha.kumar@email.com', '+919990000010', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'parent', TRUE, TRUE),
-- Woman
('user-woman-001', 'Anjali', 'Singh', 'anjali.singh@email.com', '+919990000011', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE),
('user-woman-002', 'Pooja', 'Gupta', 'pooja.gupta@email.com', '+919990000012', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE),
('user-woman-003', 'Deepa', 'Iyer', 'deepa.iyer@email.com', '+919990000013', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE),
-- Friend
('user-friend-001', 'Vikram', 'Malhotra', 'vikram.malhotra@email.com', '+919990000014', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'friend', TRUE, TRUE),
('user-friend-002', 'Meera', 'Reddy', 'meera.reddy@email.com', '+919990000015', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'friend', TRUE, TRUE);

-- ==============================================================================
-- INSERT DEFAULT ROLE PERMISSIONS (ALL 10 ROLES)
-- ==============================================================================

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', 
'{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'agency_admin', 
'{ "sos.emergency": true, "sos.manage_agency": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": false, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": false, "assign_roles": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": false }, "automation": { "read": true, "write": false }, "areas": { "read": true, "write": true }, "roles": { "read": true, "write": false } }',
'{ "hiddenScreens": ["SystemSettings", "RoleManagement"], "readOnlyFields": ["user.role", "system_settings"], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'admin', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'supervisor', 
'{ "sos.emergency": true, "sos.view_area": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "assign": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["role_management", "system_settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'local_police', 
'{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "sos.investigate": true, "sos.resolve": true, "ai.chat": false, "ai.vision": true, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true, "investigate": true, "resolve": true, "assign": false }, "ai": { "read": false, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }',
'{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "WomenSafety", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_features", "family_tracking"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'village_head', 
'{ "sos.emergency": true, "sos.view_area": true, "sos.acknowledge": true, "ai.chat": true, "ai.vision": false, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "admin.panel": false, "users.manage": false, "roles.manage": false, "areas.manage": false, "reports.view": true, "reports.export": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_area": true, "acknowledge": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": false } }',
'{ "hiddenScreens": ["AdminPanel", "FamilyManagement", "HomeAutomation"], "readOnlyFields": ["user.role"], "disabledFeatures": ["ai_vision", "advanced_settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'guardian', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": false }, "automation": { "read": true, "write": true } }',
'{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": ["bulk-export"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'parent', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "automation": { "read": false, "write": false } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'woman', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'friend', 
'{ "sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": false, "view_history": false }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- ==============================================================================
-- INSERT MENUS (Home and More Menu)
-- ==============================================================================

-- Primary Menu Container
INSERT IGNORE INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible) VALUES
('menu-primary-main', 'Primary Navigation', 'primary', TRUE, '[]', 0, '#8B5CF6', '#FFFFFF', 'home', 'mobile', TRUE);

-- Primary Menu Items (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible) VALUES
('menu-home', 'Home', 'primary', TRUE, '[]', 'menu-primary-main', 1, 'Home', 'home', 'Home', 'home', 'mobile', TRUE),
('menu-notifications', 'Notifications', 'primary', TRUE, '[]', 'menu-primary-main', 2, 'Notifications', 'notifications', 'Alerts', 'home', 'mobile', TRUE),
('menu-more', 'More', 'primary', TRUE, '[]', 'menu-primary-main', 4, 'More', 'menu', 'More', 'home', 'mobile', TRUE),
('menu-profile', 'Profile', 'primary', TRUE, '[]', 'menu-primary-main', 5, 'Profile', 'person', 'Profile', 'home', 'mobile', TRUE);

-- AI Chat with permissions
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible, required_flags, required_permissions) VALUES
('menu-ai-chat', 'AI Chat', 'primary', TRUE, '[]', 'menu-primary-main', 3, 'AIChat', 'chatbubbles', 'AI Chat', 'home', 'mobile', TRUE, '["ai.chat"]', '["ai:read"]');

-- Core Services Container
INSERT IGNORE INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible) VALUES
('menu-core-services', 'Core Services', 'secondary', TRUE, '[]', 1, '#EC4899', '#FFFFFF', 'home', 'mobile', TRUE);

-- Core Services - Women Safety (Home Screen)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-women-safety', 'Women Safety', 'secondary', TRUE, '[]', 'menu-core-services', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'SOS, emergency contacts & safety tips', '#EC4899', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Child Care (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-child-care', 'Child Care', 'secondary', TRUE, '[]', 'menu-core-services', 2, 'ChildCare', 'happy', 'Child Care', 'Tips, guidance & assistant', '#10B981', 'home', 'mobile', TRUE, 'family');

-- Core Services - Family (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-family', 'Family', 'secondary', TRUE, '[]', 'menu-core-services', 3, 'Family', 'people', 'Family', 'Manage family members & relationships', '#EC4899', 'home', 'mobile', TRUE, 'family');

-- Core Services - Home Automation (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-home-automation', 'Home Automation', 'secondary', TRUE, '[]', 'menu-core-services', 4, 'HomeAutomation', 'home', 'Home Automation', 'Control smart devices & appliances', '#3B82F6', 'home', 'mobile', TRUE, 'lifestyle');

-- Core Services - Vision AI (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-vision', 'Vision', 'secondary', TRUE, '[]', 'menu-core-services', 5, 'Vision', 'camera', 'Vision AI', 'Image analysis with AI', '#8B5CF6', 'home', 'mobile', TRUE, 'ai');

-- Core Services - Speech to Text (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-speech', 'Speech to Text', 'secondary', TRUE, '[]', 'menu-core-services', 6, 'SpeechToText', 'mic', 'Speech to Text', 'Transcribe audio with AI', '#10B981', 'home', 'mobile', TRUE, 'ai');

-- Core Services - Text to Speech (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-tts', 'Text to Speech', 'secondary', TRUE, '[]', 'menu-core-services', 7, 'TextToSpeech', 'volume-high', 'Text to Speech', 'Convert text to speech', '#F59E0B', 'home', 'mobile', TRUE, 'ai');

-- Core Services - Model Browser (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-models', 'Model Browser', 'secondary', TRUE, '[]', 'menu-core-services', 8, 'ModelsList', 'server', 'Model Browser', 'Browse and select AI models', '#8B5CF6', 'home', 'mobile', TRUE, 'ai');

-- Core Services - Safety Map
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-core-services', 9, 'SafetyMap', 'map', 'Safety Map', 'View safe zones & danger areas', '#10B981', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Safe Route
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-core-services', 10, 'SafeRoute', 'navigate', 'Safe Route', 'Find safest path to destination', '#3B82F6', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Cylinder Verification
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-cylinder', 'Cylinder Verification', 'secondary', TRUE, '[]', 'menu-core-services', 11, 'CylinderVerification', 'flame', 'Cylinder Verification', 'Verify gas cylinder safety', '#EF4444', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Safety Tutorials
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-core-services', 12, 'SafetyTutorial', 'book', 'Safety Tutorials', 'Learn safety tips & tricks', '#8B5CF6', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Safety News
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-core-services', 13, 'SafetyNews', 'newspaper', 'Safety News', 'Latest safety news & alerts', '#3B82F6', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Safety Laws
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-core-services', 14, 'SafetyLaw', 'shield', 'Safety Laws', 'Know your legal rights', '#10B981', 'home', 'mobile', TRUE, 'safety');

-- Core Services - Settings
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-settings', 'Settings', 'secondary', TRUE, '[]', 'menu-core-services', 15, 'Settings', 'settings', 'Settings', 'App settings & preferences', '#F59E0B', 'home', 'mobile', TRUE, 'system');

-- Core Services - My Profile
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, category) VALUES
('svc-profile', 'My Profile', 'secondary', TRUE, '[]', 'menu-core-services', 16, 'Profile', 'person', 'My Profile', 'View & edit your profile', '#8B5CF6', 'home', 'mobile', TRUE, 'system');

-- More Menu - Women Safety
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category) VALUES
('menu-more-women-safety', 'Women Safety', 'secondary', TRUE, '[]', 'menu-more', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'SOS, emergency contacts & safety tips', '#EC4899', 'more', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety');

-- More Menu - Child Care (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles, category) VALUES
('menu-more-child-care', 'Child Care', 'secondary', TRUE, '[]', 'menu-more', 2, 'ChildCare', 'happy', 'Child Care', '#10B981', 'more', 'mobile', TRUE, '["parent", "guardian"]', 'family');

-- More Menu - Family (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, required_roles, category) VALUES
('menu-more-family', 'Family', 'secondary', TRUE, '[]', 'menu-more', 3, 'Family', 'people', 'Family', '#EC4899', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', 'family');

-- More Menu - Home Automation (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-home-automation', 'Home Automation', 'secondary', TRUE, '[]', 'menu-more', 4, 'HomeAutomation', 'home', 'Home Automation', '#3B82F6', 'more', 'mobile', TRUE, 'lifestyle');

-- More Menu - Vision AI (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-vision', 'Vision AI', 'secondary', TRUE, '[]', 'menu-more', 5, 'Vision', 'camera', 'Vision AI', '#8B5CF6', 'more', 'mobile', TRUE, 'ai');

-- More Menu - Speech to Text (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-speech', 'Speech to Text', 'secondary', TRUE, '[]', 'menu-more', 6, 'SpeechToText', 'mic', 'Speech to Text', '#10B981', 'more', 'mobile', TRUE, 'ai');

-- More Menu - Text to Speech (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-tts', 'Text to Speech', 'secondary', TRUE, '[]', 'menu-more', 7, 'TextToSpeech', 'volume-high', 'Text to Speech', '#F59E0B', 'more', 'mobile', TRUE, 'ai');

-- More Menu - Model Browser (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-models', 'Model Browser', 'secondary', TRUE, '[]', 'menu-more', 8, 'ModelsList', 'server', 'Model Browser', '#8B5CF6', 'more', 'mobile', TRUE, 'ai');

-- More Menu - Women Safety (without extra permissions - simpler version)
-- REMOVED: Duplicate of menu-more-women-safety

-- More Menu - Settings (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-settings', 'Settings', 'secondary', TRUE, '[]', 'menu-more', 9, 'Settings', 'settings', 'Settings', '#F59E0B', 'more', 'mobile', TRUE, 'system');

-- More Menu - My Profile (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-more-profile', 'My Profile', 'secondary', TRUE, '[]', 'menu-more', 10, 'Profile', 'person', 'My Profile', '#8B5CF6', 'more', 'mobile', TRUE, 'system');

-- More Menu - Safety Map (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-more', 12, 'SafetyMap', 'map', 'Safety Map', '#10B981', 'more', 'mobile', TRUE, 'safety');

-- More Menu - Safe Route (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-more', 13, 'SafeRoute', 'navigate', 'Safe Route', '#3B82F6', 'more', 'mobile', TRUE, 'safety');

-- More Menu - Cylinder Verification (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-cylinder-verification', 'Cylinder Verification', 'secondary', TRUE, '[]', 'menu-more', 14, 'CylinderVerification', 'flame', 'Cylinder Verification', '#EF4444', 'more', 'mobile', TRUE, 'safety');

-- More Menu - Safety Tutorials (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-safety-tutorials', 'Safety Tutorials', 'secondary', TRUE, '[]', 'menu-more', 15, 'SafetyTutorial', 'book', 'Safety Tutorials', '#8B5CF6', 'more', 'mobile', TRUE, 'safety');

-- More Menu - Safety News (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-safety-news', 'Safety News', 'secondary', TRUE, '[]', 'menu-more', 16, 'SafetyNews', 'newspaper', 'Safety News', '#3B82F6', 'more', 'mobile', TRUE, 'safety');

-- More Menu - Safety Laws (without extra permissions)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, bg_color, purpose, menu_for, is_visible, category) VALUES
('menu-safety-laws', 'Safety Laws', 'secondary', TRUE, '[]', 'menu-more', 17, 'SafetyLaw', 'shield', 'Safety Laws', '#10B981', 'more', 'mobile', TRUE, 'safety');

-- INSERT USER PERMISSIONS (Copy from role defaults)
-- ==============================================================================
INSERT INTO permissions (id, user_id, flags, permissions, ui_restrictions)
SELECT UUID(), id, 
    (SELECT flags FROM role_permissions WHERE role = users.role),
    (SELECT base_permissions FROM role_permissions WHERE role = users.role),
    (SELECT ui_restrictions FROM role_permissions WHERE role = users.role)
FROM users;

-- ==============================================================================
-- INSERT DEFAULT EMERGENCY CONTACTS
-- ==============================================================================
INSERT INTO default_emergency_contacts (id, name, phone, description, country, service_type, is_active, display_order, icon) VALUES
('dec-001', 'Police', '100', 'Police Emergency', 'India', 'police', TRUE, 1, 'shield'),
('dec-002', 'Women Helpline', '1091', 'Women Safety Helpline', 'India', 'emergency', TRUE, 2, 'woman'),
('dec-003', 'Ambulance', '102', 'Medical Emergency', 'India', 'medical', TRUE, 3, 'medkit'),
('dec-004', 'Fire', '101', 'Fire Emergency', 'India', 'fire', TRUE, 4, 'flame'),
('dec-005', 'Child Helpline', '1098', 'Child Emergency', 'India', 'child', TRUE, 5, 'people'),
('dec-006', 'NCRB', '155260', 'National Crime Reporting', 'India', 'emergency', TRUE, 6, 'shield-checkmark');

-- ==============================================================================
-- INSERT USER EMERGENCY PREFERENCES
-- ==============================================================================
INSERT INTO user_emergency_preferences (id, user_id, enable_sos, auto_share_location, notify_emergency_contacts, sos_sound_enabled, sos_vibration_enabled, emergency_message)
SELECT UUID(), id, TRUE, FALSE, TRUE, TRUE, TRUE, 'I need help immediately!'
FROM users;

-- ==============================================================================
-- INSERT USER SETTINGS
-- ==============================================================================
INSERT INTO user_settings (id, user_id, notification_enabled, location_sharing, auto_sos, shake_to_sos, sos_timer, shake_sensitivity, volume_press_enabled, power_press_enabled, voice_enabled, auto_sos_enabled)
SELECT UUID(), id, TRUE, TRUE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE
FROM users;

-- ==============================================================================
-- INSERT THEMES
-- ==============================================================================
INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-dark-default', 'Dark Default', 'Default dark theme with purple accents', TRUE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "background": "#0F0F14",
        "backgroundLight": "#1A1A24",
        "surface": "#1E1E2C",
        "text": "#FFFFFF",
        "textSecondary": "#A1A1AA",
        "success": "#10B981",
        "warning": "#F59E0B",
        "error": "#EF4444",
        "danger": "#EF4444",
        "info": "#3B82F6"
    }
}
'),
('theme-light-default', 'Light Default', 'Default light theme', FALSE, TRUE, '
{
    "colors": {
        "primary": "#8B5CF6",
        "primaryLight": "#A78BFA",
        "primaryDark": "#7C3AED",
        "secondary": "#EC4899",
        "background": "#F8FAFC",
        "backgroundLight": "#F1F5F9",
        "surface": "#FFFFFF",
        "text": "#1E293B",
        "textSecondary": "#64748B",
        "success": "#059669",
        "warning": "#D97706",
        "error": "#DC2626",
        "danger": "#DC2626",
        "info": "#2563EB"
    }
}
');

-- ==============================================================================
-- INSERT USER THEMES
-- ==============================================================================
INSERT INTO user_themes (id, user_id, theme_id, is_active)
SELECT UUID(), id, 'theme-dark-default', TRUE FROM users;

-- ==============================================================================
-- INSERT APP SETTINGS
-- ==============================================================================
INSERT INTO app_settings (id, setting_key, setting_value, description, is_encrypted) VALUES
(UUID(), 'groq_key', '', 'Groq API key for AI chat functionality', TRUE),
(UUID(), 'app_name', 'Women Safety App', 'Application name', FALSE),
(UUID(), 'app_version', '1.0.0', 'Application version', FALSE),
(UUID(), 'max_sos_contacts', '5', 'Maximum emergency contacts per user', FALSE);

-- ==============================================================================
-- INSERT GEOGRAPHIC AREAS (Sample India Areas)
-- ==============================================================================
INSERT INTO geographic_areas (id, name, type, code, latitude, longitude, is_active) VALUES
('geo-state-mh', 'Maharashtra', 'state', 'MH', 19.7515, 75.7139, TRUE),
('geo-state-up', 'Uttar Pradesh', 'state', 'UP', 26.8467, 80.9462, TRUE),
('geo-stateka', 'Karnataka', 'state', 'KA', 15.3173, 75.7139, TRUE),
('geo-state-dl', 'Delhi', 'state', 'DL', 28.7041, 77.1025, TRUE),
('geo-state-tn', 'Tamil Nadu', 'state', 'TN', 11.1271, 78.6569, TRUE),
('geo-district-mumbai', 'Mumbai', 'district', 'MH-MUM', 19.0760, 72.8777, TRUE),
('geo-district-delhi', 'Delhi', 'district', 'DL-DEL', 28.6139, 77.2090, TRUE),
('geo-district-bangalore', 'Bangalore', 'district', 'KA-BLR', 12.9716, 77.5946, TRUE),
('geo-district-chennai', 'Chennai', 'district', 'TN-MAA', 13.0827, 80.2707, TRUE),
('geo-village-pune', 'Pune City', 'village', 'MH-PUNE', 18.5204, 73.8567, TRUE);

-- ==============================================================================
-- INSERT USER AREA ASSIGNMENTS (For authority roles)
-- ==============================================================================
INSERT INTO user_area_assignments (id, user_id, area_id, role_in_area, is_primary, assigned_by) VALUES
(UUID(), 'user-police-001', 'geo-district-mumbai', 'police', TRUE, 'user-system-admin-001'),
(UUID(), 'user-village-head-001', 'geo-village-pune', 'village_head', TRUE, 'user-system-admin-001'),
(UUID(), 'user-supervisor-001', 'geo-state-mh', 'supervisor', TRUE, 'user-system-admin-001');

-- ==============================================================================
-- INSERT FAMILIES
-- ==============================================================================
INSERT INTO families (id, name, description, created_by) VALUES
('family-001', 'Patel Family', 'Rajesh Patel family', 'user-guardian-001'),
('family-002', 'Sharma Family', 'Priya Sharma family', 'user-guardian-002'),
('family-003', 'Kumar Family', 'Amit and Sneha Kumar family', 'user-parent-001'),
('family-004', 'Singh Family', 'Anjali Singh family', 'user-woman-001');

-- ==============================================================================
-- INSERT FAMILY MEMBERS
-- ==============================================================================
INSERT INTO family_members (id, family_id, user_id, role, nickname) VALUES
('fm-001', 'family-001', 'user-guardian-001', 'head', 'Dad'),
('fm-002', 'family-001', 'user-woman-001', 'member', 'Daughter'),
('fm-003', 'family-002', 'user-guardian-002', 'head', 'Mom'),
('fm-004', 'family-002', 'user-woman-003', 'member', 'Daughter'),
('fm-005', 'family-003', 'user-parent-001', 'head', 'Father'),
('fm-006', 'family-003', 'user-parent-002', 'head', 'Mother'),
('fm-007', 'family-003', 'user-guardian-001', 'member', 'Grandfather'),
('fm-008', 'family-004', 'user-woman-001', 'head', 'Self'),
('fm-009', 'family-004', 'user-friend-001', 'member', 'Friend');

-- ==============================================================================
-- INSERT FAMILY PLACES
-- ==============================================================================
INSERT INTO family_places (id, family_id, name, place_type, address, latitude, longitude, radius_meters, is_active, created_by) VALUES
('fp-001', 'family-001', 'Patel Home', 'home', '123 Main Road, Mumbai', 19.0760, 72.8777, 100, TRUE, 'user-guardian-001'),
('fp-002', 'family-001', 'St. Mary School', 'school', '456 Education Lane, Mumbai', 19.0780, 72.8800, 200, TRUE, 'user-guardian-001'),
('fp-003', 'family-002', 'Sharma Residence', 'home', '789 Oak Street, Delhi', 28.6139, 77.2090, 100, TRUE, 'user-guardian-002'),
('fp-004', 'family-003', 'Kumar House', 'home', '321 Pine Avenue, Bangalore', 12.9716, 77.5946, 100, TRUE, 'user-parent-001'),
('fp-005', 'family-004', 'Singh Apartment', 'home', '777 Lake View, Chennai', 13.0827, 80.2707, 100, TRUE, 'user-woman-001');

-- ==============================================================================
-- INSERT EMERGENCY CONTACTS
-- ==============================================================================
INSERT INTO emergency_contacts (id, user_id, name, phone, relationship, is_primary, contact_type) VALUES
('ec-001', 'user-woman-001', 'Rajesh Patel', '+919990000007', 'Father', TRUE, 'family'),
('ec-002', 'user-woman-001', 'Priya Sharma', '+919990000008', 'Mother', FALSE, 'family'),
('ec-003', 'user-woman-001', 'Vikram Malhotra', '+919990000014', 'Friend', FALSE, 'friend'),
('ec-004', 'user-woman-002', 'Amit Kumar', '+919990000009', 'Brother', TRUE, 'family'),
('ec-005', 'user-woman-003', 'Priya Sharma', '+919990000008', 'Mother', TRUE, 'family'),
('ec-006', 'user-guardian-001', 'Anjali Singh', '+919990000011', 'Daughter', TRUE, 'family'),
('ec-007', 'user-guardian-002', 'Deepa Iyer', '+919990000013', 'Daughter', TRUE, 'family'),
('ec-008', 'user-parent-001', 'Sneha Kumar', '+919990000010', 'Spouse', TRUE, 'family'),
('ec-009', 'user-parent-002', 'Amit Kumar', '+919990000009', 'Spouse', TRUE, 'family');

-- ==============================================================================
-- INSERT CHILDREN
-- ==============================================================================
INSERT INTO children (id, parent_id, first_name, last_name, date_of_birth, gender, notes) VALUES
('child-001', 'user-parent-001', 'Arjun', 'Kumar', '2018-05-15', 'male', 'First child'),
('child-002', 'user-parent-001', 'Myra', 'Kumar', '2020-08-22', 'female', 'Second child'),
('child-003', 'user-guardian-001', 'Aisha', 'Patel', '2019-03-10', 'female', 'Granddaughter'),
('child-004', 'user-guardian-002', 'Karthik', 'Sharma', '2021-01-05', 'male', 'Grandson');

-- ==============================================================================
-- INSERT HOME DEVICES
-- ==============================================================================
INSERT INTO home_devices (id, user_id, name, device_type, room, status, brightness, is_locked) VALUES
('hd-001', 'user-guardian-001', 'Living Room Light', 'light', 'Living Room', 'on', 80, TRUE),
('hd-002', 'user-guardian-001', 'Bedroom Fan', 'fan', 'Bedroom', 'on', 3, TRUE),
('hd-003', 'user-guardian-001', 'Main Door', 'door', 'Entrance', 'off', 0, TRUE),
('hd-004', 'user-guardian-002', 'Kitchen Light', 'light', 'Kitchen', 'on', 100, TRUE),
('hd-005', 'user-parent-001', 'Baby Room Monitor', 'camera', 'Baby Room', 'on', 0, TRUE);

-- ==============================================================================
-- INSERT GEOFENCES
-- ==============================================================================
INSERT INTO geofences (id, user_id, name, latitude, longitude, radius, is_active) VALUES
('geo-001', 'user-guardian-001', 'Home', 19.0760, 72.8777, 100, TRUE),
('geo-002', 'user-guardian-001', 'School', 19.0780, 72.8800, 200, TRUE),
('geo-003', 'user-parent-001', 'Home', 12.9716, 77.5946, 100, TRUE),
('geo-004', 'user-woman-001', 'Home', 13.0827, 80.2707, 100, TRUE);

-- ==============================================================================
-- INSERT NOTIFICATIONS
-- ==============================================================================
INSERT INTO notifications (id, user_id, title, message, type, is_read) VALUES
('notif-001', 'user-woman-001', 'Safety Alert', 'Stay safe! Remember to share your location with family.', 'safety', FALSE),
('notif-002', 'user-woman-001', 'AI Assistant', 'Your AI assistant has new safety tips!', 'system', TRUE),
('notif-003', 'user-guardian-001', 'Family Update', 'Anjali has reached home safely.', 'system', FALSE),
('notif-004', 'user-parent-001', 'Child Activity', 'Arjun logged breakfast activity', 'child', TRUE),
('notif-005', 'user-admin-001', 'System', 'Database migration completed successfully', 'system', TRUE);

-- ==============================================================================
-- INSERT LOCATION HISTORY
-- ==============================================================================
INSERT INTO location_history (id, user_id, latitude, longitude, accuracy) VALUES
('lh-001', 'user-woman-001', 13.0827, 80.2707, 10),
('lh-002', 'user-woman-001', 13.0830, 80.2710, 15),
('lh-003', 'user-guardian-001', 19.0760, 72.8777, 5),
('lh-004', 'user-parent-001', 12.9716, 77.5946, 12);

-- ==============================================================================
-- INSERT SAFETY TUTORIALS
-- ==============================================================================
INSERT IGNORE INTO safety_tutorials (id, title, description, content, category, duration, difficulty, is_active) VALUES
('tutorial-001', 'Self-Defense Basics', 'Learn essential self-defense techniques every woman should know', '<h2>Basic Self-Defense Techniques</h2><p>Palm strike, knee defense, escaping wrist grabs, creating distance</p>', 'self-defense', 30, 'beginner', TRUE),
('tutorial-002', 'Digital Safety Guide', 'Protect yourself from online threats and harassment', '<h2>Digital Safety Essentials</h2><p>Secure accounts, recognize phishing, protect information</p>', 'digital-safety', 45, 'beginner', TRUE),
('tutorial-003', 'Travel Safety Tips', 'Stay safe while traveling alone', '<h2>Safe Travel Guidelines</h2><p>Research destination, share itinerary, stay aware</p>', 'travel-safety', 25, 'beginner', TRUE),
('tutorial-004', 'Emergency Alert Systems', 'How to effectively use emergency alert systems', '<h2>Using Emergency Alerts</h2><p>SOS button, location sharing, emergency contacts</p>', 'emergency', 20, 'beginner', TRUE),
('tutorial-005', 'Street Safety 101', 'Essential tips for navigating public spaces safely', '<h2>Street Safety Essentials</h2><p>Walking confidently, avoiding dangerous areas, trusting instincts</p>', 'general', 15, 'beginner', TRUE);

-- ==============================================================================
-- INSERT SAFETY NEWS
-- ==============================================================================
INSERT IGNORE INTO safety_news (id, title, summary, content, category, is_featured, is_active, views_count) VALUES
('news-001', 'New Safety App Launches Nationwide', 'A revolutionary safety application has been launched', '<h2>New Safety App Available</h2><p>Real-time location sharing, emergency alerts, community support</p>', 'technology', TRUE, TRUE, 1520),
('news-002', 'Government Announces Women Safety Initiative', 'Comprehensive program to improve public safety infrastructure', '<h2>Women Safety Initiative 2026</h2><p>Better street lighting, increased police patrols, emergency call boxes</p>', 'government', TRUE, TRUE, 2340),
('news-003', 'Self-Defense Classes See Surge in Enrollment', 'More women signing up for self-defense courses', '<h2>Self-Defense Training Popularity</h2><p>50% increase in enrollment across the country</p>', 'lifestyle', FALSE, TRUE, 890),
('news-004', 'New Emergency Response System Launched', 'Faster emergency response times with new technology', '<h2>Faster Emergency Response</h2><p>New system reduces response time to under 5 minutes</p>', 'technology', TRUE, TRUE, 1100),
('news-005', 'Women Safety Workshops Across Cities', 'Free safety workshops being conducted in major cities', '<h2>Free Safety Workshops</h2><p>Learn self-defense, digital safety, and emergency preparedness</p>', 'events', FALSE, TRUE, 750);

-- ==============================================================================
-- INSERT SAFETY LAWS
-- ==============================================================================
INSERT IGNORE INTO safety_laws (id, title, description, content, category, jurisdiction, penalty, is_active) VALUES
('law-001', 'Violence Against Women Act', 'Comprehensive legislation protecting women from violence', '<h2>VAWA</h2><p>Protection orders, legal representation, support services</p>', 'protection', 'Federal', 'Varies by offense', TRUE),
('law-002', 'Workplace Harassment Prevention Law', 'Employers must maintain harassment-free workplaces', '<h2>Workplace Safety</h2><p>Mandatory training, confidential reporting, prompt investigation</p>', 'workplace', 'National', 'Up to $50,000 fine', TRUE),
('law-003', 'Domestic Violence Protection Order', 'Legal mechanism to protect domestic violence victims', '<h2>DV Protection</h2><p>No-contact orders, stay-away orders, custody provisions</p>', 'domestic', 'State', 'Arrest for violation', TRUE),
('law-004', 'Sexual Harassment Act', 'Prevention and redressal of sexual harassment at workplace', '<h2>Sexual Harassment</h2><p>Internal complaints committee, time-bound resolution</p>', 'workplace', 'National', 'Imprisonment up to 3 years', TRUE),
('law-005', 'Stalking Prevention Law', 'Legal provisions against stalking and cyberstalking', '<h2>Stalking Prevention</h2><p>Protection from stalker, penalties for violation</p>', 'protection', 'National', 'Imprisonment up to 3 years', TRUE);

-- ==============================================================================
-- INSERT SAFETY TIPS
-- ==============================================================================
INSERT IGNORE INTO safety_tips (id, title, content, category, travel_mode, time_of_day, is_active, display_order) VALUES
('tip-001', 'Stay Aware', 'Always be aware of your surroundings and trust your instincts', 'general', 'all', 'all', TRUE, 1),
('tip-002', 'Share Your Location', 'Keep your location shared with trusted contacts while traveling', 'general', 'walking', 'all', TRUE, 2),
('tip-003', 'Emergency Contacts', 'Keep emergency numbers saved and easily accessible', 'emergency', 'all', 'all', TRUE, 3),
('tip-004', 'Night Safety', 'Stay in well-lit areas and avoid shortcuts through dark alleys', 'walking', 'walking', 'night', TRUE, 4),
('tip-005', 'Trust Your Gut', 'If something feels wrong, leave immediately', 'general', 'all', 'all', TRUE, 5),
('tip-006', 'Avoid Isolated Areas', 'Stay in populated areas, especially at night', 'walking', 'walking', 'night', TRUE, 6);

-- ==============================================================================
-- DATABASE DUMP COMPLETE
-- ==============================================================================
SELECT 'Women Safety App Database Dump Complete - 2026-03-08' AS message;
SELECT 'Password for all users: Password@123' AS password_info;
SELECT COUNT(*) AS total_users FROM users;
SELECT role, COUNT(*) as count FROM users GROUP BY role;
