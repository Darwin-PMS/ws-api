-- Migration: Update menus table with additional fields
-- Created: 2026-03-05
-- Adds: bgColor, textColor, hoverBgColor, hoverTextColor, label, route, icon, order, puspose, for, isVisible

-- ============================================
-- ALTER MENUS TABLE - ADD NEW COLUMNS
-- ============================================

-- Add new columns to menus table (only if they don't exist)
ALTER TABLE menus 
ADD COLUMN IF NOT EXISTS bgColor VARCHAR(100) DEFAULT '#8B5CF6',
ADD COLUMN IF NOT EXISTS textColor VARCHAR(100) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS hoverBgColor VARCHAR(100) DEFAULT '#7C3AED',
ADD COLUMN IF NOT EXISTS hoverTextColor VARCHAR(100) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS label VARCHAR(100),
ADD COLUMN IF NOT EXISTS route VARCHAR(100),
ADD COLUMN IF NOT EXISTS icon VARCHAR(100),
ADD COLUMN IF NOT EXISTS menu_order VARCHAR(100) DEFAULT '0',
ADD COLUMN IF NOT EXISTS puspose ENUM('home', 'more', 'profile') DEFAULT 'more',
ADD COLUMN IF NOT EXISTS menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
ADD COLUMN IF NOT EXISTS isVisible BOOLEAN DEFAULT TRUE;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_menus_puspose ON menus(puspose);
CREATE INDEX IF NOT EXISTS idx_menus_for ON menus(menu_for);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_visible ON menus(isVisible);

-- ============================================
-- UPDATE EXISTING MENUS WITH DEFAULT VALUES
-- ============================================

-- Update primary menu with new field values
UPDATE menus 
SET 
    bgColor = COALESCE(bgColor, '#8B5CF6'),
    textColor = COALESCE(textColor, '#FFFFFF'),
    hoverBgColor = COALESCE(hoverBgColor, '#7C3AED'),
    hoverTextColor = COALESCE(hoverTextColor, '#FFFFFF'),
    menu_order = COALESCE(menu_order, '0'),
    puspose = COALESCE(puspose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    isVisible = COALESCE(isVisible, TRUE)
WHERE type = 'primary';

-- Update secondary menu with new field values
UPDATE menus 
SET 
    bgColor = COALESCE(bgColor, '#EC4899'),
    textColor = COALESCE(textColor, '#FFFFFF'),
    hoverBgColor = COALESCE(hoverBgColor, '#DB2777'),
    hoverTextColor = COALESCE(hoverTextColor, '#FFFFFF'),
    menu_order = COALESCE(menu_order, '1'),
    puspose = COALESCE(puspose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    isVisible = COALESCE(isVisible, TRUE)
WHERE type = 'secondary';

-- Migration complete
SELECT 'Migration 003: menus table updated with additional fields successfully' as message;
