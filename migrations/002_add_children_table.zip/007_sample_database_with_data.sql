-- ============================================
-- SAMPLE DATABASE WITH COMPLETE SCHEMA AND DATA
-- Created: 2026-03-07
-- Password for all users: Password@123 (hashed with bcrypt, cost factor 10)
-- Hash: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ============================================

-- ============================================
-- DATABASE CREATION
-- ============================================
CREATE DATABASE IF NOT EXISTS safety_app;
USE safety_app;

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('woman', 'parent', 'guardian', 'friend', 'admin') DEFAULT 'woman',
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    verification_code VARCHAR(10),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- EMERGENCY CONTACTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    relationship VARCHAR(50),
    is_primary BOOLEAN DEFAULT FALSE,
    notes TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    contact_type ENUM('personal', 'family', 'friend', 'work', 'emergency') DEFAULT 'personal',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- DEFAULT EMERGENCY CONTACTS (System-wide)
-- ============================================
CREATE TABLE IF NOT EXISTS default_emergency_contacts (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    description VARCHAR(255),
    country VARCHAR(50) DEFAULT 'India',
    service_type VARCHAR(50) DEFAULT 'emergency',
    is_active BOOLEAN DEFAULT TRUE,
    display_order INT DEFAULT 0,
    icon VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- USER EMERGENCY PREFERENCES
-- ============================================
CREATE TABLE IF NOT EXISTS user_emergency_preferences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    enable_sos BOOLEAN DEFAULT TRUE,
    auto_share_location BOOLEAN DEFAULT FALSE,
    notify_emergency_contacts BOOLEAN DEFAULT TRUE,
    sos_sound_enabled BOOLEAN DEFAULT TRUE,
    sos_vibration_enabled BOOLEAN DEFAULT TRUE,
    emergency_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_preferences (user_id)
);

-- ============================================
-- GUARDIANS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS guardians (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    guardian_id VARCHAR(36) NOT NULL,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- SOS ALERTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS sos_alerts (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    status ENUM('active', 'resolved', 'cancelled') DEFAULT 'active',
    message TEXT,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- LOCATION HISTORY TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS location_history (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(6,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- CHILDREN TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS children (
    id VARCHAR(36) PRIMARY KEY,
    parent_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other'),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- CHILD ACTIVITIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS child_activities (
    id VARCHAR(36) PRIMARY KEY,
    child_id VARCHAR(36) NOT NULL,
    activity_type ENUM('feeding', 'sleep', 'medicine', 'diaper', 'other') NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE
);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT,
    type ENUM('sos', 'safety', 'system', 'child') DEFAULT 'system',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- GEOFENCES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS geofences (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius INT DEFAULT 100,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- USER SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    notification_enabled BOOLEAN DEFAULT TRUE,
    location_sharing BOOLEAN DEFAULT TRUE,
    auto_sos BOOLEAN DEFAULT FALSE,
    shake_to_sos BOOLEAN DEFAULT FALSE,
    sos_timer INT DEFAULT 30,
    shake_sensitivity INT DEFAULT 3,
    volume_press_enabled BOOLEAN DEFAULT FALSE,
    power_press_enabled BOOLEAN DEFAULT FALSE,
    voice_enabled BOOLEAN DEFAULT FALSE,
    auto_sos_enabled BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- APP SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS app_settings (
    id VARCHAR(36) PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- REFRESH TOKENS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS refresh_tokens (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- HOME AUTOMATION DEVICES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS home_devices (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    name VARCHAR(100) NOT NULL,
    device_type ENUM('light', 'fan', 'ac', 'door', 'camera', 'thermostat', 'plug', 'sensor') NOT NULL,
    room VARCHAR(100) DEFAULT 'Living Room',
    status ENUM('on', 'off') DEFAULT 'off',
    brightness INT DEFAULT 100,
    speed INT DEFAULT 0,
    temperature INT DEFAULT 24,
    is_locked BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- FAMILIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS families (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- FAMILY MEMBERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS family_members (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    role ENUM('head', 'member') DEFAULT 'member',
    nickname VARCHAR(100),
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_family_user (family_id, user_id),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- FAMILY RELATIONSHIPS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS family_relationships (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    from_user_id VARCHAR(36) NOT NULL,
    to_user_id VARCHAR(36) NOT NULL,
    relationship_type ENUM('parent', 'child', 'spouse', 'sibling', 'grandparent', 'grandchild', 'other') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_relationship (family_id, from_user_id, to_user_id, relationship_type),
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- FAMILY PLACES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS family_places (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    name VARCHAR(150) NOT NULL,
    place_type ENUM('home', 'school', 'daycare', 'park', 'clinic', 'hospital', 'relative_home', 'work', 'sports', 'other') NOT NULL,
    address TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius_meters INT DEFAULT 100,
    privacy_tag ENUM('do_not_log') DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_by VARCHAR(36) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- CONTEXT SNAPSHOTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS context_snapshots (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    place_id VARCHAR(36),
    place_type VARCHAR(50),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_type ENUM('arriving', 'leaving', 'dwell', 'transit') DEFAULT 'dwell',
    candidate_context_types JSON,
    confidence DECIMAL(3, 2) DEFAULT 0.50,
    raw_event_ids JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ============================================
-- SUGGESTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS suggestions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    family_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    type ENUM('log_activity', 'reminder', 'safety_prompt', 'photo_suggestion') NOT NULL,
    title VARCHAR(200) NOT NULL,
    body TEXT,
    status ENUM('pending', 'shown', 'accepted', 'dismissed', 'snoozed') DEFAULT 'pending',
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shown_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL
);

-- ============================================
-- FAMILY ACTIVITY LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS family_activity_logs (
    id VARCHAR(36) PRIMARY KEY,
    family_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    context_id VARCHAR(36),
    activity_type VARCHAR(100) NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    started_at TIMESTAMP NOT NULL,
    ended_at TIMESTAMP NULL,
    place_id VARCHAR(36),
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (context_id) REFERENCES context_snapshots(id) ON DELETE SET NULL,
    FOREIGN KEY (place_id) REFERENCES family_places(id) ON DELETE SET NULL
);

-- ============================================
-- CONSENT SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS consent_settings (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) UNIQUE NOT NULL,
    location_enabled BOOLEAN DEFAULT FALSE,
    activity_enabled BOOLEAN DEFAULT FALSE,
    calendar_enabled BOOLEAN DEFAULT FALSE,
    analytics_enabled BOOLEAN DEFAULT FALSE,
    family_agent_enabled BOOLEAN DEFAULT TRUE,
    quiet_hours_start TIME NULL,
    quiet_hours_end TIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- AUDIT LOGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36),
    family_id VARCHAR(36),
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id VARCHAR(36),
    metadata JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE SET NULL
);

-- ============================================
-- THEMES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS themes (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    config JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- USER THEMES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS user_themes (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    theme_id VARCHAR(36) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (theme_id) REFERENCES themes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_active_theme (user_id, is_active)
);

-- ============================================
-- MENUS TABLE - Each menu item as separate row
-- ============================================
CREATE TABLE IF NOT EXISTS menus (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    items JSON NOT NULL,
    parent_id VARCHAR(36) DEFAULT NULL,
    menu_order INT DEFAULT 0,
    bg_color VARCHAR(20) DEFAULT '#8B5CF6',
    text_color VARCHAR(20) DEFAULT '#FFFFFF',
    hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
    hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
    label VARCHAR(100),
    route VARCHAR(100),
    icon VARCHAR(50),
    subtitle VARCHAR(255),
    purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
    menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
    is_visible BOOLEAN DEFAULT TRUE,
    required_flags JSON,
    required_permissions JSON,
    required_roles JSON,
    category VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL
);

-- ============================================
-- PERMISSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS permissions (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    flags JSON,
    permissions JSON,
    ui_restrictions JSON,
    expires_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_permission (user_id)
);

-- ============================================
-- ROLE PERMISSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS role_permissions (
    id VARCHAR(36) PRIMARY KEY,
    role VARCHAR(50) NOT NULL,
    flags JSON,
    base_permissions JSON,
    ui_restrictions JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_role (role)
);

-- ============================================
-- INSERT USERS
-- Password: Password@123 (hashed with bcrypt, cost=10)
-- Hash: $2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.
-- ============================================
INSERT INTO users (id, first_name, last_name, email, phone, password, role, is_verified, is_active, verification_code, created_at, updated_at) VALUES
('user-admin-001', 'System', 'Administrator', 'admin@safetyapp.com', '+919999999999', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'admin', TRUE, TRUE, NULL, NOW(), NOW()),
('user-guardian-001', 'Rajesh', 'Patel', 'rajesh.patel@email.com', '+919888888888', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'guardian', TRUE, TRUE, NULL, NOW(), NOW()),
('user-guardian-002', 'Priya', 'Sharma', 'priya.sharma@email.com', '+919777777777', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'guardian', TRUE, TRUE, NULL, NOW(), NOW()),
('user-parent-001', 'Amit', 'Kumar', 'amit.kumar@email.com', '+919666666666', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'parent', TRUE, TRUE, NULL, NOW(), NOW()),
('user-parent-002', 'Sneha', 'Kumar', 'sneha.kumar@email.com', '+919555555555', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'parent', TRUE, TRUE, NULL, NOW(), NOW()),
('user-woman-001', 'Anjali', 'Singh', 'anjali.singh@email.com', '+919444444444', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE, NULL, NOW(), NOW()),
('user-woman-002', 'Pooja', 'Gupta', 'pooja.gupta@email.com', '+919333333333', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE, NULL, NOW(), NOW()),
('user-friend-001', 'Vikram', 'Malhotra', 'vikram.malhotra@email.com', '+919222222222', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'friend', TRUE, TRUE, NULL, NOW(), NOW()),
('user-friend-002', 'Meera', 'Reddy', 'meera.reddy@email.com', '+919111111111', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'friend', TRUE, TRUE, NULL, NOW(), NOW()),
('user-woman-003', 'Deepa', 'Iyer', 'deepa.iyer@email.com', '+919000000000', '$2a$10$g49D3kHJp1Wl5ig7mCFjZOGEVIHiIA5AI.CKki4tHwmgJKHC.5Ln.', 'woman', TRUE, TRUE, NULL, NOW(), NOW());

-- ============================================
-- INSERT DEFAULT EMERGENCY CONTACTS
-- ============================================
INSERT INTO default_emergency_contacts (id, name, phone, description, country, service_type, is_active, display_order, icon, created_at, updated_at) VALUES
('dec-001', 'Police', '100', 'Police Emergency', 'India', 'police', TRUE, 1, 'shield', NOW(), NOW()),
('dec-002', 'Women Helpline', '1091', 'Women Safety Helpline', 'India', 'emergency', TRUE, 2, 'women', NOW(), NOW()),
('dec-003', 'Ambulance', '102', 'Medical Emergency', 'India', 'medical', TRUE, 3, 'medkit', NOW(), NOW()),
('dec-004', 'Fire', '101', 'Fire Emergency', 'India', 'fire', TRUE, 4, 'flame', NOW(), NOW()),
('dec-005', 'Child Helpline', '1098', 'Child Emergency', 'India', 'child', TRUE, 5, 'people', NOW(), NOW());

-- ============================================
-- INSERT USER EMERGENCY PREFERENCES
-- ============================================
INSERT INTO user_emergency_preferences (id, user_id, enable_sos, auto_share_location, notify_emergency_contacts, sos_sound_enabled, sos_vibration_enabled, emergency_message) VALUES
('uep-001', 'user-admin-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'I need help immediately!'),
('uep-002', 'user-guardian-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency! Please help!'),
('uep-003', 'user-guardian-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Need immediate assistance'),
('uep-004', 'user-parent-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency SOS triggered'),
('uep-005', 'user-parent-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Please help me!'),
('uep-006', 'user-woman-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'I am in danger, please help!'),
('uep-007', 'user-woman-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency! Need help!'),
('uep-008', 'user-friend-001', TRUE, FALSE, TRUE, TRUE, TRUE, 'Need assistance'),
('uep-009', 'user-friend-002', TRUE, FALSE, TRUE, TRUE, TRUE, 'Please contact me'),
('uep-010', 'user-woman-003', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency!');

-- ============================================
-- INSERT USER SETTINGS
-- ============================================
INSERT INTO user_settings (id, user_id, notification_enabled, location_sharing, auto_sos, shake_to_sos, sos_timer, shake_sensitivity, volume_press_enabled, power_press_enabled, voice_enabled, auto_sos_enabled) VALUES
('us-001', 'user-admin-001', TRUE, TRUE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-002', 'user-guardian-001', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-003', 'user-guardian-002', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-004', 'user-parent-001', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-005', 'user-parent-002', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-006', 'user-woman-001', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE),
('us-007', 'user-woman-002', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE),
('us-008', 'user-friend-001', TRUE, FALSE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-009', 'user-friend-002', TRUE, FALSE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
('us-010', 'user-woman-003', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE);

-- ============================================
-- INSERT APP SETTINGS
-- ============================================
INSERT INTO app_settings (id, setting_key, setting_value, description, is_encrypted, created_at, updated_at) VALUES
('as-001', 'groq_key', '', 'Groq API key for AI chat functionality', TRUE, NOW(), NOW()),
('as-002', 'app_name', 'Women Safety App', 'Application name', FALSE, NOW(), NOW()),
('as-003', 'app_version', '1.0.0', 'Application version', FALSE, NOW(), NOW()),
('as-004', 'max_sos_contacts', '5', 'Maximum emergency contacts per user', FALSE, NOW(), NOW());

-- ============================================
-- INSERT FAMILIES
-- ============================================
INSERT INTO families (id, name, description, created_by, created_at, updated_at) VALUES
('family-001', 'Patel Family', 'Rajesh Patel family', 'user-guardian-001', NOW(), NOW()),
('family-002', 'Sharma Family', 'Priya Sharma family', 'user-guardian-002', NOW(), NOW()),
('family-003', 'Kumar Family', 'Amit and Sneha Kumar family', 'user-parent-001', NOW(), NOW()),
('family-004', 'Singh Family', 'Anjali Singh family', 'user-woman-001', NOW(), NOW());

-- ============================================
-- INSERT FAMILY MEMBERS
-- ============================================
INSERT INTO family_members (id, family_id, user_id, role, nickname, joined_at) VALUES
('fm-001', 'family-001', 'user-guardian-001', 'head', 'Dad', NOW()),
('fm-002', 'family-001', 'user-woman-001', 'member', 'Daughter', NOW()),
('fm-003', 'family-002', 'user-guardian-002', 'head', 'Mom', NOW()),
('fm-004', 'family-002', 'user-woman-003', 'member', 'Daughter', NOW()),
('fm-005', 'family-003', 'user-parent-001', 'head', 'Father', NOW()),
('fm-006', 'family-003', 'user-parent-002', 'head', 'Mother', NOW()),
('fm-007', 'family-003', 'user-guardian-001', 'member', 'Grandfather', NOW()),
('fm-008', 'family-004', 'user-woman-001', 'head', 'Self', NOW()),
('fm-009', 'family-004', 'user-friend-001', 'member', 'Friend', NOW());

-- ============================================
-- INSERT FAMILY RELATIONSHIPS
-- ============================================
INSERT INTO family_relationships (id, family_id, from_user_id, to_user_id, relationship_type) VALUES
('fr-001', 'family-001', 'user-guardian-001', 'user-woman-001', 'parent'),
('fr-002', 'family-002', 'user-guardian-002', 'user-woman-003', 'parent'),
('fr-003', 'family-003', 'user-parent-001', 'user-parent-002', 'spouse'),
('fr-004', 'family-004', 'user-woman-001', 'user-friend-001', 'other');

-- ============================================
-- INSERT FAMILY PLACES
-- ============================================
INSERT INTO family_places (id, family_id, name, place_type, address, latitude, longitude, radius_meters, is_active, created_by, created_at, updated_at) VALUES
('fp-001', 'family-001', 'Patel Home', 'home', '123 Main Road, Mumbai', 19.0760, 72.8777, 100, TRUE, 'user-guardian-001', NOW(), NOW()),
('fp-002', 'family-001', 'St. Mary School', 'school', '456 Education Lane, Mumbai', 19.0780, 72.8800, 200, TRUE, 'user-guardian-001', NOW(), NOW()),
('fp-003', 'family-002', 'Sharma Residence', 'home', '789 Oak Street, Delhi', 28.6139, 77.2090, 100, TRUE, 'user-guardian-002', NOW(), NOW()),
('fp-004', 'family-003', 'Kumar House', 'home', '321 Pine Avenue, Bangalore', 12.9716, 77.5946, 100, TRUE, 'user-parent-001', NOW(), NOW()),
('fp-005', 'family-003', 'Metro Mall', 'park', '555 Shopping Center, Bangalore', 12.9750, 77.6000, 150, TRUE, 'user-parent-001', NOW(), NOW()),
('fp-006', 'family-004', 'Singh Apartment', 'home', '777 Lake View, Chennai', 13.0827, 80.2707, 100, TRUE, 'user-woman-001', NOW(), NOW());

-- ============================================
-- INSERT EMERGENCY CONTACTS
-- ============================================
INSERT INTO emergency_contacts (id, user_id, name, phone, relationship, is_primary, is_verified, contact_type, notes, created_at) VALUES
('ec-001', 'user-woman-001', 'Rajesh Patel', '+919888888888', 'Father', TRUE, FALSE, 'family', 'Primary emergency contact', NOW()),
('ec-002', 'user-woman-001', 'Priya Sharma', '+919777777777', 'Mother', FALSE, FALSE, 'family', NULL, NOW()),
('ec-003', 'user-woman-001', 'Vikram Malhotra', '+919222222222', 'Friend', FALSE, FALSE, 'friend', 'Close friend', NOW()),
('ec-004', 'user-woman-002', 'Amit Kumar', '+919666666666', 'Brother', TRUE, FALSE, 'family', NULL, NOW()),
('ec-005', 'user-woman-003', 'Priya Sharma', '+919777777777', 'Mother', TRUE, FALSE, 'family', NULL, NOW()),
('ec-006', 'user-guardian-001', 'Anjali Singh', '+919444444444', 'Daughter', TRUE, FALSE, 'family', NULL, NOW()),
('ec-007', 'user-guardian-002', 'Deepa Iyer', '+919000000000', 'Daughter', TRUE, FALSE, 'family', NULL, NOW()),
('ec-008', 'user-parent-001', 'Sneha Kumar', '+919555555555', 'Spouse', TRUE, FALSE, 'family', NULL, NOW()),
('ec-009', 'user-parent-002', 'Amit Kumar', '+919666666666', 'Spouse', TRUE, FALSE, 'family', NULL, NOW()),
('ec-010', 'user-admin-001', 'System Admin', '+919999999999', 'Self', TRUE, FALSE, 'personal', NULL, NOW());

-- ============================================
-- INSERT CHILDREN
-- ============================================
INSERT INTO children (id, parent_id, name, date_of_birth, gender, notes, created_at) VALUES
('child-001', 'user-parent-001', 'Arjun Kumar', '2018-05-15', 'male', 'First child', NOW()),
('child-002', 'user-parent-001', 'Myra Kumar', '2020-08-22', 'female', 'Second child', NOW()),
('child-003', 'user-guardian-001', 'Aisha Patel', '2019-03-10', 'female', 'Granddaughter', NOW()),
('child-004', 'user-guardian-002', 'Karthik Sharma', '2021-01-05', 'male', 'Grandson', NOW());

-- ============================================
-- INSERT CHILD ACTIVITIES
-- ============================================
INSERT INTO child_activities (id, child_id, activity_type, notes, created_at) VALUES
('ca-001', 'child-001', 'feeding', 'Had breakfast at 8 AM', NOW()),
('ca-002', 'child-001', 'sleep', 'Nap time from 1 PM to 3 PM', NOW()),
('ca-003', 'child-001', 'medicine', 'Vitamin D supplement', NOW()),
('ca-004', 'child-002', 'feeding', 'Lunch at 12:30 PM', NOW()),
('ca-005', 'child-002', 'sleep', 'Bedtime at 8 PM', NOW()),
('ca-006', 'child-003', 'diaper', 'Changed at 10 AM', NOW()),
('ca-007', 'child-004', 'feeding', 'Evening snack', NOW());

-- ============================================
-- INSERT HOME DEVICES
-- ============================================
INSERT INTO home_devices (id, user_id, name, device_type, room, status, brightness, speed, temperature, is_locked, created_at, updated_at) VALUES
('hd-001', 'user-guardian-001', 'Living Room Light', 'light', 'Living Room', 'on', 80, 0, 24, TRUE, NOW(), NOW()),
('hd-002', 'user-guardian-001', 'Bedroom Fan', 'fan', 'Bedroom', 'on', 0, 3, 24, TRUE, NOW(), NOW()),
('hd-003', 'user-guardian-001', 'Main Door', 'door', 'Entrance', 'off', 0, 0, 24, TRUE, NOW(), NOW()),
('hd-004', 'user-guardian-002', 'Kitchen Light', 'light', 'Kitchen', 'on', 100, 0, 24, TRUE, NOW(), NOW()),
('hd-005', 'user-guardian-002', 'Living Room AC', 'ac', 'Living Room', 'off', 0, 0, 22, TRUE, NOW(), NOW()),
('hd-006', 'user-parent-001', 'Baby Room Monitor', 'camera', 'Baby Room', 'on', 0, 0, 24, TRUE, NOW(), NOW()),
('hd-007', 'user-parent-002', 'Doorbell Camera', 'camera', 'Entrance', 'on', 0, 0, 24, TRUE, NOW(), NOW());

-- ============================================
-- INSERT GEOFENCES
-- ============================================
INSERT INTO geofences (id, user_id, name, latitude, longitude, radius, is_active, created_at) VALUES
('geo-001', 'user-guardian-001', 'Home', 19.0760, 72.8777, 100, TRUE, NOW()),
('geo-002', 'user-guardian-001', 'School', 19.0780, 72.8800, 200, TRUE, NOW()),
('geo-003', 'user-guardian-002', 'Home', 28.6139, 77.2090, 100, TRUE, NOW()),
('geo-004', 'user-parent-001', 'Home', 12.9716, 77.5946, 100, TRUE, NOW()),
('geo-005', 'user-woman-001', 'Home', 13.0827, 80.2707, 100, TRUE, NOW());

-- ============================================
-- INSERT LOCATION HISTORY
-- ============================================
INSERT INTO location_history (id, user_id, latitude, longitude, accuracy, created_at) VALUES
('lh-001', 'user-woman-001', 13.0827, 80.2707, 10, NOW() - INTERVAL 1 HOUR),
('lh-002', 'user-woman-001', 13.0830, 80.2710, 15, NOW() - INTERVAL 30 MINUTE),
('lh-003', 'user-woman-001', 13.0825, 80.2705, 8, NOW() - INTERVAL 10 MINUTE),
('lh-004', 'user-guardian-001', 19.0760, 72.8777, 5, NOW() - INTERVAL 2 HOUR),
('lh-005', 'user-parent-001', 12.9716, 77.5946, 12, NOW() - INTERVAL 45 MINUTE);

-- ============================================
-- INSERT NOTIFICATIONS
-- ============================================
INSERT INTO notifications (id, user_id, title, message, type, is_read, created_at) VALUES
('notif-001', 'user-woman-001', 'Safety Alert', 'Stay safe! Remember to share your location with family.', 'safety', FALSE, NOW() - INTERVAL 1 DAY),
('notif-002', 'user-woman-001', 'AI Assistant', 'Your AI assistant has new safety tips!', 'system', TRUE, NOW() - INTERVAL 2 DAY),
('notif-003', 'user-guardian-001', 'Family Update', 'Anjali has reached home safely.', 'system', FALSE, NOW() - INTERVAL 3 HOUR),
('notif-004', 'user-parent-001', 'Child Activity', 'Arjun logged breakfast activity', 'child', TRUE, NOW() - INTERVAL 5 HOUR),
('notif-005', 'user-admin-001', 'System', 'Database migration completed successfully', 'system', TRUE, NOW() - INTERVAL 1 WEEK);

-- ============================================
-- INSERT THEMES
-- ============================================
INSERT INTO themes (id, name, description, is_default, is_active, config, created_at, updated_at) VALUES
('theme-dark-default', 'Dark Default', 'Default dark theme with purple accents', TRUE, TRUE, '{"colors": {"primary": "#8B5CF6", "background": "#0F0F14"}}', NOW(), NOW()),
('theme-light-default', 'Light Default', 'Default light theme', FALSE, TRUE, '{"colors": {"primary": "#8B5CF6", "background": "#F8FAFC"}}', NOW(), NOW());

-- ============================================
-- INSERT USER THEMES
-- ============================================
INSERT INTO user_themes (id, user_id, theme_id, is_active, created_at) VALUES
('ut-001', 'user-admin-001', 'theme-dark-default', TRUE, NOW()),
('ut-002', 'user-guardian-001', 'theme-dark-default', TRUE, NOW()),
('ut-003', 'user-guardian-002', 'theme-light-default', TRUE, NOW()),
('ut-004', 'user-parent-001', 'theme-dark-default', TRUE, NOW()),
('ut-005', 'user-parent-002', 'theme-light-default', TRUE, NOW()),
('ut-006', 'user-woman-001', 'theme-dark-default', TRUE, NOW()),
('ut-007', 'user-woman-002', 'theme-dark-default', TRUE, NOW()),
('ut-008', 'user-friend-001', 'theme-light-default', TRUE, NOW()),
('ut-009', 'user-friend-002', 'theme-dark-default', TRUE, NOW()),
('ut-010', 'user-woman-003', 'theme-dark-default', TRUE, NOW());

-- ============================================
-- INSERT MENUS - EACH MENU ITEM AS SEPARATE ROW
-- ============================================

-- PRIMARY NAVIGATION - Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible, created_at, updated_at) 
VALUES ('menu-primary-container', 'Primary Navigation', 'primary', TRUE, '[]', 0, '#8B5CF6', '#FFFFFF', 'home', 'mobile', TRUE, NOW(), NOW());

-- PRIMARY MENU ITEMS - Each as separate row with parent_id
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible, required_roles, created_at, updated_at) VALUES
('menu-home', 'Home', 'primary', TRUE, '[]', 'menu-primary-container', 1, 'Home', 'home', 'Home', 'home', 'mobile', TRUE, '["woman", "parent", "guardian", "admin", "friend"]', NOW(), NOW()),
('menu-notifications', 'Notifications', 'primary', TRUE, '[]', 'menu-primary-container', 2, 'Notifications', 'notifications', 'Alerts', 'home', 'mobile', TRUE, '["woman", "parent", "guardian", "admin"]', NOW(), NOW()),
('menu-ai-chat', 'AI Chat', 'primary', TRUE, '[]', 'menu-primary-container', 3, 'AIChat', 'chatbubbles', 'AI Chat', 'home', 'mobile', TRUE, '["woman", "parent", "guardian", "admin", "friend"]', NOW(), NOW()),
('menu-more', 'More', 'primary', TRUE, '[]', 'menu-primary-container', 4, 'More', 'menu', 'More', 'home', 'mobile', TRUE, '["woman", "parent", "guardian", "admin", "friend"]', NOW(), NOW()),
('menu-profile', 'Profile', 'primary', TRUE, '[]', 'menu-primary-container', 5, 'Profile', 'person', 'Profile', 'home', 'mobile', TRUE, '["woman", "parent", "guardian", "admin", "friend"]', NOW(), NOW());

-- MORE MENU CHILDREN - Each as separate row
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
-- Women Safety Section
('menu-women-safety', 'Women Safety', 'secondary', TRUE, '[]', 'menu-more', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'SOS, emergency contacts & safety tips', '#EC4899', 'more', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety', NOW(), NOW()),
('menu-fake-call', 'Fake Call', 'secondary', TRUE, '[]', 'menu-women-safety', 1, 'FakeCall', 'call', 'Fake Call', 'Simulate incoming call', '#10B981', 'more', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety', NOW(), NOW()),
('menu-safe-route', 'Safe Route', 'secondary', TRUE, '[]', 'menu-women-safety', 2, 'SafeRoute', 'navigate', 'Safe Route', 'Find safe routes to destinations', '#3B82F6', 'more', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety', NOW(), NOW()),
('menu-safety-map', 'Safety Map', 'secondary', TRUE, '[]', 'menu-women-safety', 3, 'SafetyMap', 'map', 'Safety Map', 'View safety locations nearby', '#8B5CF6', 'more', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety', NOW(), NOW()),
-- Child Care Section
('menu-child-care', 'Child Care', 'secondary', TRUE, '[]', 'menu-more', 2, 'ChildCare', 'happy', 'Child Care', 'Tips, guidance & assistant', '#10B981', 'more', 'mobile', TRUE, '["parent", "guardian"]', NULL, 'family', NOW(), NOW()),
('menu-behavior-pattern', 'Behavior Pattern', 'secondary', TRUE, '[]', 'menu-child-care', 1, 'BehaviorPattern', 'trending-up', 'Behavior Pattern', 'Track child behavior patterns', '#EC4899', 'more', 'mobile', TRUE, '["parent", "guardian"]', NULL, 'family', NOW(), NOW()),
-- Family Section
('menu-family', 'Family', 'secondary', TRUE, '[]', 'menu-more', 3, 'Family', 'people', 'Family', 'Manage family members & relationships', '#EC4899', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
('menu-family-details', 'Family Details', 'secondary', TRUE, '[]', 'menu-family', 1, 'FamilyDetails', 'information-circle', 'Family Details', 'View family details', '#8B5CF6', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
('menu-family-location', 'Family Location', 'secondary', TRUE, '[]', 'menu-family', 2, 'FamilyLocation', 'location', 'Family Location', 'Track family member locations', '#3B82F6', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
('menu-add-member', 'Add Member', 'secondary', TRUE, '[]', 'menu-family', 3, 'AddMember', 'person-add', 'Add Member', 'Add family member', '#10B981', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
('menu-relationship-editor', 'Relationship Editor', 'secondary', TRUE, '[]', 'menu-family', 4, 'RelationshipEditor', 'git-branch', 'Relationship Editor', 'Edit family relationships', '#F59E0B', 'more', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
-- Home Automation
('menu-home-automation', 'Home Automation', 'secondary', TRUE, '[]', 'menu-more', 4, 'HomeAutomation', 'home', 'Home Automation', 'Control smart devices & appliances', '#3B82F6', 'more', 'mobile', TRUE, NULL, '["home.automation"]', 'lifestyle', NOW(), NOW()),
-- AI Vision & Cylinder
('menu-cylinder-verification', 'Cylinder Verification', 'secondary', TRUE, '[]', 'menu-more', 5, 'CylinderVerification', 'flame', 'Cylinder Verification', 'Verify gas cylinder validity', '#EF4444', 'more', 'mobile', TRUE, NULL, NULL, 'safety', NOW(), NOW()),
('menu-vision', 'Vision AI', 'secondary', TRUE, '[]', 'menu-more', 6, 'Vision', 'camera', 'Vision AI', 'Image analysis with AI', '#8B5CF6', 'more', 'mobile', TRUE, NULL, '["ai.vision"]', 'ai', NOW(), NOW()),
-- Speech & TTS
('menu-speech-to-text', 'Speech to Text', 'secondary', TRUE, '[]', 'menu-more', 7, 'SpeechToText', 'mic', 'Speech to Text', 'Transcribe audio with AI', '#10B981', 'more', 'mobile', TRUE, NULL, '["ai.speech"]', 'ai', NOW(), NOW()),
('menu-text-to-speech', 'Text to Speech', 'secondary', TRUE, '[]', 'menu-more', 8, 'TextToSpeech', 'volume-high', 'Text to Speech', 'Convert text to speech', '#F59E0B', 'more', 'mobile', TRUE, NULL, '["ai.tts"]', 'ai', NOW(), NOW()),
-- AI Features
('menu-thought-generator', 'Thought Generator', 'secondary', TRUE, '[]', 'menu-more', 9, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered thought suggestions', '#EC4899', 'more', 'mobile', TRUE, NULL, '["ai.chat"]', 'ai', NOW(), NOW()),
('menu-models', 'Model Browser', 'secondary', TRUE, '[]', 'menu-more', 10, 'Models', 'server', 'Model Browser', 'Browse and select AI models', '#8B5CF6', 'more', 'mobile', TRUE, NULL, '["ai:read"]', 'ai', NOW(), NOW()),
-- Settings & Profile
('menu-settings', 'Settings', 'secondary', TRUE, '[]', 'menu-more', 11, 'Settings', 'settings', 'Settings', 'API key, preferences & about', '#F59E0B', 'more', 'mobile', TRUE, NULL, '["settings:read"]', 'system', NOW(), NOW()),
('menu-my-profile', 'My Profile', 'secondary', TRUE, '[]', 'menu-more', 12, 'Profile', 'person', 'My Profile', 'View & edit your profile', '#8B5CF6', 'more', 'mobile', TRUE, NULL, '["users:read"]', 'system', NOW(), NOW());

-- CORE SERVICES (Home Screen Cards) - Container
INSERT INTO menus (id, name, type, is_active, items, menu_order, bg_color, text_color, purpose, menu_for, is_visible, created_at, updated_at) 
VALUES ('menu-core-services-container', 'Core Services', 'secondary', TRUE, '[]', 1, '#EC4899', '#FFFFFF', 'home', 'mobile', TRUE, NOW(), NOW());

-- CORE SERVICE ITEMS - Each as separate row
INSERT INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
('svc-women-safety', 'Women Safety', 'secondary', TRUE, '[]', 'menu-core-services-container', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'SOS, emergency contacts & safety tips', '#EC4899', 'home', 'mobile', TRUE, '["woman", "parent", "guardian"]', '["sos.emergency"]', 'safety', NOW(), NOW()),
('svc-child-care', 'Child Care', 'secondary', TRUE, '[]', 'menu-core-services-container', 2, 'ChildCare', 'happy', 'Child Care', 'Tips, guidance & assistant', '#10B981', 'home', 'mobile', TRUE, '["parent", "guardian"]', NULL, 'family', NOW(), NOW()),
('svc-family', 'Family', 'secondary', TRUE, '[]', 'menu-core-services-container', 3, 'Family', 'people', 'Family', 'Manage family members & relationships', '#EC4899', 'home', 'mobile', TRUE, '["parent", "guardian", "admin"]', '["family.tracking"]', 'family', NOW(), NOW()),
('svc-home-automation', 'Home Automation', 'secondary', TRUE, '[]', 'menu-core-services-container', 4, 'HomeAutomation', 'home', 'Home Automation', 'Control smart devices & appliances', '#3B82F6', 'home', 'mobile', TRUE, NULL, '["home.automation"]', 'lifestyle', NOW(), NOW()),
('svc-cylinder', 'Cylinder Verification', 'secondary', TRUE, '[]', 'menu-core-services-container', 5, 'CylinderVerification', 'flame', 'Cylinder Verification', 'Verify gas cylinder validity', '#EF4444', 'home', 'mobile', TRUE, NULL, NULL, 'safety', NOW(), NOW()),
('svc-vision', 'Vision AI', 'secondary', TRUE, '[]', 'menu-core-services-container', 6, 'Vision', 'camera', 'Vision AI', 'Image analysis with AI', '#8B5CF6', 'home', 'mobile', TRUE, NULL, '["ai.vision"]', 'ai', NOW(), NOW()),
('svc-speech', 'Speech to Text', 'secondary', TRUE, '[]', 'menu-core-services-container', 7, 'SpeechToText', 'mic', 'Speech to Text', 'Transcribe audio with AI', '#10B981', 'home', 'mobile', TRUE, NULL, '["ai.speech"]', 'ai', NOW(), NOW()),
('svc-tts', 'Text to Speech', 'secondary', TRUE, '[]', 'menu-core-services-container', 8, 'TextToSpeech', 'volume-high', 'Text to Speech', 'Convert text to speech', '#F59E0B', 'home', 'mobile', TRUE, NULL, '["ai.tts"]', 'ai', NOW(), NOW()),
('svc-models', 'Model Browser', 'secondary', TRUE, '[]', 'menu-core-services-container', 9, 'Models', 'server', 'Model Browser', 'Browse and select AI models', '#8B5CF6', 'home', 'mobile', TRUE, NULL, '["ai:read"]', 'ai', NOW(), NOW()),
('svc-settings', 'Settings', 'secondary', TRUE, '[]', 'menu-core-services-container', 10, 'Settings', 'settings', 'Settings', 'API key, preferences & about', '#F59E0B', 'home', 'mobile', TRUE, NULL, '["settings:read"]', 'system', NOW(), NOW()),
('svc-profile', 'My Profile', 'secondary', TRUE, '[]', 'menu-core-services-container', 11, 'Profile', 'person', 'My Profile', 'View & edit your profile', '#8B5CF6', 'home', 'mobile', TRUE, NULL, '["users:read"]', 'system', NOW(), NOW());

-- ============================================
-- INSERT ROLE PERMISSIONS
-- ============================================
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions, created_at, updated_at) VALUES
('perm-admin', 'admin', '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}', '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}', '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-guardian', 'guardian', '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true}', '{"users": {"read": true, "write": false, "delete": false}, "family": {"read": true, "write": true, "delete": false}, "sos": {"trigger": true, "view_history": true, "manage": false}, "ai": {"read": true, "write": true, "admin": false}, "settings": {"read": true, "write": true}, "menus": {"read": true, "write": false}, "automation": {"read": true, "write": true}}', '{"hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": ["bulk-export"]}', NOW(), NOW()),
('perm-parent', 'parent', '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false}', '{"users": {"read": true, "write": false, "delete": false}, "family": {"read": true, "write": true, "delete": false}, "sos": {"trigger": true, "view_history": true}, "ai": {"read": true, "write": true}, "settings": {"read": true, "write": true}, "menus": {"read": true}, "automation": {"read": false, "write": false}}', '{"hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"]}', NOW(), NOW()),
('perm-woman', 'woman', '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false}', '{"users": {"read": true, "write": false, "delete": false}, "family": {"read": false, "write": false, "delete": false}, "sos": {"trigger": true, "view_history": false}, "ai": {"read": true, "write": true}, "settings": {"read": true, "write": true}, "menus": {"read": true}}', '{"hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"]}', NOW(), NOW()),
('perm-friend', 'friend', '{"sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false}', '{"users": {"read": true, "write": false, "delete": false}, "family": {"read": false, "write": false, "delete": false}, "sos": {"trigger": false, "view_history": false}, "ai": {"read": true, "write": false}, "settings": {"read": true, "write": false}, "menus": {"read": true}}', '{"hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"]}', NOW(), NOW());

-- ============================================
-- INSERT ALL PERMISSIONS FOR ALL USERS (FULL ACCESS)
-- ============================================
INSERT INTO permissions (id, user_id, flags, permissions, ui_restrictions, created_at, updated_at) VALUES
('perm-user-admin-001', 'user-admin-001', 
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-guardian-001', 'user-guardian-001',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-guardian-002', 'user-guardian-002',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-parent-001', 'user-parent-001',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-parent-002', 'user-parent-002',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-woman-001', 'user-woman-001',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-woman-002', 'user-woman-002',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-woman-003', 'user-woman-003',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-friend-001', 'user-friend-001',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW()),
('perm-user-friend-002', 'user-friend-002',
 '{"sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true}',
 '{"users": {"read": true, "write": true, "delete": true}, "family": {"read": true, "write": true, "delete": true}, "sos": {"trigger": true, "view_history": true, "manage": true}, "ai": {"read": true, "write": true, "admin": true}, "settings": {"read": true, "write": true, "admin": true}, "menus": {"read": true, "write": true}, "themes": {"read": true, "write": true}, "automation": {"read": true, "write": true, "delete": true}}',
 '{"hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": []}', NOW(), NOW());

-- ============================================
-- INSERT CONSENT SETTINGS
-- ============================================
INSERT INTO consent_settings (id, user_id, location_enabled, activity_enabled, calendar_enabled, analytics_enabled, family_agent_enabled, created_at, updated_at) VALUES
('cs-001', 'user-admin-001', TRUE, TRUE, FALSE, TRUE, TRUE, NOW(), NOW()),
('cs-002', 'user-guardian-001', TRUE, TRUE, TRUE, TRUE, TRUE, NOW(), NOW()),
('cs-003', 'user-guardian-002', TRUE, TRUE, TRUE, TRUE, TRUE, NOW(), NOW()),
('cs-004', 'user-parent-001', TRUE, TRUE, TRUE, TRUE, TRUE, NOW(), NOW()),
('cs-005', 'user-parent-002', TRUE, TRUE, TRUE, TRUE, TRUE, NOW(), NOW()),
('cs-006', 'user-woman-001', TRUE, TRUE, FALSE, TRUE, TRUE, NOW(), NOW()),
('cs-007', 'user-woman-002', TRUE, TRUE, FALSE, TRUE, TRUE, NOW(), NOW()),
('cs-008', 'user-friend-001', FALSE, FALSE, FALSE, FALSE, TRUE, NOW(), NOW()),
('cs-009', 'user-friend-002', FALSE, FALSE, FALSE, FALSE, TRUE, NOW(), NOW()),
('cs-010', 'user-woman-003', TRUE, TRUE, FALSE, TRUE, TRUE, NOW(), NOW());

-- ============================================
-- VERIFICATION CONFIRMATION
-- ============================================
SELECT 'Sample database created successfully!' as message;
SELECT 'All tables created with proper schema' as tables;
SELECT 'All sample data inserted successfully!' as data;
SELECT 'All menus as separate rows in database!' as menus;
SELECT 'All permissions assigned to all users with FULL ACCESS!' as permissions;
SELECT 'Password for all users: Password@123' as password;
