-- Migration: Add parent-child hierarchical support to menus table
-- Created: 2026-03-05
-- Purpose: Enable menus to have parent-child relationships for hierarchical navigation

-- ============================================
-- STEP 0: Handle existing data
-- ============================================

-- Note: If menus already exist, we need to ensure the new columns exist
-- Run this to add columns without dropping existing data

-- ============================================
-- STEP 1: Add new columns for parent support
-- ============================================

ALTER TABLE menus 
ADD COLUMN IF NOT EXISTS parent_id VARCHAR(36) DEFAULT NULL,
ADD COLUMN IF NOT EXISTS menu_order INT DEFAULT 0,
ADD COLUMN IF NOT EXISTS bg_color VARCHAR(20) DEFAULT '#8B5CF6',
ADD COLUMN IF NOT EXISTS text_color VARCHAR(20) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS hover_bg_color VARCHAR(20) DEFAULT '#7C3AED',
ADD COLUMN IF NOT EXISTS hover_text_color VARCHAR(20) DEFAULT '#FFFFFF',
ADD COLUMN IF NOT EXISTS label VARCHAR(100),
ADD COLUMN IF NOT EXISTS route VARCHAR(100),
ADD COLUMN IF NOT EXISTS icon VARCHAR(50),
ADD COLUMN IF NOT EXISTS subtitle VARCHAR(255),
ADD COLUMN IF NOT EXISTS purpose ENUM('home', 'more', 'profile') DEFAULT 'more',
ADD COLUMN IF NOT EXISTS menu_for ENUM('web', 'mobile') DEFAULT 'mobile',
ADD COLUMN IF NOT EXISTS is_visible BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS required_flags JSON,
ADD COLUMN IF NOT EXISTS required_permissions JSON,
ADD COLUMN IF NOT EXISTS required_roles JSON,
ADD COLUMN IF NOT EXISTS category VARCHAR(50);

-- Add foreign key constraint
ALTER TABLE menus 
ADD CONSTRAINT IF NOT EXISTS fk_menus_parent 
FOREIGN KEY (parent_id) REFERENCES menus(id) ON DELETE SET NULL;

-- ============================================
-- STEP 2: Create indexes for performance
-- ============================================

CREATE INDEX IF NOT EXISTS idx_menus_parent ON menus(parent_id);
CREATE INDEX IF NOT EXISTS idx_menus_order ON menus(menu_order);
CREATE INDEX IF NOT EXISTS idx_menus_purpose ON menus(purpose);
CREATE INDEX IF NOT EXISTS idx_menus_menu_for ON menus(menu_for);

-- ============================================
-- STEP 3: Update existing menus with default values
-- ============================================

-- Update primary menu
UPDATE menus 
SET 
    bg_color = COALESCE(bg_color, '#8B5CF6'),
    text_color = COALESCE(text_color, '#FFFFFF'),
    hover_bg_color = COALESCE(hover_bg_color, '#7C3AED'),
    hover_text_color = COALESCE(hover_text_color, '#FFFFFF'),
    menu_order = COALESCE(menu_order, 0),
    purpose = COALESCE(purpose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    is_visible = COALESCE(is_visible, TRUE)
WHERE type = 'primary';

-- Update secondary menu
UPDATE menus 
SET 
    bg_color = COALESCE(bg_color, '#EC4899'),
    text_color = COALESCE(text_color, '#FFFFFF'),
    hover_bg_color = COALESCE(hover_bg_color, '#DB2777'),
    hover_text_color = COALESCE(hover_text_color, '#FFFFFF'),
    menu_order = COALESCE(menu_order, 1),
    purpose = COALESCE(purpose, 'more'),
    menu_for = COALESCE(menu_for, 'mobile'),
    is_visible = COALESCE(is_visible, TRUE)
WHERE type = 'secondary';

-- Migration complete
SELECT 'Migration: Parent-child hierarchical support added to menus table' as status;
