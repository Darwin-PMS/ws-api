-- Migration: Add missing role_permissions and module permissions
-- Created: 2026-03-13

-- ==============================================================================
-- ADD MISSING ROLE PERMISSIONS
-- ==============================================================================

-- Guardian Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'guardian', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": false }, "automation": { "read": true, "write": true, "delete": false }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Parent Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'parent', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "automation": { "read": false, "write": false }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Friend Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'friend', 
'{ "sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false, "fake.call": false, "siren": false, "evidence.recording": false, "grievance.enabled": false, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": false, "view_history": false }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "grievance": { "read": false, "write": false }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Supervisor Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'supervisor', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "areas.manage": true, "reports.view": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": true }, "reports": { "read": true }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Village Head Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'village_head', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "admin.panel": false, "users.manage": false, "areas.manage": true, "reports.view": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "view_history": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": true }, "reports": { "read": true }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Local Police Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'local_police', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": false, "users.manage": false, "areas.manage": true, "reports.view": true, "reports.export": true, "fake.call": false, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_area": true, "view_all": false, "manage": true, "resolve": true }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "areas": { "read": true, "write": true }, "reports": { "read": true, "export": true }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- Agency Admin Role Permissions
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'agency_admin', 
'{ "sos.emergency": true, "sos.manage_all": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": false, "areas.manage": true, "reports.view": true, "reports.export": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true }',
'{ "users": { "read": true, "write": true, "delete": false }, "family": { "read": true, "write": false, "delete": false }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": false, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "themes": { "read": true }, "areas": { "read": true, "write": true }, "reports": { "read": true, "export": true }, "grievance": { "read": true, "write": true }, "news": { "read": true, "write": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }')
ON DUPLICATE KEY UPDATE flags = VALUES(flags), base_permissions = VALUES(base_permissions), ui_restrictions = VALUES(ui_restrictions);

-- ==============================================================================
-- UPDATE EXISTING ROLES WITH NEW MODULE PERMISSIONS
-- ==============================================================================

-- Update system_admin with new module permissions
UPDATE role_permissions SET
    flags = JSON_SET(IFNULL(flags, '{}'), '$.fake.call', true, '$.siren', true, '$.evidence.recording', true, '$.grievance.enabled', true, '$.news.view', true, '$.tutorial.view', true, '$.helpline.view', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.grievance.read', true, '$.grievance.write', true, '$.news.read', true, '$.news.write', true, '$.tutorial.read', true)
WHERE role = 'system_admin';

-- Update admin with new module permissions
UPDATE role_permissions SET
    flags = JSON_SET(IFNULL(flags, '{}'), '$.fake.call', true, '$.siren', true, '$.evidence.recording', true, '$.grievance.enabled', true, '$.news.view', true, '$.tutorial.view', true, '$.helpline.view', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.grievance.read', true, '$.grievance.write', true, '$.news.read', true, '$.news.write', true, '$.tutorial.read', true)
WHERE role = 'admin';

-- Update woman with new module permissions
UPDATE role_permissions SET
    flags = JSON_SET(IFNULL(flags, '{}'), '$.fake.call', true, '$.siren', true, '$.evidence.recording', true, '$.grievance.enabled', true, '$.news.view', true, '$.tutorial.view', true, '$.helpline.view', true),
    base_permissions = JSON_SET(IFNULL(base_permissions, '{}'), '$.grievance.read', true, '$.grievance.write', true, '$.news.read', true, '$.tutorial.read', true)
WHERE role = 'woman';

-- ==============================================================================
-- SYNC USER PERMISSIONS WITH NEW ROLE PERMISSIONS
-- ==============================================================================

-- Update user permissions based on their roles
UPDATE permissions p
SET 
    flags = (
        SELECT flags FROM role_permissions rp 
        WHERE rp.role = (SELECT role FROM users u WHERE u.id = p.user_id)
    ),
    permissions = (
        SELECT base_permissions FROM role_permissions rp 
        WHERE rp.role = (SELECT role FROM users u WHERE u.id = p.user_id)
    ),
    ui_restrictions = (
        SELECT ui_restrictions FROM role_permissions rp 
        WHERE rp.role = (SELECT role FROM users u WHERE u.id = p.user_id)
    )
WHERE EXISTS (
    SELECT 1 FROM role_permissions rp 
    WHERE rp.role = (SELECT role FROM users u WHERE u.id = p.user_id)
);

-- Migration complete
SELECT 'Migration 013: Missing role_permissions and module permissions added successfully' as message;
