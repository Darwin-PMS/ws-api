-- ============================================
-- THOUGHT GENERATOR & AI VISION & SPEECH MENU MIGRATION
-- Created: 2026-03-07
-- Purpose: Add ThoughtGenerator, Vision, Speech, TTS screens to menus and link with users
-- ============================================

USE safety_app;

-- ============================================
-- ADD THOUGHT GENERATOR MENU (Using INSERT IGNORE to avoid duplicates)
-- ============================================

-- Add to 'More' menu (menu-thought-generator)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
('menu-thought-generator', 'Thought Generator', 'secondary', TRUE, '[]', 'menu-more', 9, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered thought suggestions', '#EC4899', 'more', 'mobile', TRUE, NULL, '["ai.chat"]', 'ai', NOW(), NOW());

-- Also add to Core Services (svc-thought-generator)
INSERT IGNORE INTO menus (id, name, type, is_active, items, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, required_flags, category, created_at, updated_at) VALUES
('svc-thought-generator', 'Thought Generator', 'secondary', TRUE, '[]', 'menu-core-services-container', 12, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered thought suggestions', '#EC4899', 'home', 'mobile', TRUE, NULL, '["ai.chat"]', 'ai', NOW(), NOW());

-- ============================================
-- UPDATE EXISTING MENU ORDER IF NEEDED
-- ============================================
-- Ensure ThoughtGenerator is in the correct position in More menu
UPDATE menus SET menu_order = 9, route = 'ThoughtGenerator', icon = 'bulb', label = 'Thought Generator' 
WHERE id = 'menu-thought-generator' AND route != 'ThoughtGenerator';

-- ============================================
-- ADD ALL AI PERMISSIONS FOR USERS (chat, vision, speech, tts)
-- ============================================

-- Add ai.chat, ai.vision, ai.speech, ai.tts flags to all existing users in permissions table
UPDATE permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE flags IS NOT NULL;

-- Add ai.chat, ai.vision, ai.speech, ai.tts flags to all existing users in role_permissions table
UPDATE role_permissions SET 
    flags = JSON_SET(IFNULL(flags, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE flags IS NOT NULL;

-- Grant ai.chat, ai.vision, ai.speech, ai.tts permission to all users
UPDATE permissions SET 
    permissions = JSON_SET(IFNULL(permissions, '{}'), '$.ai.chat', true, '$.ai.vision', true, '$.ai.speech', true, '$.ai.tts', true)
WHERE permissions IS NOT NULL;

-- ============================================
-- UPDATE MENU ROUTE NAMES TO MATCH NAVIGATOR
-- ============================================
-- Fix route names to match the navigator screen names
UPDATE menus SET route = 'SpeechToText' WHERE route = 'Speech' OR route = 'speech-to-text';
UPDATE menus SET route = 'TextToSpeech' WHERE route = 'TTS' OR route = 'text-to-speech';
UPDATE menus SET route = 'SpeechToText' WHERE label LIKE '%Speech to Text%';
UPDATE menus SET route = 'TextToSpeech' WHERE label LIKE '%Text to Speech%';

-- ============================================
-- VERIFICATION
-- ============================================
SELECT 'ThoughtGenerator, AI Vision, Speech, TTS menu migration completed!' as message;

-- Show Speech and TextToSpeech menu entries
SELECT id, name, route, icon, label, purpose, menu_for, is_visible, required_roles, required_flags 
FROM menus 
WHERE route IN ('SpeechToText', 'TextToSpeech', 'ThoughtGenerator', 'Vision');

-- Verify permissions were updated
SELECT id, user_id, flags FROM permissions LIMIT 5;

-- Verify role permissions were updated
SELECT id, role, flags FROM role_permissions;
