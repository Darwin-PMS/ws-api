-- Create session_history table for tracking user login/logout/force_logout events

CREATE TABLE IF NOT EXISTS session_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    action ENUM('login', 'logout', 'force_logout') NOT NULL,
    app_version VARCHAR(50),
    device_info VARCHAR(255),
    device_id VARCHAR(255),
    os_version VARCHAR(50),
    ip_address VARCHAR(45),
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    location_name VARCHAR(255),
    user_agent TEXT,
    success BOOLEAN DEFAULT TRUE,
    reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at),
    INDEX idx_action (action)
);
