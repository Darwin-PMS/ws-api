-- ==============================================================================
-- Women Safety App - Complete Database Dump
-- Created: 2026-03-13
-- Description: Full database schema with all tables, permissions, menus, and sample data
-- ==============================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ==============================================================================
-- TABLE: users
-- ==============================================================================
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(36) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'woman',
  `is_verified` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `verification_code` varchar(10) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: themes
-- ==============================================================================
DROP TABLE IF EXISTS `themes`;
CREATE TABLE `themes` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `description` TEXT,
  `is_default` BOOLEAN DEFAULT FALSE,
  `is_active` BOOLEAN DEFAULT TRUE,
  `config` JSON NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_themes_active` (`is_active`),
  INDEX `idx_themes_default` (`is_default`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: user_themes
-- ==============================================================================
DROP TABLE IF EXISTS `user_themes`;
CREATE TABLE `user_themes` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `theme_id` varchar(36) NOT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`theme_id`) REFERENCES `themes`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_user_active_theme` (`user_id`, `is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: menus
-- ==============================================================================
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `type` ENUM('primary', 'secondary', 'footer', 'sidebar') DEFAULT 'primary',
  `is_active` BOOLEAN DEFAULT TRUE,
  `items` JSON NOT NULL,
  `parent_id` varchar(36) DEFAULT NULL,
  `menu_order` INT DEFAULT 0,
  `route` varchar(100) DEFAULT NULL,
  `icon` varchar(50) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `subtitle` TEXT,
  `bg_color` varchar(20) DEFAULT NULL,
  `text_color` varchar(20) DEFAULT NULL,
  `purpose` varchar(50) DEFAULT NULL,
  `menu_for` varchar(50) DEFAULT 'mobile',
  `is_visible` BOOLEAN DEFAULT TRUE,
  `required_roles` JSON DEFAULT NULL,
  `required_flags` JSON DEFAULT NULL,
  `required_permissions` JSON DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_menus_type` (`type`),
  INDEX `idx_menus_active` (`is_active`),
  INDEX `idx_menus_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: permissions
-- ==============================================================================
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `flags` JSON,
  `permissions` JSON,
  `ui_restrictions` JSON,
  `expires_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_user_permission` (`user_id`),
  INDEX `idx_permissions_user` (`user_id`),
  INDEX `idx_permissions_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: role_permissions
-- ==============================================================================
DROP TABLE IF EXISTS `role_permissions`;
CREATE TABLE `role_permissions` (
  `id` varchar(36) PRIMARY KEY,
  `role` varchar(50) NOT NULL,
  `flags` JSON,
  `base_permissions` JSON,
  `ui_restrictions` JSON,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_role` (`role`),
  INDEX `idx_role_permissions_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: default_emergency_contacts
-- ==============================================================================
DROP TABLE IF EXISTS `default_emergency_contacts`;
CREATE TABLE `default_emergency_contacts` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `description` TEXT,
  `country` varchar(50) DEFAULT 'India',
  `service_type` varchar(50) DEFAULT 'emergency',
  `is_active` BOOLEAN DEFAULT TRUE,
  `display_order` INT DEFAULT 0,
  `icon` varchar(50) DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_dec_service` (`service_type`),
  INDEX `idx_dec_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: user_emergency_contacts
-- ==============================================================================
DROP TABLE IF EXISTS `user_emergency_contacts`;
CREATE TABLE `user_emergency_contacts` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `is_primary` BOOLEAN DEFAULT FALSE,
  `notify_priority` INT DEFAULT 0,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_uec_user` (`user_id`),
  INDEX `idx_uec_primary` (`is_primary`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: user_emergency_preferences
-- ==============================================================================
DROP TABLE IF EXISTS `user_emergency_preferences`;
CREATE TABLE `user_emergency_preferences` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL UNIQUE,
  `enable_sos` BOOLEAN DEFAULT TRUE,
  `auto_share_location` BOOLEAN DEFAULT TRUE,
  `notify_emergency_contacts` BOOLEAN DEFAULT TRUE,
  `sos_sound_enabled` BOOLEAN DEFAULT TRUE,
  `sos_vibration_enabled` BOOLEAN DEFAULT TRUE,
  `emergency_message` TEXT,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: user_settings
-- ==============================================================================
DROP TABLE IF EXISTS `user_settings`;
CREATE TABLE `user_settings` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL UNIQUE,
  `notification_enabled` BOOLEAN DEFAULT TRUE,
  `location_sharing` BOOLEAN DEFAULT TRUE,
  `auto_sos` BOOLEAN DEFAULT FALSE,
  `shake_to_sos` BOOLEAN DEFAULT FALSE,
  `sos_timer` INT DEFAULT 30,
  `shake_sensitivity` INT DEFAULT 3,
  `volume_press_enabled` BOOLEAN DEFAULT FALSE,
  `power_press_enabled` BOOLEAN DEFAULT FALSE,
  `voice_enabled` BOOLEAN DEFAULT FALSE,
  `auto_sos_enabled` BOOLEAN DEFAULT FALSE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_us_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: app_settings
-- ==============================================================================
DROP TABLE IF EXISTS `app_settings`;
CREATE TABLE `app_settings` (
  `id` varchar(36) PRIMARY KEY,
  `setting_key` varchar(100) UNIQUE NOT NULL,
  `setting_value` TEXT NOT NULL,
  `description` TEXT,
  `is_encrypted` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: families
-- ==============================================================================
DROP TABLE IF EXISTS `families`;
CREATE TABLE `families` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `description` TEXT,
  `created_by` varchar(36) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_families_creator` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: family_members
-- ==============================================================================
DROP TABLE IF EXISTS `family_members`;
CREATE TABLE `family_members` (
  `id` varchar(36) PRIMARY KEY,
  `family_id` varchar(36) NOT NULL,
  `user_id` varchar(36) NOT NULL,
  `role` ENUM('head', 'member', 'admin') DEFAULT 'member',
  `nickname` varchar(50) DEFAULT NULL,
  `joined_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`family_id`) REFERENCES `families`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_family_member` (`family_id`, `user_id`),
  INDEX `idx_fm_family` (`family_id`),
  INDEX `idx_fm_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: family_relationships
-- ==============================================================================
DROP TABLE IF EXISTS `family_relationships`;
CREATE TABLE `family_relationships` (
  `id` varchar(36) PRIMARY KEY,
  `family_id` varchar(36) NOT NULL,
  `from_user_id` varchar(36) NOT NULL,
  `to_user_id` varchar(36) NOT NULL,
  `relationship_type` ENUM('parent', 'child', 'spouse', 'sibling', 'grandparent', 'grandchild', 'other') NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`family_id`) REFERENCES `families`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`from_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`to_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_fr_family` (`family_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: family_places
-- ==============================================================================
DROP TABLE IF EXISTS `family_places`;
CREATE TABLE `family_places` (
  `id` varchar(36) PRIMARY KEY,
  `family_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `place_type` ENUM('home', 'school', 'office', 'park', 'other') DEFAULT 'other',
  `address` TEXT,
  `latitude` DECIMAL(10, 8),
  `longitude` DECIMAL(11, 8),
  `radius_meters` INT DEFAULT 100,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_by` varchar(36) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`family_id`) REFERENCES `families`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_fp_family` (`family_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: home_devices
-- ==============================================================================
DROP TABLE IF EXISTS `home_devices`;
CREATE TABLE `home_devices` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `device_type` ENUM('light', 'fan', 'ac', 'camera', 'lock', 'other') DEFAULT 'other',
  `room` varchar(50) DEFAULT NULL,
  `status` ENUM('on', 'off') DEFAULT 'off',
  `brightness` INT DEFAULT 0,
  `is_locked` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_hd_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: geofences
-- ==============================================================================
DROP TABLE IF EXISTS `geofences`;
CREATE TABLE `geofences` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `name` varchar(100) NOT NULL,
  `latitude` DECIMAL(10, 8) NOT NULL,
  `longitude` DECIMAL(11, 8) NOT NULL,
  `radius` INT DEFAULT 100,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_geofence_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: location_history
-- ==============================================================================
DROP TABLE IF EXISTS `location_history`;
CREATE TABLE `location_history` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `latitude` DECIMAL(10, 8) NOT NULL,
  `longitude` DECIMAL(11, 8) NOT NULL,
  `accuracy` INT DEFAULT 0,
  `timestamp` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_lh_user` (`user_id`),
  INDEX `idx_lh_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: sos_alerts
-- ==============================================================================
DROP TABLE IF EXISTS `sos_alerts`;
CREATE TABLE `sos_alerts` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `latitude` DECIMAL(10, 8),
  `longitude` DECIMAL(11, 8),
  `status` ENUM('active', 'acknowledged', 'resolved', 'cancelled') DEFAULT 'active',
  `trigger_method` ENUM('button', 'shake', 'voice', 'auto') DEFAULT 'button',
  `message` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `resolved_at` TIMESTAMP NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_sos_user` (`user_id`),
  INDEX `idx_sos_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: children
-- ==============================================================================
DROP TABLE IF EXISTS `children`;
CREATE TABLE `children` (
  `id` varchar(36) PRIMARY KEY,
  `parent_id` varchar(36) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100),
  `date_of_birth` DATE NOT NULL,
  `gender` ENUM('male', 'female', 'other'),
  `blood_group` varchar(10),
  `allergies` JSON,
  `medications` JSON,
  `emergency_contact` varchar(255),
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`parent_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: behavior_patterns
-- ==============================================================================
DROP TABLE IF EXISTS `behavior_patterns`;
CREATE TABLE `behavior_patterns` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `pattern_type` varchar(50) NOT NULL,
  `pattern_data` JSON NOT NULL,
  `confidence` DECIMAL(5, 2) DEFAULT 0.00,
  `is_anomalous` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_bp_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: behavior_alerts
-- ==============================================================================
DROP TABLE IF EXISTS `behavior_alerts`;
CREATE TABLE `behavior_alerts` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `alert_type` varchar(50) NOT NULL,
  `severity` ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
  `message` TEXT NOT NULL,
  `metadata` JSON,
  `is_read` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_ba_user` (`user_id`),
  INDEX `idx_ba_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: cylinder_verifications
-- ==============================================================================
DROP TABLE IF EXISTS `cylinder_verifications`;
CREATE TABLE `cylinder_verifications` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `cylinder_number` varchar(50),
  `verification_result` ENUM('genuine', 'suspected', 'invalid', 'pending') DEFAULT 'pending',
  `expiry_date` DATE,
  `confidence_score` DECIMAL(5, 2),
  `image_url` TEXT,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_cv_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: thought_records
-- ==============================================================================
DROP TABLE IF EXISTS `thought_records`;
CREATE TABLE `thought_records` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `category` varchar(50) NOT NULL,
  `thought_text` TEXT NOT NULL,
  `ai_response` TEXT,
  `mood` varchar(50),
  `is_favorite` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_tr_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: geographic_areas
-- ==============================================================================
DROP TABLE IF EXISTS `geographic_areas`;
CREATE TABLE `geographic_areas` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `type` ENUM('state', 'district', 'taluk', 'village', 'ward', 'block', 'panchayat') NOT NULL,
  `code` varchar(50) UNIQUE,
  `latitude` DECIMAL(10, 8),
  `longitude` DECIMAL(11, 8),
  `parent_area_id` varchar(36) DEFAULT NULL,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`parent_area_id`) REFERENCES `geographic_areas`(`id`) ON DELETE SET NULL,
  INDEX `idx_ga_type` (`type`),
  INDEX `idx_ga_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: user_area_assignments
-- ==============================================================================
DROP TABLE IF EXISTS `user_area_assignments`;
CREATE TABLE `user_area_assignments` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `area_id` varchar(36) NOT NULL,
  `role_in_area` ENUM('admin', 'police', 'supervisor', 'village_head', 'guardian', 'member') DEFAULT 'member',
  `is_primary` BOOLEAN DEFAULT FALSE,
  `assigned_by` varchar(36) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`area_id`) REFERENCES `geographic_areas`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`assigned_by`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  UNIQUE KEY `unique_user_area` (`user_id`, `area_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: safety_laws
-- ==============================================================================
DROP TABLE IF EXISTS `safety_laws`;
CREATE TABLE `safety_laws` (
  `id` varchar(36) PRIMARY KEY,
  `title` varchar(200) NOT NULL,
  `description` TEXT NOT NULL,
  `content` TEXT,
  `category` varchar(50) DEFAULT NULL,
  `jurisdiction` varchar(100) DEFAULT 'National',
  `effective_date` DATE,
  `penalties` TEXT,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_sl_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: safety_news
-- ==============================================================================
DROP TABLE IF EXISTS `safety_news`;
CREATE TABLE `safety_news` (
  `id` varchar(36) PRIMARY KEY,
  `title` varchar(200) NOT NULL,
  `summary` TEXT,
  `content` TEXT NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `image_url` TEXT,
  `is_featured` BOOLEAN DEFAULT FALSE,
  `is_active` BOOLEAN DEFAULT TRUE,
  `published_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_sn_category` (`category`),
  INDEX `idx_sn_published` (`published_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: safety_tutorials
-- ==============================================================================
DROP TABLE IF EXISTS `safety_tutorials`;
CREATE TABLE `safety_tutorials` (
  `id` varchar(36) PRIMARY KEY,
  `title` varchar(200) NOT NULL,
  `summary` TEXT,
  `content` TEXT NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `difficulty` ENUM('beginner', 'intermediate', 'advanced') DEFAULT 'beginner',
  `duration_minutes` INT DEFAULT 0,
  `video_url` TEXT,
  `image_url` TEXT,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_st_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: grievances
-- ==============================================================================
DROP TABLE IF EXISTS `grievances`;
CREATE TABLE `grievances` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` TEXT NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `status` ENUM('pending', 'in_progress', 'resolved', 'rejected') DEFAULT 'pending',
  `resolution` TEXT,
  `resolved_by` varchar(36) DEFAULT NULL,
  `resolved_at` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_g_user` (`user_id`),
  INDEX `idx_g_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: safety_zones
-- ==============================================================================
DROP TABLE IF EXISTS `safety_zones`;
CREATE TABLE `safety_zones` (
  `id` varchar(36) PRIMARY KEY,
  `name` varchar(100) NOT NULL,
  `description` TEXT,
  `latitude` DECIMAL(10, 8) NOT NULL,
  `longitude` DECIMAL(11, 8) NOT NULL,
  `radius` INT DEFAULT 50,
  `zone_type` ENUM('safe', 'caution', 'danger') DEFAULT 'safe',
  `reported_by` varchar(36) NOT NULL,
  `upvotes` INT DEFAULT 0,
  `downvotes` INT DEFAULT 0,
  `is_verified` BOOLEAN DEFAULT FALSE,
  `is_active` BOOLEAN DEFAULT TRUE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`reported_by`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_sz_type` (`zone_type`),
  INDEX `idx_sz_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==============================================================================
-- TABLE: notifications
-- ==============================================================================
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` varchar(36) PRIMARY KEY,
  `user_id` varchar(36) NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` TEXT NOT NULL,
  `type` ENUM('sos', 'alert', 'info', 'warning', 'success') DEFAULT 'info',
  `data` JSON,
  `is_read` BOOLEAN DEFAULT FALSE,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  INDEX `idx_notif_user` (`user_id`),
  INDEX `idx_notif_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ==============================================================================
-- INSERT SAMPLE USERS
-- ==============================================================================
INSERT INTO users (id, first_name, last_name, email, phone, password, role, is_verified, is_active) VALUES
('user-admin-001', 'System', 'Administrator', 'admin@safetyapp.com', '+919999999999', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'admin', TRUE, TRUE),
('user-guardian-001', 'Rajesh', 'Patel', 'rajesh.patel@email.com', '+919888888888', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'guardian', TRUE, TRUE),
('user-guardian-002', 'Priya', 'Sharma', 'priya.sharma@email.com', '+919777777777', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'guardian', TRUE, TRUE),
('user-parent-001', 'Amit', 'Kumar', 'amit.kumar@email.com', '+919666666666', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'parent', TRUE, TRUE),
('user-parent-002', 'Sneha', 'Kumar', 'sneha.kumar@email.com', '+919555555555', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'parent', TRUE, TRUE),
('user-woman-001', 'Anjali', 'Singh', 'anjali.singh@email.com', '+919444444444', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'woman', TRUE, TRUE),
('user-woman-002', 'Pooja', 'Gupta', 'pooja.gupta@email.com', '+919333333333', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'woman', TRUE, TRUE),
('user-friend-001', 'Vikram', 'Malhotra', 'vikram.malhotra@email.com', '+919222222222', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'friend', TRUE, TRUE),
('user-friend-002', 'Meera', 'Reddy', 'meera.reddy@email.com', '+919111111111', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'friend', TRUE, TRUE),
('user-woman-003', 'Deepa', 'Iyer', 'deepa.iyer@email.com', '+919000000000', '$2a$10$Ou7DF/h3kEn7mUdJbSrZDep7yfV3JNF.OC3MCeA0QmawZZBB7WpNW', 'woman', TRUE, TRUE);

-- ==============================================================================
-- INSERT ROLE PERMISSIONS
-- ==============================================================================

-- System Admin
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'system_admin', 
'{ "sos.emergency": true, "sos.manage_all": true, "sos.assign": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true, "helpline.view": true, "safety.map.view": true, "safety.map.report": true, "safe.route.view": true, "behavior.analysis": true, "cylinder.verification": true }',
'{ "users": { "read": true, "write": true, "delete": true, "assign_roles": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_all": true, "view_area": true, "manage": true, "assign": true, "resolve": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "areas": { "read": true, "write": true, "delete": true }, "roles": { "read": true, "write": true }, "grievance": { "read": true, "write": true }, "news": { "read": true, "write": true }, "tutorial": { "read": true }, "safety_map": { "view": true, "report": true, "vote": true }, "safe_route": { "view": true, "create": true }, "cylinder": { "read": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }');

-- Admin
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'admin', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": true, "export.data": true, "admin.panel": true, "users.manage": true, "roles.manage": true, "areas.manage": true, "reports.view": true, "reports.export": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true, "helpline.view": true, "safety.map.view": true, "safe.route.view": true, "behavior.analysis": true }',
'{ "users": { "read": true, "write": true, "delete": true }, "family": { "read": true, "write": true, "delete": true }, "sos": { "trigger": true, "view_history": true, "manage": true }, "ai": { "read": true, "write": true, "admin": true }, "settings": { "read": true, "write": true, "admin": true }, "menus": { "read": true, "write": true }, "themes": { "read": true, "write": true }, "automation": { "read": true, "write": true, "delete": true }, "grievance": { "read": true, "write": true }, "news": { "read": true, "write": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": [], "readOnlyFields": [], "disabledFeatures": [] }');

-- Guardian
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'guardian', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": true, "advanced.models": false, "export.data": true, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true, "helpline.view": true, "safety.map.view": true, "safe.route.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true, "manage": false }, "ai": { "read": true, "write": true, "admin": false }, "settings": { "read": true, "write": true }, "menus": { "read": true, "write": false }, "automation": { "read": true, "write": true, "delete": false }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel"], "readOnlyFields": ["user.role"], "disabledFeatures": [] }');

-- Parent
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'parent', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": true, "home.automation": false, "advanced.models": false, "export.data": false, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true, "helpline.view": true, "safety.map.view": true, "safe.route.view": true, "behavior.analysis": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": true, "write": true, "delete": false }, "sos": { "trigger": true, "view_history": true }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation"], "readOnlyFields": ["user.role", "family.settings"], "disabledFeatures": ["advanced-settings"] }');

-- Woman
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'woman', 
'{ "sos.emergency": true, "ai.chat": true, "ai.vision": true, "ai.speech": true, "ai.tts": true, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false, "fake.call": true, "siren": true, "evidence.recording": true, "grievance.enabled": true, "news.view": true, "tutorial.view": true, "helpline.view": true, "safety.map.view": true, "safe.route.view": true, "behavior.analysis": true, "cylinder.verification": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": true, "view_history": false }, "ai": { "read": true, "write": true }, "settings": { "read": true, "write": true }, "menus": { "read": true }, "grievance": { "read": true, "write": true }, "news": { "read": true }, "tutorial": { "read": true }, "cylinder": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement"], "readOnlyFields": ["user.role"], "disabledFeatures": ["family-tracking", "advanced-settings"] }');

-- Friend
INSERT INTO role_permissions (id, role, flags, base_permissions, ui_restrictions) VALUES
(UUID(), 'friend', 
'{ "sos.emergency": false, "ai.chat": true, "ai.vision": false, "ai.speech": false, "ai.tts": false, "family.tracking": false, "home.automation": false, "advanced.models": false, "export.data": false, "fake.call": false, "siren": false, "evidence.recording": false, "grievance.enabled": false, "news.view": true, "tutorial.view": true, "helpline.view": true }',
'{ "users": { "read": true, "write": false, "delete": false }, "family": { "read": false, "write": false, "delete": false }, "sos": { "trigger": false, "view_history": false }, "ai": { "read": true, "write": false }, "settings": { "read": true, "write": false }, "menus": { "read": true }, "news": { "read": true }, "tutorial": { "read": true } }',
'{ "hiddenScreens": ["AdminPanel", "HomeAutomation", "FamilyManagement", "WomenSafety"], "readOnlyFields": ["user.role", "user.settings"], "disabledFeatures": ["sos", "family", "advanced-ai"] }');

-- ==============================================================================
-- INSERT USER PERMISSIONS (based on roles)
-- ==============================================================================
INSERT INTO permissions (id, user_id, flags, permissions, ui_restrictions)
SELECT UUID(), id, 
    (SELECT flags FROM role_permissions WHERE role = users.role),
    (SELECT base_permissions FROM role_permissions WHERE role = users.role),
    (SELECT ui_restrictions FROM role_permissions WHERE role = users.role)
FROM users;

-- ==============================================================================
-- INSERT DEFAULT EMERGENCY CONTACTS
-- ==============================================================================
INSERT INTO default_emergency_contacts (id, name, phone, description, country, service_type, is_active, display_order, icon) VALUES
('dec-001', 'Police', '100', 'Police Emergency', 'India', 'police', TRUE, 1, 'shield'),
('dec-002', 'Women Helpline', '1091', 'Women Safety Helpline', 'India', 'emergency', TRUE, 2, 'women'),
('dec-003', 'Ambulance', '102', 'Medical Emergency', 'India', 'medical', TRUE, 3, 'medkit'),
('dec-004', 'Fire', '101', 'Fire Emergency', 'India', 'fire', TRUE, 4, 'flame'),
('dec-005', 'Child Helpline', '1098', 'Child Emergency', 'India', 'child', TRUE, 5, 'people');

-- ==============================================================================
-- INSERT USER EMERGENCY PREFERENCES
-- ==============================================================================
INSERT INTO user_emergency_preferences (id, user_id, enable_sos, auto_share_location, notify_emergency_contacts, sos_sound_enabled, sos_vibration_enabled, emergency_message) VALUES
(UUID(), 'user-admin-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'I need help immediately!'),
(UUID(), 'user-guardian-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency! Please help!'),
(UUID(), 'user-guardian-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Need immediate assistance'),
(UUID(), 'user-parent-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency SOS triggered'),
(UUID(), 'user-parent-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Please help me!'),
(UUID(), 'user-woman-001', TRUE, TRUE, TRUE, TRUE, TRUE, 'I am in danger, please help!'),
(UUID(), 'user-woman-002', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency! Need help!'),
(UUID(), 'user-friend-001', TRUE, FALSE, TRUE, TRUE, TRUE, 'Need assistance'),
(UUID(), 'user-friend-002', TRUE, FALSE, TRUE, TRUE, TRUE, 'Please contact me'),
(UUID(), 'user-woman-003', TRUE, TRUE, TRUE, TRUE, TRUE, 'Emergency!');

-- ==============================================================================
-- INSERT USER SETTINGS
-- ==============================================================================
INSERT INTO user_settings (id, user_id, notification_enabled, location_sharing, auto_sos, shake_to_sos, sos_timer, shake_sensitivity, volume_press_enabled, power_press_enabled, voice_enabled, auto_sos_enabled) VALUES
(UUID(), 'user-admin-001', TRUE, TRUE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-guardian-001', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-guardian-002', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-parent-001', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-parent-002', TRUE, TRUE, FALSE, TRUE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-woman-001', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE),
(UUID(), 'user-woman-002', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE),
(UUID(), 'user-friend-001', TRUE, FALSE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-friend-002', TRUE, FALSE, FALSE, FALSE, 30, 3, FALSE, FALSE, FALSE, FALSE),
(UUID(), 'user-woman-003', TRUE, TRUE, FALSE, TRUE, 30, 3, TRUE, TRUE, TRUE, FALSE);

-- ==============================================================================
-- INSERT FAMILIES
-- ==============================================================================
INSERT INTO families (id, name, description, created_by) VALUES
('family-001', 'Patel Family', 'Rajesh Patel family', 'user-guardian-001'),
('family-002', 'Sharma Family', 'Priya Sharma family', 'user-guardian-002'),
('family-003', 'Kumar Family', 'Amit and Sneha Kumar family', 'user-parent-001'),
('family-004', 'Singh Family', 'Anjali Singh family', 'user-woman-001');

-- ==============================================================================
-- INSERT FAMILY MEMBERS
-- ==============================================================================
INSERT INTO family_members (id, family_id, user_id, role, nickname) VALUES
('fm-001', 'family-001', 'user-guardian-001', 'head', 'Dad'),
('fm-002', 'family-001', 'user-woman-001', 'member', 'Daughter'),
('fm-003', 'family-002', 'user-guardian-002', 'head', 'Mom'),
('fm-004', 'family-002', 'user-woman-003', 'member', 'Daughter'),
('fm-005', 'family-003', 'user-parent-001', 'head', 'Father'),
('fm-006', 'family-003', 'user-parent-002', 'head', 'Mother'),
('fm-007', 'family-004', 'user-woman-001', 'head', 'Self'),
('fm-008', 'family-004', 'user-friend-001', 'member', 'Friend');

-- ==============================================================================
-- INSERT FAMILY PLACES
-- ==============================================================================
INSERT INTO family_places (id, family_id, name, place_type, address, latitude, longitude, radius_meters, is_active, created_by) VALUES
('fp-001', 'family-001', 'Patel Home', 'home', '123 Main Road, Mumbai', 19.0760, 72.8777, 100, TRUE, 'user-guardian-001'),
('fp-002', 'family-001', 'St. Mary School', 'school', '456 Education Lane, Mumbai', 19.0780, 72.8800, 200, TRUE, 'user-guardian-001'),
('fp-003', 'family-002', 'Sharma Residence', 'home', '789 Oak Street, Delhi', 28.6139, 77.2090, 100, TRUE, 'user-guardian-002'),
('fp-004', 'family-003', 'Kumar House', 'home', '321 Pine Avenue, Bangalore', 12.9716, 77.5946, 100, TRUE, 'user-parent-001');

-- ==============================================================================
-- INSERT HOME DEVICES
-- ==============================================================================
INSERT INTO home_devices (id, user_id, name, device_type, room, status, brightness, is_locked) VALUES
('hd-001', 'user-guardian-001', 'Living Room Light', 'light', 'Living Room', 'on', 80, TRUE),
('hd-002', 'user-guardian-001', 'Bedroom Fan', 'fan', 'Bedroom', 'on', 3, TRUE),
('hd-003', 'user-parent-001', 'Baby Room Monitor', 'camera', 'Baby Room', 'on', 0, TRUE);

-- ==============================================================================
-- INSERT GEOFENCES
-- ==============================================================================
INSERT INTO geofences (id, user_id, name, latitude, longitude, radius, is_active) VALUES
('geo-001', 'user-guardian-001', 'Home', 19.0760, 72.8777, 100, TRUE),
('geo-002', 'user-parent-001', 'Home', 12.9716, 77.5946, 100, TRUE);

-- ==============================================================================
-- INSERT SAFETY LAWS
-- ==============================================================================
INSERT INTO safety_laws (id, title, description, content, category, jurisdiction, penalties, is_active) VALUES
(UUID(), 'Criminal Law (Amendment) Act 2013', 'Strengthened laws for sexual offences', '<h2>Criminal Law Amendment</h2><p>Key provisions include:</p><ul><li>Stringent punishments for sexual offences</li><li>Definition of sexual harassment expanded</li><li>Fast-track courts for trial</li></ul>', 'violence', 'National', 'Up to life imprisonment', TRUE),
(UUID(), 'Protection of Women from Domestic Violence Act', 'Legal protection for women against domestic violence', '<h2>Domestic Violence Protection</h2><p>Provides protection to women who are victims of domestic violence including:</p><ul><li>Physical violence</li><li>Emotional abuse</li><li>Economic deprivation</li></ul>', 'domestic', 'National', 'Fine and/or imprisonment up to 1 year', TRUE),
(UUID(), 'Workplace Harassment Prevention Law', 'Employers must maintain harassment-free workplace environments', '<h2>Workplace Harassment Prevention</h2><p>Key provisions include:</p><ul><li>Mandatory training programs</li><li>Confidential reporting systems</li><li>Prompt investigation requirements</li></ul>', 'workplace', 'National', 'Fines up to $50,000', TRUE);

-- ==============================================================================
-- INSERT APP SETTINGS
-- ==============================================================================
INSERT INTO app_settings (id, setting_key, setting_value, description, is_encrypted) VALUES
(UUID(), 'groq_key', '', 'Groq API key for AI chat functionality', TRUE),
(UUID(), 'app_name', 'Women Safety App', 'Application name', FALSE),
(UUID(), 'app_version', '1.0.0', 'Application version', FALSE),
(UUID(), 'max_sos_contacts', '5', 'Maximum emergency contacts per user', FALSE);

-- ==============================================================================
-- INSERT DEFAULT MENUS
-- ==============================================================================
-- Primary Navigation
INSERT INTO menus (id, name, type, is_active, menu_order, label, route, icon, purpose, menu_for, is_visible, items) VALUES
('menu-primary', 'Primary Navigation', 'primary', TRUE, 0, 'Primary Navigation', NULL, NULL, 'home', 'mobile', TRUE, '[]');

-- Core Services Container
INSERT INTO menus (id, name, type, is_active, menu_order, bg_color, text_color, purpose, menu_for, is_visible, items) VALUES
('menu-core-services', 'Core Services', 'secondary', TRUE, 1, '#EC4899', '#FFFFFF', 'home', 'mobile', TRUE, '[]');

-- Core Service Items
INSERT INTO menus (id, name, type, is_active, parent_id, menu_order, route, icon, label, subtitle, bg_color, purpose, menu_for, is_visible, required_roles, category, items) VALUES
('svc-women-safety', 'Women Safety', 'secondary', TRUE, 'menu-core-services', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'SOS, emergency contacts & safety tips', '#EC4899', 'home', 'mobile', TRUE, '["woman", "parent", "guardian"]', 'safety', '[]'),
('svc-child-care', 'Child Care', 'secondary', TRUE, 'menu-core-services', 2, 'ChildCare', 'happy', 'Child Care', 'Tips, guidance & assistant', '#10B981', 'home', 'mobile', TRUE, '["parent", "guardian"]', 'family', '[]'),
('svc-family', 'Family', 'secondary', TRUE, 'menu-core-services', 3, 'Family', 'people', 'Family', 'Family location & safety', '#3B82F6', 'home', 'mobile', TRUE, '["woman", "parent", "guardian"]', 'family', '[]'),
('svc-home-automation', 'Home Automation', 'secondary', TRUE, 'menu-core-services', 4, 'HomeAutomation', 'home', 'Home Automation', 'Control smart devices', '#8B5CF6', 'home', 'mobile', TRUE, '["guardian"]', 'lifestyle', '[]'),
('svc-cylinder', 'Cylinder Verification', 'secondary', TRUE, 'menu-core-services', 5, 'CylinderVerification', 'flame', 'Cylinder Verification', 'Verify gas cylinder safety', '#EF4444', 'home', 'mobile', TRUE, NULL, 'safety', '[]'),
('svc-vision', 'Vision AI', 'secondary', TRUE, 'menu-core-services', 6, 'Vision', 'camera', 'Vision AI', 'Image analysis with AI', '#8B5CF6', 'home', 'mobile', TRUE, '["ai.vision"]', 'ai', '[]'),
('svc-speech', 'Speech to Text', 'secondary', TRUE, 'menu-core-services', 7, 'SpeechToText', 'mic', 'Speech to Text', 'Convert speech to text', '#6366F6', 'home', 'mobile', TRUE, '["ai.speech"]', 'ai', '[]'),
('svc-tts', 'Text to Speech', 'secondary', TRUE, 'menu-core-services', 8, 'TextToSpeech', 'volume-high', 'Text to Speech', 'Convert text to speech', '#EC4899', 'home', 'mobile', TRUE, '["ai.tts"]', 'ai', '[]'),
('svc-chat', 'AI Chat', 'secondary', TRUE, 'menu-core-services', 9, 'Chat', 'chatbubbles', 'AI Chat', 'Chat with AI assistant', '#10B981', 'home', 'mobile', TRUE, '["ai.chat"]', 'ai', '[]'),
('svc-thought-generator', 'Thought Generator', 'secondary', TRUE, 'menu-core-services', 10, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'AI-powered suggestions', '#F59E0B', 'home', 'mobile', TRUE, '["ai.chat"]', 'ai', '[]'),
('svc-safety-map', 'Safety Map', 'secondary', TRUE, 'menu-core-services', 11, 'SafetyMap', 'map', 'Safety Map', 'Community safety map', '#10B981', 'home', 'mobile', TRUE, '["safety.map.view"]', 'safety', '[]'),
('svc-safe-route', 'Safe Route', 'secondary', TRUE, 'menu-core-services', 12, 'SafeRoute', 'navigate', 'Safe Route', 'AI-powered safe routes', '#3B82F6', 'home', 'mobile', TRUE, '["safe.route.view"]', 'safety', '[]');

-- More Menu (Secondary Navigation)
INSERT INTO menus (id, name, type, is_active, menu_order, label, route, icon, purpose, menu_for, is_visible, items) VALUES
('menu-more', 'More', 'secondary', TRUE, 100, 'More', NULL, 'ellipsis-horizontal', 'home', 'mobile', TRUE, '[]');

-- More Menu Items
INSERT INTO menus (id, name, type, is_active, parent_id, menu_order, route, icon, label, purpose, menu_for, is_visible, category, items) VALUES
('menu-women-safety', 'Women Safety', 'secondary', TRUE, 'menu-more', 1, 'WomenSafety', 'shield-checkmark', 'Women Safety', 'more', 'mobile', TRUE, 'safety', '[]'),
('menu-child-care', 'Child Care', 'secondary', TRUE, 'menu-more', 2, 'ChildCare', 'happy', 'Child Care', 'more', 'mobile', TRUE, 'family', '[]'),
('menu-family', 'Family', 'secondary', TRUE, 'menu-more', 3, 'Family', 'people', 'Family', 'more', 'mobile', TRUE, 'family', '[]'),
('menu-home-automation', 'Home Automation', 'secondary', TRUE, 'menu-more', 4, 'HomeAutomation', 'home', 'Home Automation', 'more', 'mobile', TRUE, 'lifestyle', '[]'),
('menu-cylinder', 'Cylinder Verification', 'secondary', TRUE, 'menu-more', 5, 'CylinderVerification', 'flame', 'Cylinder Verification', 'more', 'mobile', TRUE, 'safety', '[]'),
('menu-vision', 'Vision AI', 'secondary', TRUE, 'menu-more', 6, 'Vision', 'camera', 'Vision AI', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-speech', 'Speech to Text', 'secondary', TRUE, 'menu-more', 7, 'SpeechToText', 'mic', 'Speech to Text', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-tts', 'Text to Speech', 'secondary', TRUE, 'menu-more', 8, 'TextToSpeech', 'volume-high', 'Text to Speech', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-models', 'Model Browser', 'secondary', TRUE, 'menu-more', 9, 'Models', 'server', 'Model Browser', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-chat', 'AI Chat', 'secondary', TRUE, 'menu-more', 10, 'Chat', 'chatbubbles', 'AI Chat', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-safety-map', 'Safety Map', 'secondary', TRUE, 'menu-more', 11, 'SafetyMap', 'map', 'Safety Map', 'more', 'mobile', TRUE, 'safety', '[]'),
('menu-safe-route', 'Safe Route', 'secondary', TRUE, 'menu-more', 12, 'SafeRoute', 'navigate', 'Safe Route', 'more', 'mobile', TRUE, 'safety', '[]'),
('menu-behavior', 'Behavior Pattern', 'secondary', TRUE, 'menu-more', 13, 'BehaviorPattern', 'trending-up', 'Behavior Pattern', 'more', 'mobile', TRUE, 'safety', '[]'),
('menu-thought-generator', 'Thought Generator', 'secondary', TRUE, 'menu-more', 14, 'ThoughtGenerator', 'bulb', 'Thought Generator', 'more', 'mobile', TRUE, 'ai', '[]'),
('menu-settings', 'Settings', 'secondary', TRUE, 'menu-more', 15, 'Settings', 'settings', 'Settings', 'more', 'mobile', TRUE, 'system', '[]'),
('menu-profile', 'My Profile', 'secondary', TRUE, 'menu-more', 16, 'Profile', 'person', 'My Profile', 'more', 'mobile', TRUE, 'system', '[]');

-- ==============================================================================
-- DEFAULT THEME
-- ==============================================================================
INSERT INTO themes (id, name, description, is_default, is_active, config) VALUES
('theme-dark-default', 'Dark Default', 'Default dark theme with purple accents', TRUE, TRUE,
'{"colors": {"primary": "#8B5CF6", "primaryLight": "#A78BFA", "primaryDark": "#7C3AED", "secondary": "#EC4899", "background": "#0F0F23", "surface": "#1A1A2E", "card": "#16213E", "text": "#FFFFFF", "textMuted": "#A0A0A0", "border": "#2D2D44", "success": "#10B981", "error": "#EF4444", "warning": "#F59E0B", "info": "#3B82F6"}}');

SELECT 'Database dump completed successfully!' as message;
